/* DCC Seasons — ambient engine v3. Lazy-loaded by ambient.js after idle;
 * never in the critical path. Everything is drawn in code: inline SVG
 * data-URIs + canvas primitives. No external requests, no libraries.
 *
 * Systems:
 *  - Bespoke illustrated sprite set (one consistent hand: 2–4 flat colors,
 *    bold shapes, legible at ~30px). Emoji remain as tofu-checked fallbacks.
 *  - THE WATERLINE (bottom ~8%): settle+ripples, floaters, cruise wakes,
 *    jumping bass, submerged manatee — the site's signature.
 *  - Depth layers: FAR (60% scale, 50% speed, 60% opacity) behind NEAR.
 *  - Waterline reflections: near actors within ~60px above the water draw a
 *    flipped, squashed, 25% mirror; floaters get a broken shimmer line.
 *    Off on mobile by default; first rung of the degrade ladder.
 *  - Pointer awareness (observation only — canvas stays pointer-events:
 *    none): soft repulsion near the cursor; a click landing on a particle
 *    pops it without consuming the click.
 *  - Vignette director: rare 5–12s choreographed scenes, one at a time,
 *    ≥90s apart, first ≥20s after load; actors borrow pool slots so the
 *    density cap is never exceeded; never overlaps a hero.
 *  - Evening tint (19:00–06:00 local): −10% brightness, +30% glow, one
 *    night variant per theme (fireflies, deck lights, sleigh-past-moon).
 *  - Christmas snow accumulation: a ≤6px snow line builds along the
 *    waterline from settled flakes; per-session only.
 *  - Auto-degrade: rolling ~8ms frame budget sheds reflections → far
 *    parallax → vignettes, silently.
 *  - Directional facing (face:'L'), motion personalities, hero crossers,
 *    and the v2.1 physics all carried forward.
 *
 * Every theme runs at full richness — the former "gentle" special case
 * for Patriot Day / MLK Day was retired in 3.2.0 at the owner's request;
 * the settings sliders are the way to tone things down. */
(function () {
	'use strict';
	var FT = 'px sans-serif';
	var W = window, D = document, MT = Math, TAU = MT.PI * 2, sin = MT.sin, cos = MT.cos, abs = MT.abs, mn = MT.min, mx2 = MT.max, atan2 = MT.atan2, sqrt = MT.sqrt, rand = MT.random;

	var DBG = typeof __DCC_DEBUG__ === 'undefined' ? true : __DCC_DEBUG__;
	function sgn() { return rand() < 0.5 ? -1 : 1; }
	function rnd(a, b) { return a + rand() * (b - a); }
	function pick(arr) { return arr[(rand() * arr.length) | 0]; }
	function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
	function lerp(a, b, t) { return a + (b - a) * t; }
	function easeIO(t) { return t < 0.5 ? 2 * t * t : 1 - MT.pow(-2 * t + 2, 2) / 2; }

	/* ---------- SVG sprite registry — one artist, one line weight ---------- */
	function plateSvg(bg, fg, txt, sil) {
		return '40 22|<rect x="1" y="1" width="38" height="20" rx="3" fill="' + bg + '"/><rect x="1" y="1" width="38" height="20" rx="3" fill="none" stroke="' + fg + '" stroke-width="1.6"/><text x="20" y="15.6" font-family="a" font-weight="bold" font-size="10" fill="' + fg + '" text-anchor="middle">' + txt + '</text><path d="' + sil + '" fill="' + fg + '" opacity=".45"/>';
	}
	function jackSvg(body, face) {
		return '30 28|<path d="M13 4q-1-3 2-4l1 4Z" fill="%c"/><ellipse cx="15" cy="16" rx="14" ry="12" fill="' + body + '"/><path d="M15 4v24" stroke="#E8590C" stroke-width="1"/>' + face;
	}
	var SVGS = {
		/* — canal & boats — */
		joint: '20 42|<path d="M8 38 12 38 15 16 5.6 16Z" fill="%d" stroke="#9AA3AD" stroke-width="1.4"/><path d="M8.6 33 11 33" stroke="#9AA3AD" stroke-width="0.9"/><circle cx="10.3" cy="12" r="4.8" fill="#FF6B1A" opacity="0.16"/><circle cx="10.3" cy="12" r="2.9" fill="#FF7A1A" opacity="0.45"/><path d="M5.6 16 15 16 14 12 12 13 10 11 8.7 13 7 12Z" fill="%q" stroke="#9AA3AD" stroke-width="1"/><circle cx="10.3" cy="12.4" r="1.7" fill="#FFC24D"/><path d="M13 8q3 -3 1 -6" fill="none" stroke="%t" stroke-width="1.3" opacity="0.5"/>',
		peacehand: '28 33|<g fill="#F2C79B" stroke="#C98F55" stroke-width="1"><path d="M11 17 8 5a2 2 0 0 1 3.7-1L15 16Z"/><path d="M16 16 21 5a2 2 0 0 1 3.5 1.4L20 17Z"/><path d="M9 15h11q3.4 0 3.4 5v3.2q0 8-7 8h-3.4q-5 0-5-6Z"/><path d="M10 20q-3.6-1.4-4 1.6t3.8 3.4"/></g><g fill="none" stroke="#C98F55" stroke-width="1"><path d="M11 23h11M12 26h11"/></g>',
		snowflake: '24 24|<g stroke="#8FC1E8" stroke-linecap="round" fill="none"><g stroke-width="2"><path d="M12 2v20M3.4 7l17 10M3.4 17 21 7"/></g><g stroke-width="1.4"><path d="m12 7-2.6-2.6M12 7l2.6-2.6M12 17l-2.6 2.6M12 17l2.6 2.6M7 9 3 9m2.8 6L3 15m14-6L21 9m-2.8 6L21 15"/></g></g>',
		sparkle: '24 24|<g fill="%k"><path d="M9 1c1.2 5 2.4 7 7 8-5 1-6 2.2-7 8-1.2-5-2.4-7-7-8 5-1 6-2.2 7-8Z"/><path d="M18 13c.7 3 1.3 3.7 4 4-2.7.6-3.3 1.3-4 4-.7-3-1.3-3.7-4-4 2.7-.6 3.3-1.3 4-4Z"/></g>',
		fleur: '26 34|<g fill="%a"><path d="M13 1C16 6 16 11 15 14 14 16 14 17 13 19 13 17 12 16 11 14 10 11 10 6 13 1Z"/><path d="M12 19C10 13 6 8.6 3.4 11 1.2 14 3 18 6.4 18 3.6 20 3 24 5.4 26 7.6 27 11 25 12 19Z"/><path d="M14 19C16 13 20 8.6 23 11 25 14 23 18 20 18 22 20 23 24 21 26 18 27 15 25 14 19Z"/></g><rect x="5" y="18.6" width="16" height="3.6" rx="1.4" fill="%f"/><path d="M10 22 16 22 13 32Z" fill="%a"/>',
		clover: '26 30|<g fill="%j"><path id="cv" d="M13 13C13 4.6 3.6 5 5.6 11C2.4 8.4 0.8 15 13 13Z"/><use href="#cv" transform="rotate(90 13 13)"/><use href="#cv" transform="rotate(180 13 13)"/><use href="#cv" transform="rotate(270 13 13)"/></g><path d="M13 14q1.6 8-2 15" fill="none" stroke="%c" stroke-width="1.8"/>',
		orange: '24 27|<circle cx="12" cy="16" r="10" fill="%r"/><path d="M12 6q4-5 9-3.4-2.4 5-8 5Z" fill="%j"/><path d="M12 5V8" stroke="%i" stroke-width="1.8"/><ellipse cx="8" cy="12" rx="2.6" ry="1.8" fill="#FFA94D" opacity=".75" transform="rotate(-40 8 12)"/>',
		banana: '30 24|<path d="M3.4 4q1.4 15 15 17 10 1.2 11-6-2.4 3.4-10 2.4Q7 16 7 3.6Z" fill="%k"/><path d="M5 3.6 3 1l3.6 1.4Zm23 11 2 1.4-2.4 2.4Z" fill="%i"/><path d="M5 5q1.6 12 13 14" fill="none" stroke="#E8C33C" stroke-width="1"/>',
		burger: '30 27|<path d="M2 12a13 9 0 0 1 26 0Z" fill="#E8A83C"/><g fill="%d"><circle cx="10" cy="8" r="1"/><circle cx="16" cy="6" r="1"/><circle cx="21" cy="8" r="1"/></g><path d="M2.6 12h25l-1 3.2H3.6Z" fill="%j"/><rect x="2.4" y="15" width="25" height="5" rx="1.8" fill="#8B5A2B"/><path d="M3 19h24a12 6 0 0 1-24 0Z" fill="#D9963C"/>',
		olive: '30 21|<path d="M2 18q12-2.4 26-14" fill="none" stroke="%c" stroke-width="1.6"/><g fill="%j"><ellipse cx="8" cy="13" rx="4" ry="2.2" transform="rotate(-32 8 13)"/><ellipse cx="15" cy="9" rx="4" ry="2.2" transform="rotate(-32 15 9)"/><ellipse cx="22" cy="6" rx="4" ry="2.2" transform="rotate(-32 22 6)"/><ellipse cx="11" cy="18" rx="3.6" ry="2" transform="rotate(22 11 18)"/><ellipse cx="18" cy="15" rx="3.6" ry="2" transform="rotate(22 18 15)"/></g>',
		tree: '30 34|<circle cx="15" cy="12" r="10" fill="%j"/><circle cx="8" cy="16" r="6" fill="%c"/><circle cx="22" cy="16" r="6" fill="%c"/><rect x="13" y="20" width="4" height="13" rx="1" fill="%i"/>',
		flamingo: '28 40|<ellipse cx="14" cy="25" rx="10" ry="7" fill="%s"/><path d="M8 20q4-4 8-2" fill="none" stroke="%u" stroke-width="2.4" opacity="0.55"/><path d="M17 20q3.4-9-2.6-12.4T6 11" fill="none" stroke="%s" stroke-width="4.2" stroke-linecap="round"/><circle cx="6" cy="10" r="3.4" fill="%s"/><path d="M3.4 11 0.4 14 4.4 13Z" fill="%b"/><circle cx="5.2" cy="9" r="0.9" fill="%g"/><path d="M12 31v7m4.4-7v7" stroke="%u" stroke-width="1.6"/><path d="M9.6 38H14m1 0h4.4" stroke="%u" stroke-width="1.4"/>',
		bat: '38 20|<path d="M19 5.4C21 2.6 23 1.6 26 2.2 25 4 25 5.6 26 6.8 29 4.2 32 3.8 35 5.4 31 6.8 29 9.4 29 13 26 11 24 12 22 14 21 12 20 10 19 10 18 10 17 12 16 14 14 12 12 11 9 13 8.6 9.4 6.6 6.8 3 5.4 6.2 3.8 9.4 4.2 12 6.8 13 5.6 13 4 12 2.2 15 1.6 17 2.6 19 5.4Z" fill="%b"/><path d="M17 3.8 16 0.8 18 2.4Z" fill="%b"/><path d="M21 3.8 22 0.8 20 2.4Z" fill="%b"/><circle cx="17.4" cy="7.2" r="0.9" fill="%e"/><circle cx="20.6" cy="7.2" r="0.9" fill="%e"/>',
		flutes: '30 34|<g fill="%d" stroke="#8A99A8" stroke-width="1.8"><path d="M4 3 11 5 9 14q-1 3-4 2T3 12Z"/><path d="M26 3 19 5l2 9q1 3 4 2t2-4Z"/></g><g fill="%k"><path d="M5 8l5 2-1 5q-1 2-3 1t-2-3Z"/><path d="M25 8l-5 2 1 5q1 2 3 1t2-3Z"/></g><path d="M7 17 9 29m14-12-2 12" stroke="#8A99A8" stroke-width="1.8"/><path d="M5 30h8m3 0h8" stroke="#8A99A8" stroke-width="2"/><g fill="%d" stroke="#8A99A8" stroke-width="1"><circle cx="13" cy="2" r="1.4"/><circle cx="18" cy="1.4" r="1.1"/></g>',
		umbrella: '32 35|<path d="M2 14a14 12 0 0 1 28 0Z" fill="%e"/><path d="M9 14q0-9 4-12a5 5 0 0 1 2.6-.2v12Zm7 0V2a5 5 0 0 1 2.6.2Q23 5 23 14Z" fill="%d"/><path d="M16 14v20" stroke="%p" stroke-width="2.2"/>',
		recycle: '34 34|<g fill="%j"><g id="rc"><rect x="7" y="8" width="14" height="4.4" rx="1.4"/><path d="M20 5 27.5 10.2 20 15.4Z"/></g><use href="#rc" transform="rotate(120 17 17)"/><use href="#rc" transform="rotate(240 17 17)"/></g>',
		hook: '20 30|<path d="M10 1.4v12" stroke="%t" stroke-width="2"/><path d="M10 14q0 9.4-4.2 9.4T2 17" fill="none" stroke="%t" stroke-width="2.2"/><path d="M2 17 4.8 20 1 19Z" fill="%t"/><circle cx="10" cy="2" r="2.2" fill="%h"/>',
		pontoon: '48 30|<path d="M3 21 L45 21 Q47 21 47 24 Q47 27 45 27 L3 27 Q1 27 1 24 Q1 21 3 21 Z" fill="#868E96"/><path d="M4 17 L42 17 L44 21 L2 21 Z" fill="%d"/><path d="M6 6 L36 6 L38 9 L4 9 Z" fill="%e"/><path d="M7 9 L7 17 M35 9 L35 17" stroke="%h" stroke-width="1.6"/><circle cx="21" cy="13" r="2.6" fill="%b"/><path d="M19 16 L23 16 L23 19 L19 19 Z" fill="%m"/><path d="M40 12 L44 12 L44 17 L40 17 Z" fill="%b"/><path d="M42 3 L47 3 L46 5 L47 7 L42 7 Z" fill="%a"/><path d="M42 3 L42 12" stroke="%h" stroke-width="1.2"/>',
		kayak: '52 22|<path d="M2 16q24-7 48 0-24 7-48 0Z" fill="%r"/><circle cx="26" cy="7" r="3" fill="%b"/><path d="M26 10v5" stroke="%b" stroke-width="2"/><line x1="14" y1="2" x2="38" y2="14" stroke="%p" stroke-width="2"/><ellipse cx="13" cy="2" rx="3" ry="2" fill="%a" transform="rotate(28 13 2)"/><ellipse cx="39" cy="14" rx="3" ry="2" fill="%a" transform="rotate(28 39 14)"/>',
		skiff: '52 22|<path d="M2 10 L44 11 L44 16 Q26 19 8 16 Z" fill="%d"/><path d="M4.6 14.2 L44 14.2 L44 16 Q26 19 8 16 Z" fill="%v"/><path d="M2 10 L44 11 L44 16 Q26 19 8 16 Z" fill="none" stroke="%x" stroke-width="1.2" stroke-linejoin="round"/><path d="M2.6 11.4 L43.6 12.2" stroke="%m" stroke-width="1.1" fill="none"/><path d="M44 11 L48 11 L48 15 L46.6 15 L46.6 19 L45 19 L45 15 L44 15 Z" fill="%b"/><path d="M38 11 L38.6 5.6 M44 11 L44 5.6" stroke="%h" stroke-width="1.4" fill="none"/><path d="M36 3.4 L48 3.4 L48 5.4 L36 5.4 Z" fill="%t" stroke="%h" stroke-width="0.8"/><path d="M22 11 L27 11 L26 6 L23 6 Z" fill="%t" stroke="%x" stroke-width="0.8"/>',
		bobber: '24 30|<line x1="12" y1="0" x2="12" y2="4" stroke="%h" stroke-width="2"/><circle cx="12" cy="16" r="11" fill="%d"/><path d="M1 16a11 11 0 0 1 22 0Z" fill="%e"/><circle cx="12" cy="16" r="11" fill="none" stroke="%b" stroke-width="1"/><circle cx="12" cy="4" r="2" fill="%b"/>',
		tacklebox: '32 26|<rect x="2" y="9" width="28" height="15" rx="2" fill="%c"/><rect x="2" y="9" width="28" height="5" fill="#237032"/><path d="M12 9V6a4 4 0 0 1 8 0v3h-3V6a1 1 0 0 0-2 0v3Z" fill="%h"/><rect x="14" y="11" width="5" height="4" rx="1" fill="%a"/>',
		lure: '30 20|<path d="M21 9 L27.6 5.4 L26 9 L27.6 12.6 Z" fill="%e"/><path d="M7 9 A7 4.4 0 0 1 21 9 Z" fill="%e"/><path d="M7 9 A7 4.4 0 0 0 21 9 Z" fill="%d"/><ellipse cx="14" cy="9" rx="7" ry="4.4" fill="none" stroke="%h" stroke-width="0.9"/><path d="M7 8.6 L1.6 12.4 L5.6 13.4 Z" fill="%t"/><path d="M3.4 6.6 L6.4 8" stroke="%h" stroke-width="1"/><circle cx="10" cy="7.4" r="1.3" fill="%b"/><path d="M11 13 L11 15 M11 15 L9.6 16.8 M11 15 L12.4 16.8 M17.6 12.6 L17.6 14.6 M17.6 14.6 L16.2 16.4 M17.6 14.6 L19 16.4" stroke="%h" stroke-width="0.9" fill="none" stroke-linecap="round"/>',
		bass: '48 26|<path d="M6 13q12-10 28-8l10-4-3 8 3 8-10-4q-16 2-28-8Z" fill="#37633F"/><path d="M8 13q11-7 26-6-13 12-26 6Z" fill="#5C8A54"/><path d="M20 3q6-3 10 0l-4 4Z" fill="#37633F"/><path d="M22 22q5 3 9 1l-4-5Z" fill="#37633F"/><circle cx="12" cy="11" r="2" fill="#111"/><path d="M6 13q3 3 7 3" fill="none" stroke="#2F4F35" stroke-width="1"/>',
		lilypad: '36 22|<path d="M31.9 7 A16 8 0 1 0 33 13.7 L18 11 Z" fill="%c"/><path d="M18 11 L4 8 M18 11 L5 14 M18 11 L11 18 M18 11 L20 18 M18 11 L19 3 M18 11 L28 4" stroke="#237032" stroke-width="0.9" fill="none"/><circle cx="10" cy="7" r="3" fill="%s"/><circle cx="10" cy="7" r="1.1" fill="#FDE68A"/>',
		sabalpalm: '34 38|<path d="M14 38 L15 20 L19 20 L20 38 Z" fill="%p"/><path d="M14.6 25 L19.4 25 M14.4 30 L19.6 30 M14.2 35 L19.8 35" stroke="%i" stroke-width="1.1" fill="none"/><g fill="%c"><path id="fr" d="M17 19 L12.4 7.6 L14.6 10.4 L15.6 4.6 L17 8.6 L18.4 4.6 L19.4 10.4 L21.6 7.6 Z"/><use href="#fr" transform="rotate(30 17 19)"/><use href="#fr" transform="rotate(-30 17 19)"/><use href="#fr" transform="rotate(60 17 19)"/><use href="#fr" transform="rotate(-60 17 19)"/><use href="#fr" transform="rotate(88 17 19)"/><use href="#fr" transform="rotate(-88 17 19)"/><use href="#fr" transform="rotate(112 17 19)"/><use href="#fr" transform="rotate(-112 17 19)"/></g><g fill="%j"><path id="fs" d="M17 19 L14 10.6 L15.6 12.6 L17 8.6 L18.4 12.6 L20 10.6 Z"/><use href="#fs" transform="rotate(45 17 19)"/><use href="#fs" transform="rotate(-45 17 19)"/><use href="#fs" transform="rotate(74 17 19)"/><use href="#fs" transform="rotate(-74 17 19)"/></g><circle cx="17" cy="19" r="2.4" fill="%i"/>',
		hibiscus: '30 30|<g fill="%e"><path id="pt" d="M15 16 C8.6 13.6 7 6 15 3 C23 6 21.4 13.6 15 16 Z"/><use href="#pt" transform="rotate(72 15 16)"/><use href="#pt" transform="rotate(144 15 16)"/><use href="#pt" transform="rotate(216 15 16)"/><use href="#pt" transform="rotate(288 15 16)"/></g><circle cx="15" cy="16" r="3.6" fill="%n"/><path d="M8.6 23 Q3 26.6 6 29 Q11 27.6 11.6 23.6 Z" fill="%j"/><path d="M15 16 L26.4 5.2" stroke="%k" stroke-width="1.8" fill="none"/><g fill="%a"><circle cx="21.6" cy="9.6" r="1"/><circle cx="23.6" cy="8" r="1.1"/><circle cx="25.4" cy="6.2" r="1.1"/></g><circle cx="26.6" cy="4.6" r="1.7" fill="%k"/><g fill="%u"><circle cx="25.6" cy="3.2" r="0.8"/><circle cx="27.6" cy="2.8" r="0.8"/><circle cx="28.4" cy="4.8" r="0.8"/></g>',
		conch: '30 26|<path d="M12.4 6.4 Q26.6 8.6 26.6 17.4 Q21.6 24.6 12.6 23 Z" fill="%s"/><path d="M12.4 6.4 Q26.6 8.6 26.6 17.4 Q24.6 18.6 24 17 Q25 11 11.8 9.4 Z" fill="%o" stroke="%t" stroke-width="0.7" stroke-linejoin="round"/><path d="M14.6 9.6 Q23 12.6 22.6 19" fill="none" stroke="%u" stroke-width="1.2"/><path d="M3 15.6 Q2 8.6 6.6 4.6 L9.6 0.8 L11.8 5.4 Q15 8.4 15.8 13 Q17.4 19.6 12.4 23.4 L14 25.6 L10 24.2 Q4.6 22.6 3 15.6 Z" fill="%q" stroke="%t" stroke-width="0.7" stroke-linejoin="round"/><g fill="none" stroke="%t" stroke-width="0.9"><path d="M5.4 8 Q8.6 5.4 11 7.4"/><path d="M4 12.4 Q9 9 13.6 12"/><path d="M5.6 17.4 Q9.6 19.6 13.4 18.6"/></g><g fill="%f"><circle cx="5.6" cy="10" r="1.7"/><circle cx="9.4" cy="5.6" r="1.6"/><circle cx="13.4" cy="9" r="1.5"/><circle cx="14.8" cy="14.4" r="1.4"/></g>',
		petal: '18 22|<path d="M9 1 Q15.4 6.4 15 13 Q14.6 18.6 10.6 20.4 Q9.6 19.6 9 18.6 Q8.4 19.6 7.4 20.4 Q3.4 18.6 3 13 Q2.6 6.4 9 1 Z" fill="%s"/><path d="M9 4 L9 17" stroke="%u" stroke-width="1" fill="none"/><path d="M9 9.4 Q12.2 12 12.6 15.6 M9 9.4 Q5.8 12 5.4 15.6" stroke="%u" stroke-width="0.8" fill="none"/>',
		dragonfly: '40 26|<g fill="#9CCBEF" opacity="0.85"><ellipse cx="14" cy="7" rx="8" ry="2.6" transform="rotate(-14 14 7)"/><ellipse cx="14" cy="19" rx="8" ry="2.6" transform="rotate(14 14 19)"/><ellipse cx="20.4" cy="8.6" rx="6.6" ry="2.2" transform="rotate(-8 20 8.6)"/><ellipse cx="20.4" cy="17.4" rx="6.6" ry="2.2" transform="rotate(8 20 17)"/></g><path d="M11 13 38 13" stroke="#1864AB" stroke-width="2.6" stroke-linecap="round"/><g stroke="#74C0FC" stroke-width="1"><path d="M23 12v2.8M27 12v2.4M31 12v2M35 12v2"/></g><ellipse cx="11" cy="13" rx="4.2" ry="3.4" fill="#1864AB"/><circle cx="6.4" cy="13" r="3.6" fill="#1864AB"/><circle cx="5.2" cy="11.6" r="1.4" fill="#74C0FC"/>',
		/* — birds & wildlife — */
		heron0: '90 60|<path d="M12 26q4-8 14-6l4 3-6 5q-8 2-12-2Z" fill="%x"/><path d="M28 22 8 12l2 8 14 6Z" fill="#5D6D7E"/><path d="M8 12 2 10l5 4Z" fill="%a"/><path d="M30 25q18-14 44-10-12 10-26 12l16 2q-16 8-30 2Z" fill="%v"/><path d="M34 24Q52 4 78 8 64 20 48 26Z" fill="#5D8AA8"/><path d="M56 30q10 2 22 12-14 0-24-6Z" fill="%v"/><path d="M52 32l16 10 4 6-8-2-14-10Z" fill="#34495E"/>',
		heron1: '90 60|<path d="M12 30q4-8 14-6l4 3-6 5q-8 2-12-2Z" fill="%x"/><path d="M28 26 8 16l2 8 14 6Z" fill="#5D6D7E"/><path d="M8 16 2 14l5 4Z" fill="%a"/><path d="M30 29q18 14 44 10-12-10-26-12l16-2q-16-8-30-2Z" fill="%v"/><path d="M34 30q18 20 44 16-14-12-30-18Z" fill="#5D8AA8"/><path d="M52 30l16 12 4 6-8-2-14-12Z" fill="#34495E"/>',
		heron2: '90 60|<path d="M12 28q4-8 14-6l4 3-6 5q-8 2-12-2Z" fill="%x"/><path d="M28 24 8 14l2 8 14 6Z" fill="#5D6D7E"/><path d="M8 14 2 12l5 4Z" fill="%a"/><path d="M30 27q20-5 46-1-14 4-28 4l16 4q-18 2-34-3Z" fill="%v"/><path d="M34 27q20-8 44-4-14 8-30 8Z" fill="#5D8AA8"/><path d="M52 31l16 11 4 6-8-2-14-11Z" fill="#34495E"/>',
		heronstand: '44 64|<path d="M18 10q8 2 10 12v12q0 10-8 12l-4-2q6-6 4-14-8-6-2-20Z" fill="%v"/><path d="M20 6q-6 0-8 6l6-1q4 1 2 6" fill="none" stroke="#5D6D7E" stroke-width="3"/><path d="M12 8 2 6l8 5Z" fill="%a"/><circle cx="17" cy="9" r="1" fill="#111"/><line x1="20" y1="46" x2="19" y2="60" stroke="%f" stroke-width="2"/><line x1="24" y1="46" x2="26" y2="60" stroke="%f" stroke-width="2"/><path d="M15 60h17" stroke="%f" stroke-width="2"/>',
		manatee: '92 48|<path d="M69 17 Q88 9.6 89 25 Q88 40.4 69 33 Z" fill="#7B8794"/><path d="M13 25 Q13 9 40 9 Q64 9 71 20 L71 30 Q64 41 40 41 Q13 41 13 25 Z" fill="#8D99A6"/><ellipse cx="14" cy="28" rx="8" ry="6.5" fill="#7B8794"/><circle cx="10" cy="25.6" r="1.2" fill="%b"/><circle cx="14.4" cy="25.2" r="1.2" fill="%b"/><circle cx="21" cy="19" r="1.4" fill="%b"/><path d="M28 40 Q32 48 41 44 Z" fill="#7B8794"/><path d="M48 41 Q52 47 59 44 Z" fill="#7B8794"/><path d="M30 15 Q44 12 58 15" stroke="#7B8794" stroke-width="1.2" fill="none"/>',
		dove: '46 34|<path d="M8 15q2-7 11-6 8 2 13 7l12 2-9 5 3 7-10-6q-9 3-16-3T8 15Z" fill="%d" stroke="#5A6B7C" stroke-width="2.8"/><path d="M19 15q6-10 14-9-2 7-6 11-4 3-8-2Z" fill="%q" stroke="#5A6B7C" stroke-width="2.4"/><path d="M7 14 2 16l5 2Z" fill="%a"/><circle cx="11" cy="13" r="1.4" fill="%g"/><ellipse cx="6" cy="21" rx="2.2" ry="1.2" fill="%c" transform="rotate(-25 6 21)"/><ellipse cx="10" cy="22" rx="2.2" ry="1.2" fill="%c" transform="rotate(-25 10 22)"/>',
		pelican: '48 28|<path d="M30 13 Q38 12.8 43.6 14.2 Q38 16.6 30 17.6 Z" fill="%b"/><path d="M19 16.4 Q27 22.6 40 21.4 Q31 18.6 22 16.4 Z" fill="%x"/><path d="M14 12.6 Q24 10 33 13.4 Q35 15.2 33 17 Q24 19.8 14 17.6 Z" fill="%h"/><path d="M17.4 13 Q27 4.6 42 6 Q34 10.6 22.6 14.2 Z" fill="%p"/><path d="M36.6 5.8 Q40.4 5.8 42 6 Q39.4 8 35 9.6 Z" fill="%b"/><circle cx="12.6" cy="12.6" r="4.4" fill="%q"/><path d="M8.6 11.6 Q12.6 6.6 16.8 11 Q12.6 8.8 8.6 11.6 Z" fill="%k"/><circle cx="10.4" cy="11.4" r="0.9" fill="%g"/><path d="M11 13 L1 15.4 Q0.2 16 1.4 16.6 L11.4 15.4 Z" fill="%f"/><path d="M11 15 L2 16.4 Q0.6 17 2 18 Q6.4 20.4 11 18.4 Z" fill="%a"/>',
		pelican1: '48 28|<path d="M30 13 Q38 12.8 43.6 14.2 Q38 16.6 30 17.6 Z" fill="%b"/><path d="M20 13.6 Q28 8.6 39 9 Q31 12.4 23 14 Z" fill="%x"/><path d="M14 12.6 Q24 10 33 13.4 Q35 15.2 33 17 Q24 19.8 14 17.6 Z" fill="%h"/><path d="M18 16.4 Q27 24.6 41 23 Q33 19 22.6 16.6 Z" fill="%p"/><path d="M35.6 23 Q39.6 23.2 41 23 Q38.4 20.8 34 19.6 Z" fill="%b"/><circle cx="12.6" cy="12.6" r="4.4" fill="%q"/><path d="M8.6 11.6 Q12.6 6.6 16.8 11 Q12.6 8.8 8.6 11.6 Z" fill="%k"/><circle cx="10.4" cy="11.4" r="0.9" fill="%g"/><path d="M11 13 L1 15.4 Q0.2 16 1.4 16.6 L11.4 15.4 Z" fill="%f"/><path d="M11 15 L2 16.4 Q0.6 17 2 18 Q6.4 20.4 11 18.4 Z" fill="%a"/>',
		swan: '44 38|<path d="M9 26 Q9 17 20 16 Q32 15 39 21 Q34 32 21 33 Q11 33 9 26 Z" fill="%d" stroke="#7D8B99" stroke-width="1.4" stroke-linejoin="round"/><path d="M16 21 Q26 17 35 22 Q28 29 18 27 Z" fill="%q" stroke="#7D8B99" stroke-width="1.2"/><path d="M19 18 Q11 14 13 8 Q15 2.6 22 3.4 Q27.6 4.2 28 9 L24.6 9 Q24.2 7 21.6 6.6 Q17.6 6.2 16.6 9.6 Q15.6 14 22.4 16.4 Z" fill="%d" stroke="#7D8B99" stroke-width="1.2"/><circle cx="26" cy="8" r="3.4" fill="%d" stroke="#7D8B99" stroke-width="1.2"/><path d="M29 8 L34 9.6 L29 11 Z" fill="%r"/><circle cx="27" cy="6.8" r="0.9" fill="%g"/>',
		ladybug: '24 20|<ellipse cx="14" cy="11" rx="8.4" ry="7" fill="%e"/><path d="M14 4v14" stroke="%g" stroke-width="1.2"/><g fill="%g"><circle cx="10.6" cy="8.4" r="1.4"/><circle cx="17.4" cy="8.4" r="1.4"/><circle cx="10.2" cy="13.4" r="1.4"/><circle cx="17.8" cy="13.4" r="1.4"/></g><circle cx="7" cy="8" r="4" fill="%g"/><path d="M5.4 4.6Q3.4 1.6 1.6 2.4M8.2 4.2Q7.6 1 5.6 0.8" fill="none" stroke="%g" stroke-width="1"/><circle cx="5.6" cy="6.6" r="0.8" fill="%d"/>',
		turkey: '40 36|<path d="M20 20 8 4q-3 8 4 14Zm0 0 4-18q6 4 3 14Zm0 0 12-14q4 8-5 15Z" fill="#A05A2C"/><ellipse cx="20" cy="25" rx="10" ry="9" fill="%i"/><circle cx="12" cy="18" r="5" fill="%i"/><circle cx="11" cy="17" r="1" fill="#111"/><path d="M8 18l-4 1 4 2Z" fill="%a"/><path d="M9 20q-2 3 0 5" stroke="%e" stroke-width="2" fill="none"/><line x1="17" y1="33" x2="17" y2="36" stroke="%f" stroke-width="2"/><line x1="23" y1="33" x2="23" y2="36" stroke="%f" stroke-width="2"/>',
		chick: '20 20|<circle cx="10" cy="12" r="7" fill="%k"/><circle cx="7" cy="6" r="4" fill="#FFE066"/><circle cx="6" cy="5" r=".9" fill="#111"/><path d="M3 6 .4 7l2 1Z" fill="%w"/><path d="M14 12q4-1 4 2-3 2-5 0Z" fill="#FAB005"/><line x1="8" y1="19" x2="8" y2="20" stroke="%w" stroke-width="1"/><line x1="12" y1="19" x2="12" y2="20" stroke="%w" stroke-width="1"/>',
		bunny: '32 30|<g fill="%q" stroke="#7A8290" stroke-width="1.8" stroke-linejoin="round"><path d="M9.6 13C7 7.4 8.4 2.6 11 3 13 3.4 14 8.4 12 14Z"/><path d="M14 13C13 6.8 16 3 18 4.4 20 5.8 19 10 17 13Z"/><path d="M23 26C27 26 29 22 28 18 27 14 23 11 18 11 14 11 11 12 9.4 14 7.2 13 5.2 14 4.6 16 4 19 5.4 20 7.6 21 7.4 23 9.6 26 13 26Z"/></g><circle cx="7.6" cy="17.4" r="1.4" fill="%g"/><path d="M5 19Q3.2 20 5 21" fill="none" stroke="#7A8290" stroke-width="1"/><path d="M28 20Q31 19 31 22 30 25 27 24" fill="%q" stroke="#7A8290" stroke-width="1.6"/>',
		bunnycarry: '32 32|<g fill="%q" stroke="#7A8290" stroke-width="1.8" stroke-linejoin="round"><path d="M11 12C8 6.4 9.4 1.6 12 2 14 2.4 15 7.4 13 13Z"/><path d="M15 12C14 5.8 17 2 19 3.4 21 4.8 20 9.2 18 12Z"/><path d="M24 27C28 27 30 24 29 20 28 15 24 12 19 12 15 12 12 13 10 15 8.2 15 6.2 16 5.6 18 5 20 6.4 22 8.6 22 8.4 25 11 27 14 27Z"/></g><circle cx="8.6" cy="18.8" r="1.4" fill="%g"/><ellipse cx="12.6" cy="23.4" rx="5" ry="6.2" fill="#BFDBFE" stroke="%l" stroke-width="1.6"/><path d="M7.8 22 17 22M8 25 17 25" stroke="%l" stroke-width="1.4"/><path d="M7.4 21Q6 23 8.6 26" fill="none" stroke="#7A8290" stroke-width="1.8"/><path d="M18 20Q19 23 17 26" fill="none" stroke="#7A8290" stroke-width="1.8"/>',
		/* — fall leaves: maple, oak, cypress, sweetgum — */
		leafm: '26 30|<path d="M13 2 L16 8 L21 5 L19 11 L25 10 L20 15 L24 18 L17 19 L15 22 L11 22 L9 19 L2 18 L6 15 L1 10 L7 11 L5 5 L10 8 Z" fill="%r"/><path d="M13 29 L13 20" stroke="#8B4513" stroke-width="1.6" fill="none"/><path d="M13 21 L13 6 M13 12 L19 8 M13 12 L7 8 M13 17 L20 15 M13 17 L6 15" stroke="#C44D0B" stroke-width="1" fill="none"/>',
		leafo: '22 30|<path d="M11 1q7 3 7 9 0 4-3 5 3 2 3 6 0 6-7 8-7-2-7-8 0-4 3-6-3-1-3-5 0-6 7-9Z" fill="#A0622D"/><path d="M11 4v22m0-16-4 3m4-3 4 3m-8 8 4 3m4-3-4 3" stroke="#7A4A21" stroke-width="1" fill="none"/>',
		leafc: '20 30|<path d="M10 29 L10 3" stroke="#8B4513" stroke-width="1.6" fill="none"/><g fill="#C97B3D"><ellipse cx="10" cy="4" rx="2.6" ry="3.4"/><ellipse cx="5" cy="8" rx="4.4" ry="2.4" transform="rotate(-24 5 8)"/><ellipse cx="15" cy="8" rx="4.4" ry="2.4" transform="rotate(24 15 8)"/><ellipse cx="4" cy="14" rx="5" ry="2.6" transform="rotate(-20 4 14)"/><ellipse cx="16" cy="14" rx="5" ry="2.6" transform="rotate(20 16 14)"/><ellipse cx="5" cy="20" rx="4.4" ry="2.4" transform="rotate(-16 5 20)"/><ellipse cx="15" cy="20" rx="4.4" ry="2.4" transform="rotate(16 15 20)"/></g>',
		leafs: '26 28|<path d="M13 1 L17 4 L16 6 L20 7 L18 10 L22 11 L20 14 L23 16 L19 18 L21 21 L16 21 L15 24 L13 22 L11 24 L10 21 L5 21 L7 18 L3 16 L6 14 L4 11 L8 10 L6 7 L10 6 L9 4 Z" fill="#B23A48"/><path d="M13 27 L13 22" stroke="#8B4513" stroke-width="1.6" fill="none"/><path d="M13 22 L13 3 M13 8 L18 7 M13 8 L8 7 M13 13 L20 12 M13 13 L6 12 M13 18 L19 17 M13 18 L7 17" stroke="#8C2B37" stroke-width="1" fill="none"/>',
		/* — halloween — */
		jack1: function () { return jackSvg('#FF7A00', '<path d="M8 12l5 3H6Zm14 0-5 3h7Z" fill="#111"/><path d="M8 21q7 5 14 0-2 4-7 4t-7-4Z" fill="#111"/>'); },
		jack2: function () { return jackSvg('#FF922B', '<circle cx="10" cy="13" r="3" fill="#111"/><circle cx="20" cy="13" r="3" fill="#111"/><path d="M13 17l2-3 2 3Z" fill="#111"/><path d="M8 21h14l-2 3-2-2-2 2-2-2-2 2Z" fill="#111"/>'); },
		jack3: function () { return jackSvg('#F76707', '<path d="M7 14q2-4 5-1Zm16 0q-2-4-5-1Z" fill="#111"/><path d="M10 20q5 6 10 0l-2 4h-6Z" fill="#111"/>'); },
		ghost: '26 32|<path d="M13 1q10 1 10 12v10l-3-2-3 4-4-3-4 3-3-4-3 3 1-12Q4 2 13 1Z" fill="%d" stroke="#8E97A3" stroke-width="1.8" opacity=".95"/><circle cx="9.6" cy="11" r="1.8" fill="%b"/><circle cx="16.4" cy="11" r="1.8" fill="%b"/><ellipse cx="13" cy="17" rx="2" ry="2.8" fill="%b"/>',
		spider: '24 24|<g id="sl" stroke="%g" stroke-width="1.3" fill="none" stroke-linecap="round"><path d="M6.4 11 1.6 6.2M6 13 0.8 11M6 16 1 18M6.6 18 2.4 22"/></g><use href="#sl" transform="translate(24 0) scale(-1 1)"/><ellipse cx="12" cy="15" rx="6" ry="5.4" fill="%g"/><circle cx="12" cy="7" r="3.6" fill="%b"/><circle cx="10.6" cy="6" r="0.9" fill="%e"/><circle cx="13.4" cy="6" r="0.9" fill="%e"/>',
		web: '40 40|<g stroke="#8A94A0" stroke-width="1" fill="none" opacity="0.9"><path d="M40 0 2 0M40 0 4.9 15M40 0 13 27M40 0 26 35M40 0 40 38"/><path d="M40 12 35 11 32 8.5 29 4.6 28 0"/><path d="M40 20 30 19 26 14 22 7.7 20 0"/><path d="M40 28 29 26 20 20 14 11 12 0"/><path d="M40 36 26 33 15 26 6.7 14 4 0"/></g>',
		candycorn: '22 30|<path d="M11 1 21 29H1Z" fill="%k"/><path d="M4 19 11 1l7 18Z" fill="#FF922B"/><path d="M8 9 11 1l3 8Z" fill="#FFF9DB"/>',
		witchhat: '32 26|<ellipse cx="16" cy="22" rx="15" ry="4" fill="%g"/><path d="M16 0 24 21H8Z" fill="%b"/><rect x="9" y="16" width="14" height="4" fill="#9C36B5"/><rect x="14" y="17" width="3" height="3" fill="%k"/>',
		/* — thanksgiving / harvest — */
		acorn: '22 28|<path d="M4 12h14c0 8-4 13-7 15-3-2-7-7-7-15Z" fill="#B08552"/><path d="M2 12c0-5 4-8 9-8s9 3 9 8Z" fill="%i"/><line x1="11" y1="4" x2="11" y2="0" stroke="%i" stroke-width="2"/>',
		pie: '32 22|<path d="M3 11h26l-2.4 8q-.6 2-3 2H8q-2.4 0-3-2Z" fill="%o"/><path d="M1 11q3-8 15-8T31 11Z" fill="#E8B04B"/><g stroke="#B5772E" stroke-width="1" fill="none"><path d="M8 6 5 11m6-8L10 11M16 3.2V11m5-8L22 11m1.2-5L27 11"/></g>',
		cornucopia: '48 32|<path d="M31 5 Q15 4 9 14 Q4 22 10 28 Q16 33 21 28 Q13 26 12 20 Q11 13 21 10 Q26 8 31 8 Z" fill="#A05A2C"/><path d="M12 20 Q18 17 24 18 M11 25 Q16 23 21 24" stroke="#7A421F" stroke-width="1" fill="none"/><ellipse cx="31" cy="12" rx="6" ry="8" fill="#7A421F"/><ellipse cx="31" cy="12" rx="6" ry="8" fill="none" stroke="#C98A4B" stroke-width="1.6"/><circle cx="38" cy="10" r="4.4" fill="%e"/><path d="M38 6 Q39 3 41 3" stroke="%c" stroke-width="1.4" fill="none"/><circle cx="44" cy="16" r="3.6" fill="%w"/><ellipse cx="36" cy="21" rx="5" ry="4" fill="%r"/><path d="M36 17 L36 19" stroke="%c" stroke-width="1.4"/><circle cx="43" cy="24" r="2.2" fill="%l"/><circle cx="46" cy="27" r="2" fill="%l"/><circle cx="41" cy="28" r="2" fill="%l"/>',
		/* — christmas — */
		holly: '34 22|<path d="M15 10C11 2 4 2 1 6c4 1 4 5 8 7Z" fill="%c"/><path d="M19 10c4-8 11-8 14-4-4 1-4 5-8 7Z" fill="%j"/><circle cx="14" cy="14" r="4" fill="%e"/><circle cx="21" cy="14" r="4" fill="%n"/><circle cx="18" cy="18" r="4" fill="%e"/>',
		ornament: '24 30|<rect x="9" y="2" width="5" height="5" rx="1" fill="%f"/><circle cx="12" cy="8" r="2" fill="none" stroke="%f" stroke-width="2"/><circle cx="12" cy="19" r="10" fill="%n"/><path d="M3 16a10 10 0 0 1 19 0" fill="%e"/><path d="M2 19q10-4 20 0" stroke="%a" stroke-width="2" fill="none"/><ellipse cx="9" cy="14" rx="3" ry="4" fill="#FFF5F5" opacity=".55"/>',
		gift: '26 26|<rect x="2" y="9" width="22" height="16" rx="2" fill="%m"/><rect x="1" y="6" width="24" height="5" rx="2" fill="#1C7ED6"/><rect x="11" y="6" width="4" height="19" fill="%a"/><path d="M13 6Q7 6 7 2q4-1 6 4Zm0 0q6 0 6-4-4-1-6 4Z" fill="%a"/>',
		pine: '30 38|<path d="M15 0 26 14H4Z" fill="%c"/><path d="M15 8 28 24H2Z" fill="%j"/><path d="M15 18 30 34H0Z" fill="#37B24D"/><rect x="12" y="34" width="6" height="4" fill="%i"/><path d="M15 0l1 3h-3Z" fill="%k"/>',
		sleigh: '122 46|<path d="M44 24 L62 28" stroke="%i" stroke-width="1.6" fill="none"/><g fill="%p"><path d="M16 18 Q28 13 40 18 Q45 20 45 26 Q45 32 39 32 L20 32 Q14 32 14 26 Q14 20 16 18 Z"/><path d="M16 22 Q9 21 6 15 Q4 10 9 9 Q14 8 16 13 Z"/><path d="M44 20 L50 12 L48 22 Z"/></g><path d="M11 9 L9 2 M9 4 L4 2 M9 6 L3 6 M14 9 L16 1 M16 3 L21 1" stroke="%i" stroke-width="1.6" fill="none" stroke-linecap="round"/><circle cx="6" cy="13" r="1.8" fill="%e"/><circle cx="13" cy="12" r="1" fill="%g"/><path d="M20 32 L17 44 M26 32 L29 44 M36 32 L33 44 M41 32 L45 43" stroke="%i" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M100 8 Q112 12 110 26 L104 26 Q106 16 98 13 Z" fill="%n"/><path d="M62 20 L104 20 Q110 20 110 26 L110 34 L64 34 Q59 30 60 24 Z" fill="%n"/><rect x="72" y="11" width="13" height="10" rx="1" fill="%c"/><path d="M78.5 11 L78.5 21 M72 16 L85 16" stroke="%k" stroke-width="1.4"/><rect x="88" y="14" width="9" height="7" rx="1" fill="%a"/><path d="M58 38 L112 38" stroke="%f" stroke-width="2.4"/><path d="M58 38 Q52 38 53 33 Q55 30 59 32" stroke="%f" stroke-width="2.4" fill="none"/><path d="M64 34 L64 38 M94 34 L94 38" stroke="%f" stroke-width="2"/>',
		/* — patriotic & winter visitors — */
		flagcloth: '40 26|<line x1="2" y1="0" x2="2" y2="26" stroke="%i" stroke-width="2"/><path d="M4 2q9 3 17-1 8-4 17 1v16q-9-4-17 0-8 4-17-1Z" fill="%d"/><path d="M4 2q9 3 17-1 8-4 17 1v3q-9-4-17 0-8 4-17-1Zm0 8q9 4 17 0 8-4 17 0v4q-9-4-17 0-8 4-17-1Z" fill="#B22234"/><path d="M4 2q7 2 13 0v9q-6 3-13-1Z" fill="#3C3B6E"/><g fill="%d"><circle cx="8" cy="5" r="1"/><circle cx="13" cy="5" r="1"/><circle cx="10" cy="8" r="1"/></g>',
		ribbon: '26 40|<path d="M8 2C4 10 6 20 16 34l6-4C14 20 12 10 15 2Z" fill="#B22234"/><path d="M18 2c4 8 2 18-8 32l-6-4C12 20 14 10 11 2Z" fill="#3C3B6E"/><path d="M11 2h4l-2 8Z" fill="%d"/>',
		plateny: function () { return plateSvg('#FDB515', '#1B335F', 'NY', 'M4 6l4-2 3 3-2 4-4-1Z'); },
		plateoh: function () { return plateSvg('%d', '%n', 'OH', 'M4 6h7l1 5-2 4H5l-2-4Z'); },
		platemi: function () { return plateSvg('#DCE9F5', '%m', 'MI', 'M4 10q2-5 6-4l2 3-1 5H6Z'); },
		suitcase: '30 26|<rect x="2" y="7" width="26" height="18" rx="3" fill="#A05A2C"/><path d="M11 7V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v3h-3V4h-2v3Z" fill="%i"/><rect x="2" y="13" width="26" height="2" fill="%i"/><circle cx="9" cy="19" r="3" fill="%a"/>',
		sunshades: '36 36|<circle cx="18" cy="18" r="10" fill="%k"/><g stroke="#FAB005" stroke-width="2"><path d="M18 2v5M18 29v5M2 18h5m22 0h5"/></g><path d="M11 16h6l1 4q-4 3-7-1Zm14 0h-6l-1 4q4 3 7-1Z" fill="%g"/><path d="M17 17h2" stroke="%g" stroke-width="1"/>',
		/* — mardi gras / celebration — */
		beads: '40 26|<path d="M2 2q18 30 36 0" fill="none" stroke="#5F3DC4" stroke-width="1"/><circle cx="5" cy="6" r="3" fill="%l"/><circle cx="12" cy="13" r="3" fill="%j"/><circle cx="20" cy="17" r="4" fill="%a"/><circle cx="28" cy="13" r="3" fill="%l"/><circle cx="35" cy="6" r="3" fill="%j"/><g fill="#FFF" opacity=".7"><circle cx="11" cy="12" r=".9"/><circle cx="19" cy="15" r="1"/><circle cx="27" cy="12" r=".9"/></g>',
		doubloon: '26 26|<circle cx="13" cy="13" r="12" fill="%a"/><circle cx="13" cy="13" r="12" fill="none" stroke="%f" stroke-width="2"/><circle cx="13" cy="13" r="8" fill="none" stroke="%f" stroke-width="1"/><path d="M13 7c-2 3-2 3 0 5 2-2 2-2 0-5Zm0 12c2-3 2-3 0-5-2 2-2 2 0 5Zm-6-6c3 2 3 2 5 0-2-2-2-2-5 0Zm12 0c-3-2-3-2-5 0 2 2 2 2 5 0Z" fill="%f"/>',
		mask: '36 26|<path d="M4 2Q1 -1 2 4q1 4 5 5Zm28 0q3-3 2 2-1 4-5 5Z" fill="%j"/><path d="M2 10q16-8 32 0 0 10-9 10-4 0-7-3-3 3-7 3-9 0-9-10Z" fill="%l"/><ellipse cx="11" cy="13" rx="4" ry="3" fill="#FFF"/><ellipse cx="25" cy="13" rx="4" ry="3" fill="#FFF"/><path d="M2 10q16-6 32 0" stroke="%a" stroke-width="1" fill="none"/>',
		stilts: '32 78|<path d="M11 46 L11 76" stroke="%i" stroke-width="3"/><path d="M21 46 L21 76" stroke="%i" stroke-width="3"/><path d="M7 47 L15 47 L15 50 L7 50 Z" fill="%f"/><path d="M17 47 L25 47 L25 50 L17 50 Z" fill="%f"/><path d="M16 3 L23 9 L20 11 L24 14 L16 17 L8 14 L12 11 L9 9 Z" fill="%l"/><circle cx="23.4" cy="8.6" r="1.8" fill="%a"/><circle cx="8.6" cy="8.6" r="1.8" fill="%a"/><circle cx="16" cy="21" r="4.2" fill="#F8D8B8"/><path d="M9 26 L23 26 L21 42 L11 42 Z" fill="%j"/><path d="M9 26 L1 34 L4 37 L11 30 Z" fill="%l"/><path d="M23 26 L31 34 L28 37 L21 30 Z" fill="%l"/><path d="M12 42 L15 42 L15 50 L12 50 Z" fill="%a"/><path d="M17 42 L20 42 L20 50 L17 50 Z" fill="%a"/>',
		bottle: '18 44|<path d="M7 2h4v8q5 4 5 12v18q0 3-3 3H5q-3 0-3-3V22q0-8 5-12Z" fill="#1E5B2B"/><path d="M7 2h4v6H7Z" fill="%f"/><rect x="4" y="24" width="10" height="10" rx="1" fill="%d"/>',
		/* — valentines — */
		balloon: '26 32|<path d="M13 2C6 2 2 7 2 12c0 7 7 12 11 15 4-3 11-8 11-15C24 7 20 2 13 2Z" fill="#FA5252"/><path d="M7 8q1-3 4-4" stroke="#FFC9C9" stroke-width="2" fill="none"/><path d="M12 27h3l-1 3Z" fill="%n"/>',
		letter0: '30 22|<rect x="1" y="1" width="28" height="20" rx="2" fill="#FFF0F3"/><rect x="1" y="1" width="28" height="20" rx="2" fill="none" stroke="%u" stroke-width="1"/><path d="M1 2l14 11L29 2" fill="none" stroke="%u" stroke-width="1"/><path d="M15 10c2-3 5-1 4 2-.6 2-4 3-4 3s-3-2-4-3c-1-3 2-4 4-2Z" fill="#FA5252"/>',
		letter1: '30 30|<path d="M1 10 15 1l14 9v18H1Z" fill="#FFDEEB"/><path d="M1 10l14 9 14-9" fill="none" stroke="%u" stroke-width="1"/><rect x="5" y="12" width="20" height="12" rx="1" fill="#FFF" stroke="%s"/><path d="M15 16c1-2 4-.8 3 1-.5 1-3 3-3 3s-3-2-3-3c-1-2 2-4 3-1Z" fill="#FA5252"/>',
		/* — presidents — */
		tophat: '32 28|<ellipse cx="16" cy="24" rx="15" ry="4" fill="%g"/><rect x="7" y="4" width="18" height="20" rx="2" fill="%b"/><rect x="7" y="16" width="18" height="4" fill="#B22234"/><path d="M14 17 16 15l2 2-.6 2h-2Z" fill="%d"/><ellipse cx="16" cy="5" rx="9" ry="2" fill="%g"/>',
		quill: '26 34|<path d="M22 2Q8 8 6 24l2 1Q12 10 24 4Z" fill="%d" stroke="#7C8894" stroke-width="1.8"/><path d="M22 2Q12 6 8 18q6-2 10-8 4-4 4-8Z" fill="%o"/><path d="M6 24 3 32l5-6Z" fill="%f"/>',
		cherry: '26 30|<path d="M13 2q-6 4-8 14m8-14q6 6 6 14" fill="none" stroke="%c" stroke-width="2"/><path d="M13 2q4-2 7 0-3 2-7 0Z" fill="%j"/><circle cx="5" cy="21" r="5" fill="%n"/><circle cx="19" cy="21" r="5" fill="%e"/><circle cx="3" cy="19" r="1" fill="#FFC9C9"/><circle cx="17" cy="19" r="1" fill="#FFC9C9"/>',
		/* — strawberry — */
		berry: '24 30|<path d="M12 3 12 8" stroke="%c" stroke-width="2"/><path d="M12 27C6 24 2.6 19 3 14 3.4 10 7 8 12 8 17 8 21 10 21 14 21 19 18 24 12 27Z" fill="%e"/><g fill="%j"><path d="M12 8 3.6 6 7 10Z"/><path d="M12 8 20 6 17 10Z"/><path d="M12 8 9 3.4 8.4 8.2Z"/><path d="M12 8 15 3.4 16 8.2Z"/></g><g fill="#FFE9A8"><circle cx="8" cy="13" r="1.1"/><circle cx="16" cy="13" r="1.1"/><circle cx="12" cy="16" r="1.1"/><circle cx="9" cy="19.6" r="1.1"/><circle cx="15" cy="19.6" r="1.1"/><circle cx="12" cy="22.6" r="1.1"/></g>',
		blossom: '24 24|<g fill="%d" stroke="#C97FA0" stroke-width="1.6"><circle cx="12" cy="5" r="4.4"/><circle cx="19" cy="10" r="4.4"/><circle cx="16.4" cy="18" r="4.4"/><circle cx="7.6" cy="18" r="4.4"/><circle cx="5" cy="10" r="4.4"/></g><circle cx="12" cy="12" r="3.4" fill="%k"/>',
		basket: '32 24|<path d="M6 8Q16 -4 26 8" fill="none" stroke="%p" stroke-width="2"/><path d="M2 8h28l-4 15H6Z" fill="#B08552"/><path d="M4 12h24m-23 5h22M9 8l3 15m8-15-3 15" stroke="%p" stroke-width="1" fill="none"/>',
		/* — st pat / april fools — */
		horseshoe: '30 30|<path d="M7.4 28C4.4 22 3 17 3.8 13 5 6.8 9.6 2.8 15 2.8 20 2.8 25 6.8 26 13 27 17 26 22 23 28L17 27C19 21 20 18 20 15 19 11 17 8.6 15 8.6 13 8.6 11 11 10 15 10 18 11 21 13 27Z" fill="#868E96"/><g fill="#39414A"><circle cx="7.6" cy="15.4" r="1.3"/><circle cx="8.4" cy="20" r="1.3"/><circle cx="9.8" cy="24.4" r="1.3"/><circle cx="22.4" cy="15.4" r="1.3"/><circle cx="21.6" cy="20" r="1.3"/><circle cx="20.2" cy="24.4" r="1.3"/></g>',
		rainbow: '96 62|<g fill="none" stroke-width="4"><path d="M5 60a40 40 0 0 1 80 0" stroke="%e"/><path d="M9 60a36 36 0 0 1 72 0" stroke="#FF922B"/><path d="M13 60a32 32 0 0 1 64 0" stroke="%k"/><path d="M17 60a28 28 0 0 1 56 0" stroke="%j"/><path d="M21 60a24 24 0 0 1 48 0" stroke="#5C7CFA"/></g><path d="M68 48h20l-3 10a7 7 0 0 1-7 4h-1a7 7 0 0 1-7-4Z" fill="%g"/><circle cx="73" cy="47" r="3" fill="%a"/><circle cx="79" cy="46" r="3" fill="%k"/><circle cx="85" cy="47" r="3" fill="%a"/><ellipse cx="64" cy="56" rx="7" ry="2" fill="#1E5B2B"/><path d="M60 50h8l-1 6h-6Z" fill="%c"/>',
		jester: '34 28|<path d="M5 22 2 4l10 10L17 2l5 12L32 4l-3 18Z" fill="%l"/><path d="M17 2l5 12 5-6-2 14H12l-2-14 5 6Z" fill="%j" opacity=".85"/><rect x="4" y="21" width="26" height="5" rx="3" fill="%a"/><circle cx="3" cy="4" r="2" fill="%a"/><circle cx="17" cy="3" r="2" fill="%a"/><circle cx="32" cy="4" r="2" fill="%a"/>',
		disguise: '34 26|<circle cx="9" cy="8" r="7" fill="none" stroke="%b" stroke-width="2"/><circle cx="25" cy="8" r="7" fill="none" stroke="%b" stroke-width="2"/><path d="M16 8h2" stroke="%b" stroke-width="2"/><path d="M0 6h3m28 0h3" stroke="%b" stroke-width="2"/><path d="M17 10q-5 4-4 9 2 4 6 2" fill="#F8C8A8" stroke="#D9A06B"/>',
		peel: '36 16|<path d="M18 8 Q11 4 5 5 Q9 9 16 10 Z" fill="#FFC107"/><path d="M17 9 Q9 11 2 14 Q9 16 16 12 Z" fill="%k"/><path d="M19 9 Q27 11 34 14 Q27 16 20 12 Z" fill="%k"/><path d="M18 10 Q19.4 14 17.6 15.6 Q15.2 14 16.4 10 Z" fill="#FFC107"/><ellipse cx="18" cy="9" rx="3.6" ry="2.6" fill="%k"/><path d="M4 4.4 L7 4.4 L6.4 6.4 L4.4 6.4 Z" fill="%i"/><path d="M8 8 Q13 10 16 10.6 M8 13.4 Q13 12.4 15.6 11.6 M28 13.4 Q23 12.4 20.4 11.6" stroke="#E0A800" stroke-width="0.9" fill="none"/>',
		/* — 420 / earth — */
		cannabis: '32 34|<g fill="%c" transform="translate(16 30)"><path id="cl" d="M0 0 1.5-5 .8-6 2.6-10 1.8-11 3-15 2-17 2.2-20 1-21 0-26-1-21-2.2-20-2-17-3-15-1.8-11-2.6-10-.8-6-1.5-5Z"/><use href="#cl" transform="rotate(27) scale(.9)"/><use href="#cl" transform="rotate(-27) scale(.9)"/><use href="#cl" transform="rotate(54) scale(.74)"/><use href="#cl" transform="rotate(-54) scale(.74)"/><use href="#cl" transform="rotate(79) scale(.54)"/><use href="#cl" transform="rotate(-79) scale(.54)"/></g><path d="M16 29v5" stroke="%c" stroke-width="2"/>',
		peace: '30 30|<circle cx="15" cy="15" r="13" fill="none" stroke="%l" stroke-width="3"/><circle cx="15" cy="15" r="13" fill="none" stroke="%j" stroke-width="3" stroke-dasharray="14 27"/><path d="M15 2v26M15 15 6 24m9-9 9 9" stroke="%u" stroke-width="3"/>',
		sprout: '22 26|<path d="M11 26V10" stroke="%c" stroke-width="2"/><path d="M11 12Q3 12 1 4q9-1 10 8Z" fill="#37B24D"/><path d="M11 9Q19 9 21 2q-9-1-10 7Z" fill="%j"/>',
		globe: '30 30|<circle cx="15" cy="15" r="13" fill="#339AF0"/><path d="M8 6q6 2 5 8t3 7q-8 1-10-6-1-6 2-9Zm12 1q4 3 4 8 0 6-5 9-2-5 0-9t1-8Z" fill="#37B24D"/>',
		hands: '44 32|<circle cx="22" cy="12" r="9.5" fill="#339AF0"/><path d="M15 7 Q20 9 19 13 Q18 17 21 18 Q15 19 13.6 14 Q12.8 10 15 7 Z" fill="%j"/><path d="M27 6 Q31 9 29 12 Q27 15 30 17 Q25 17 24.6 12 Q24.4 8 27 6 Z" fill="%j"/><path d="M2 31 Q1 21 9 18 Q14 16 19 20 L21 24 L14 31 Z" fill="#D9A06B"/><path d="M42 31 Q43 21 35 18 Q30 16 25 20 L23 24 L30 31 Z" fill="#D9A06B"/><path d="M8 20 L12 25 M12 18.6 L16 23.6 M36 20 L32 25 M32 18.6 L28 23.6" stroke="#B87F4E" stroke-width="0.9" fill="none"/>',
		/* — labor day picnic — */
		sparkler: '22 34|<path d="M11 33 L11 15" stroke="%h" stroke-width="2.2" stroke-linecap="round"/><path d="M11 13 L11 2 M11 13 L20 5 M11 13 L21 13 M11 13 L20 21 M11 13 L2 5 M11 13 L1 13 M11 13 L2 21" stroke="%a" stroke-width="1.6" stroke-linecap="round" fill="none"/><path d="M11 13 L15 3 M11 13 L7 3 M11 13 L19 9 M11 13 L3 9 M11 13 L18 18 M11 13 L4 18" stroke="%d" stroke-width="1.1" stroke-linecap="round" fill="none"/><circle cx="11" cy="13" r="2.6" fill="%d"/><circle cx="11" cy="13" r="1.4" fill="%a"/>',
		poppy: '26 30|<path d="M13 22 L13 29" stroke="%c" stroke-width="1.6"/><g fill="%e"><ellipse cx="8" cy="10" rx="6.4" ry="5.6" transform="rotate(-30 8 10)"/><ellipse cx="18" cy="10" rx="6.4" ry="5.6" transform="rotate(30 18 10)"/><ellipse cx="8" cy="17" rx="6.4" ry="5.6" transform="rotate(30 8 17)"/><ellipse cx="18" cy="17" rx="6.4" ry="5.6" transform="rotate(-30 18 17)"/></g><path d="M13 13 L7 8 M13 13 L19 8 M13 13 L7 19 M13 13 L19 19" stroke="#C92A2A" stroke-width="1.2" fill="none"/><circle cx="13" cy="13.4" r="3.4" fill="%g"/><circle cx="13" cy="13.4" r="1.4" fill="#495057"/>',
		tulip: '22 34|<path d="M11 33 L11 18" stroke="%c" stroke-width="1.8"/><path d="M11 30 Q3 28 2 20 Q8 22 11 27 Z" fill="%j"/><path d="M3 9 Q2 20 11 21 Q20 20 19 9 L15 13 L11 6 L7 13 Z" fill="%u"/><path d="M8 12 L11 6 L14 12 L14 20 Q11 21 8 20 Z" fill="%s"/>',
		necktie: '16 40|<clipPath id="nt"><path d="M8 9 L13 7 L14 30 L8 39 L2 30 L3 7 Z"/></clipPath><path d="M5 2 L11 2 L13 7 L8 9 L3 7 Z" fill="%n"/><path d="M8 9 L13 7 L14 30 L8 39 L2 30 L3 7 Z" fill="%e"/><g clip-path="url(#nt)"><path d="M0 15 L16 11 M0 23 L16 19 M0 31 L16 27" stroke="%m" stroke-width="2.4"/></g><path d="M8 9 L13 7 L14 30 L8 39 L2 30 L3 7 Z" fill="none" stroke="#8C1D1D" stroke-width="0.8"/>',
		medal: '22 34|<path d="M6 1 L16 1 L14 16 L8 16 Z" fill="%e"/><path d="M9 1 L13 1 L12.4 16 L9.6 16 Z" fill="%d"/><path d="M6 1 L8.4 1 L8.6 16 L8 16 Z M13.6 1 L16 1 L14 16 L13.4 16 Z" fill="%m"/><circle cx="11" cy="23.5" r="8.6" fill="%f"/><circle cx="11" cy="23.5" r="7" fill="%a"/><path d="M11 17.4 L12.8 21.2 L17 21.6 L13.8 24.4 L14.8 28.6 L11 26.4 L7.2 28.6 L8.2 24.4 L5 21.6 L9.2 21.2 Z" fill="%f"/>',
		sun: '34 34|<path d="M17 1.5 L17 6 M32.5 17 L28 17 M17 32.5 L17 28 M1.5 17 L6 17 M28 6 L24.8 9.2 M28 28 L24.8 24.8 M6 28 L9.2 24.8 M6 6 L9.2 9.2" stroke="%k" stroke-width="2.4" stroke-linecap="round" fill="none"/><circle cx="17" cy="17" r="9" fill="%r"/><circle cx="17" cy="17" r="7" fill="%k"/>',
		watermelon: '34 22|<path d="M1 3 A16 16 0 0 1 33 3 L17 21 Z" fill="%c"/><path d="M3.6 3.6 A13.4 13.4 0 0 1 30.4 3.6 L17 19 Z" fill="%d"/><path d="M5.6 4 A11.4 11.4 0 0 1 28.4 4 L17 17 Z" fill="#FA5252"/><g fill="%g"><ellipse cx="12" cy="7.6" rx="1.1" ry="1.8" transform="rotate(20 12 7.6)"/><ellipse cx="22" cy="7.6" rx="1.1" ry="1.8" transform="rotate(-20 22 7.6)"/><ellipse cx="17" cy="11" rx="1.1" ry="1.8"/><ellipse cx="13.6" cy="12.6" rx="1" ry="1.6" transform="rotate(25 13.6 12.6)"/></g>',
		flipflop: '18 34|<path d="M9 1 Q17 1 17 12 L16 26 Q15 33 9 33 Q3 33 2 26 L1 12 Q1 1 9 1 Z" fill="%k"/><path d="M9 3 Q15 3 15 12 L14 25 Q13.4 31 9 31 Q4.6 31 4 25 L3 12 Q3 3 9 3 Z" fill="#FFE066"/><path d="M9 11 L3.4 19 M9 11 L14.6 19" stroke="%u" stroke-width="2.2" stroke-linecap="round" fill="none"/><circle cx="9" cy="10.6" r="1.6" fill="%u"/>',
		icecream: '22 36|<path d="M3 16 L11 35 L19 16 Z" fill="%w"/><path d="M5 18 L17 18 M6.4 22 L15.6 22 M8 26 L14 26 M9.4 30 L12.6 30 M6 16 L13 30 M16 16 L9 30" stroke="#B8690C" stroke-width="0.9" fill="none"/><circle cx="11" cy="12.4" r="7.2" fill="%s"/><circle cx="11" cy="7.4" r="6" fill="%d"/><circle cx="8.6" cy="5.6" r="1.4" fill="%e"/>',
		grill: '30 32|<path d="M2 8h26q0 9-13 9T2 8Z" fill="%g"/><path d="M2 8h26q0 3-13 3T2 8Z" fill="%b"/><line x1="9" y1="16" x2="6" y2="30" stroke="%h" stroke-width="2"/><line x1="21" y1="16" x2="24" y2="30" stroke="%h" stroke-width="2"/><circle cx="24" cy="30" r="2" fill="%h"/>',
		cooler: '28 24|<rect x="2" y="8" width="24" height="15" rx="2" fill="%m"/><rect x="1" y="5" width="26" height="5" rx="2" fill="#4DABF7"/><path d="M8 5V2m5 3V1m5 4V2" stroke="%p" stroke-width="2"/><rect x="11" y="14" width="6" height="3" rx="1" fill="%d"/>'
	};

	var PAL = {"a":"#F1C40F","b":"#343A40","c":"#2B8A3E","d":"#F1F3F5","e":"#E03131","f":"#B8860B","g":"#212529","h":"#495057","i":"#6F4E37","j":"#2F9E44","k":"#FFD43B","l":"#7C3AED","m":"#1864AB","n":"#C92A2A","o":"#DEE2E6","p":"#8B5A2B","q":"#E9ECEF","r":"#E8590C","s":"#F783AC","t":"#ADB5BD","u":"#E64980","v":"#4A6B8A","w":"#E8890C","x":"#2C3E50"};
	function svgDoc(raw) {
		if (typeof raw === 'function') { raw = raw(); }
		var cut = raw.indexOf('|');
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + raw.slice(0, cut) + '">' +
			raw.slice(cut + 1).replace(/%([a-x])/g, function (m2, k) { return PAL[k]; }) + '</svg>';
	}
	var sprites = {};
	function sprite(name) {
		var s = sprites[name];
		if (s) { return s; }
		s = { ready: false, img: new Image(), ratio: 1 };
		s.img.onload = function () {
			s.ratio = (s.img.naturalHeight || 1) / (s.img.naturalWidth || 1);
			s.ready = true;
		};
		s.img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgDoc(SVGS[name] || '0 0|'));
		sprites[name] = s;
		return s;
	}

	/* ---------- Emoji tofu check ---------- */
	var tcx = null;
	function drawable(g) {
		try {
			if (!tcx) {
				var tcv = D.createElement('canvas');
				tcv.width = tcv.height = 24;
				tcx = tcv.getContext('2d', { willReadFrequently: true });
			}
			tcx.clearRect(0, 0, 24, 24);
			tcx.font = 20 + FT;
			tcx.fillText(g, 2, 18);
			var d = tcx.getImageData(0, 0, 24, 24).data;
			for (var j = 3; j < d.length; j += 4) { if (d[j]) { return true; } }
			return false;
		} catch (e) { return true; }
	}

	/* ---------- Canvas primitives (recolorable where emoji/SVG can't) ---------- */
	function drawStar(cx, r, color) {
		cx.fillStyle = color;
		cx.beginPath();
		for (var i = 0; i < 10; i++) {
			var rr = i % 2 ? r * 0.42 : r;
			var a = -MT.PI / 2 + i * MT.PI / 5;
			cx[i ? 'lineTo' : 'moveTo'](cos(a) * rr, sin(a) * rr);
		}
		cx.closePath();
		cx.fill();
		/* crisp inner facet line */
		cx.globalAlpha *= 0.5;
		cx.strokeStyle = '#00000033';
		cx.lineWidth = 1;
		cx.stroke();
		cx.globalAlpha *= 2;
	}
	var PRIMS = {
		star: function (cx, p, s) { drawStar(cx, p.size * 0.45 * s, p.color); },
		confetti: function (cx, p, s, t) {
			/* metallic shimmer: alternate a lighter tint every ~200ms */
			cx.fillStyle = (((t / 200) | 0) + (p.shim || 0)) % 2 ? p.color : '#FFFFFF';
			if (cx.fillStyle === '#FFFFFF') { cx.globalAlpha *= 0.8; }
			cx.fillRect(-p.size * 0.42 * s, -p.size * 0.17 * s, p.size * 0.84 * s, p.size * 0.34 * s);
		},
		bubble: function (cx, p, s) {
			cx.strokeStyle = p.color;
			cx.lineWidth = 1.8;
			cx.beginPath();
			cx.arc(0, 0, p.size * 0.26 * s, 0, TAU);
			cx.stroke();
		},
		egg: function (cx, p, s) {
			var rx = p.size * 0.37 * s, ry = p.size * 0.48 * s;
			cx.save();
			cx.beginPath();
			cx.ellipse(0, 0, rx, ry, 0, 0, TAU);
			cx.fillStyle = p.color;
			cx.fill();
			cx.clip();
			cx.fillStyle = p.color2;
			if (p.deco) {
				for (var i = 0; i < 5; i++) {
					cx.beginPath();
					cx.arc((i % 3 - 1) * rx * 0.7, ((i / 3 | 0) - 0.5) * ry * 0.8, rx * 0.16, 0, TAU);
					cx.fill();
				}
			} else {
				cx.fillRect(-rx, -ry * 0.45, rx * 2, ry * 0.22);
				cx.fillRect(-rx, ry * 0.15, rx * 2, ry * 0.22);
			}
			cx.restore();
		},
		heart: function (cx, p, s) {
			var r = p.size * 0.34 * s;
			cx.fillStyle = p.color;
			cx.beginPath();
			cx.moveTo(0, r);
			cx.bezierCurveTo(-r * 1.6, -r * 0.35, -r * 0.62, -r * 1.4, 0, -r * 0.45);
			cx.bezierCurveTo(r * 0.62, -r * 1.4, r * 1.6, -r * 0.35, 0, r);
			cx.fill();
		},
		tulip: function (cx, p, s) {
			var r = p.size * 0.32 * s;
			cx.fillStyle = p.color;
			cx.beginPath();
			cx.moveTo(-r, -r * 0.4);
			cx.quadraticCurveTo(-r, r, 0, r);
			cx.quadraticCurveTo(r, r, r, -r * 0.4);
			cx.lineTo(r * 0.45, r * 0.1);
			cx.lineTo(0, -r * 0.5);
			cx.lineTo(-r * 0.45, r * 0.1);
			cx.closePath();
			cx.fill();
			cx.strokeStyle = '#2B8A3E';
			cx.lineWidth = 1.6;
			cx.beginPath();
			cx.moveTo(0, r);
			cx.lineTo(0, r * 2.4);
			cx.stroke();
		},
	};

	/* The behaviours that are placed in free air and nowhere in particular:
	 * the guardrail spreads them at seed time and the anti-clump keeps them
	 * apart afterwards. Everything else is staged on purpose — water-line
	 * riders, growers, off-screen entrances, the hero — and is left alone. */
	var FREEAIR = ' fall sway tumble spin wobble jump flutter rise pulse orbit dangle hang dart twinkle firefly ';

	/* ================= Engine ================= */
	function start(boot) {
		var CFG = boot.cfg || {};
		var theme = boot.theme;
		var themeKey = boot.themeKey || 'florida_keys';
		var A = (theme && theme.ambient) || { particles: [] };
		var mq = boot.mq;
		var reduced = function () { return !!(mq && mq.matches); };
		if (reduced()) { return; }

		var water = !!A.water;
		var up = !!A.up;
		var burstMode = A.mode === 'burst';
		var alphaBase = clamp(CFG.opacity || 0.35, 0.05, 1);
		var maxTotal = clamp(CFG.density || 10, 1, 16); /* hard cap incl. ripples */
		var reserve = water ? 3 : 0;
		var maxParts = mx2(1, mn(maxTotal - reserve, A.max || 99));
		var heroEvery = CFG.heroEvery || [120, 180];
		var DEBUG = DBG && !!CFG.debug;

		/* Visual richness + advanced toggles. Classic = v2 behavior;
		 * Minimal = sprites only. Solemn themes never get the playful set. */
		var V = CFG.visual || {};
		var rich = V.richness || 'full';
		var mobile = W.innerWidth < 768;
		var FX = {
			parallax: rich === 'full',
			reflect: rich === 'full' && V.reflections !== false && !mobile && water,
			vig: rich === 'full' && V.vignettes !== false,
			pointer: rich === 'full' && V.pointer !== false,
			evening: rich === 'full' && V.evening !== false,
			snow: rich === 'full' && V.snow !== false && themeKey === 'christmas',
			heroes: rich !== 'minimal'
		};

		/* Evening: 19:00–06:00 by the visitor's clock (mockable in tests). */
		function localNow() {
			return (DEBUG && CFG.forceNow != null) ? new Date(CFG.forceNow) : new Date();
		}
		var hour = (DEBUG && CFG.forceHour != null) ? CFG.forceHour : localNow().getHours();
		var evening = FX.evening && (hour >= 19 || hour < 6);

		/* Static corner accents (DOM, no motion, no assets). */
		var ACCENTS = {
			halloween: ['web', 'right:0;top:0;width:64px;opacity:.5;'],
			thanksgiving: ['cornucopia', 'left:10px;bottom:10px;width:56px;opacity:.55;'],
			snowbird: ['sunshades', 'left:12px;top:12px;width:44px;opacity:.5;'],
			earth_day: ['hands', 'left:10px;bottom:10px;width:52px;opacity:.55;'],
			summer_canal: ['sun', 'right:12px;top:12px;width:54px;opacity:.5;']
		};
		/* Accents are built here but mounted with the canvas below, so they
		 * follow the layering setting: through 3.6.2 they sat on the body at
		 * z-index 99990 in EVERY mode, floating over text and widgets even
		 * when the owner had chosen "behind". */
		var accents = [];
		function accentEl(key, css) {
			if (!SVGS[key]) { return; }
			var el = D.createElement('div');
			el.setAttribute('aria-hidden', 'true');
			el.className = 'dcc-seasons-accent';
			el.style.cssText = 'position:fixed;pointer-events:none;' + css;
			el.innerHTML = svgDoc(SVGS[key]);
			accents.push(el);
		}
		if (A.accent && A.accent.svg) { accentEl(A.accent.svg, 'left:14px;bottom:14px;width:26px;opacity:.6;'); }
		if (rich === 'full' && ACCENTS[themeKey]) { accentEl(ACCENTS[themeKey][0], ACCENTS[themeKey][1]); }

		var cv = D.createElement('canvas');
		cv.setAttribute('aria-hidden', 'true');
		cv.className = 'dcc-seasons-canvas';

		/* --- Where the canvas is MOUNTED decides whether "behind" works. ---
		 *
		 * "In front of everything": body, z-index 99990. Untouched.
		 *
		 * "Behind": mounting on the body cannot express it. The theme's
		 * content column (Bravada/cryout: main.main) is position:relative
		 * with z-index:9 AND an opaque white background, so it establishes a
		 * stacking context and paints over any body-level canvas below 9 —
		 * and going above 9 is just "front" again. There is no body-level
		 * z-index that lands BETWEEN that white background and the text on
		 * top of it, which is what "behind" means.
		 *
		 * So the canvas is mounted INSIDE that element with z-index:-1. Per
		 * the CSS painting order a negative-z-index positioned descendant
		 * paints after its stacking context's own background and border but
		 * before that context's in-flow content: above the white, below
		 * every piece of text, image and widget. It needs no cooperation
		 * from individual widgets at all.
		 *
		 * It stays position:fixed, so it is still a non-scrolling backdrop
		 * and still covers the viewport outside the host (the coloured page
		 * margins). A fixed element's containing block is the viewport, so
		 * the host's overflow:hidden does not clip it — unless the host or
		 * an ancestor has a transform/filter/perspective, which WOULD make
		 * it the containing block. Rather than enumerate those properties,
		 * the mount is verified below by measuring the canvas. --- */
		/* --- Choosing the element to mount inside, on a real theme. -------
		 *
		 * Measured on the live site (Bravada/Cryout), the content chain is:
		 *
		 *   div#content.cryout   transparent, 0px wide
		 *     main#main.main     WHITE, position:relative z-index:9, no transform
		 *       article#post-620 WHITE, but carries translateZ(-0.001px)
		 *         div.entry-content  transparent, 0px wide
		 *
		 * Three traps in that, all of which this code now handles:
		 *
		 *  1. The DEEPEST anchor (.entry-content) is transparent and ZERO
		 *     WIDTH — Elementor breaks out of the theme wrappers, so they
		 *     collapse. A deepest-first walk that only asks "opaque?" can
		 *     land on an invisible, zero-area host.
		 *  2. article carries a non-identity 3D transform, which makes it the
		 *     containing block for position:fixed descendants. Mounting there
		 *     turns the fixed backdrop into an article-sized box that scrolls
		 *     and clips — the same trap the availability calendar's popup hit
		 *     before it portalled to <body>.
		 *  3. Only a POSITIONED element with a numeric z-index above the
		 *     body-mount z-index can actually cover a body-level canvas. A
		 *     stacking context made by transform or opacity alone paints in
		 *     the z-index:auto step, i.e. BELOW a fixed z-index:5 element, so
		 *     it is not what is hiding the particles and must not outrank the
		 *     element that is. main#main.main (z-index 9) is the real one.
		 * ------------------------------------------------------------------ */
		var BODY_Z = 5; /* z-index used when the canvas falls back to <body> */

		function alphaOf(cs) {
			if (cs.backgroundImage && cs.backgroundImage !== 'none') { return 1; }
			var m = /^rgba?\(([^)]+)\)/.exec(cs.backgroundColor || '');
			if (!m) { return 0; }
			var parts2 = m[1].split(',');
			return parts2.length < 4 ? 1 : parseFloat(parts2[3]) || 0;
		}
		/* Painted enough to hide anything behind it. Not literally alpha > 0:
		 * a 2% wash is not what is covering the particles, and treating it as
		 * a host would mount the canvas UNDER a background that never
		 * occluded it. */
		function paintsOpaque(el) { return alphaOf(W.getComputedStyle(el)) > 0.05; }

		function rectOf(el) { return el.getBoundingClientRect(); }
		function hasArea(el) {
			var r = rectOf(el);
			return r.width >= 1 && r.height >= 1;
		}
		/* Does this element establish the containing block for fixed
		 * descendants? Anything here makes `position:fixed` resolve against
		 * the element instead of the viewport. */
		function fixesDescendants(el) {
			var cs = W.getComputedStyle(el);
			if (cs.transform && cs.transform !== 'none') { return true; }
			if (cs.perspective && cs.perspective !== 'none') { return true; }
			if (cs.filter && cs.filter !== 'none') { return true; }
			if (cs.backdropFilter && cs.backdropFilter !== 'none') { return true; }
			if (cs.willChange && /transform|perspective|filter/.test(cs.willChange)) { return true; }
			if (cs.contain && /paint|layout|strict|content/.test(cs.contain)) { return true; }
			if (cs.containerType && cs.containerType !== 'normal') { return true; }
			return false;
		}
		function trapped(el) {
			for (var n = el; n && n.nodeType === 1; n = n.parentElement) {
				if (fixesDescendants(n)) { return true; }
			}
			return false;
		}
		/* Tier 1: can actually cover a body-level canvas (see note 3 above). */
		function occluder(el) {
			var cs = W.getComputedStyle(el);
			var z = parseInt(cs.zIndex, 10);
			return cs.position !== 'static' && !isNaN(z) && z > BODY_Z;
		}
		/* Tier 2: makes a stacking context some other way. Kept as a safety
		 * net for themes where the reasoning above doesn't hold; never tried
		 * before a tier-1 candidate. */
		function stacks(el) {
			var cs = W.getComputedStyle(el);
			if (cs.position !== 'static' && cs.zIndex !== 'auto') { return true; }
			if (parseFloat(cs.opacity) < 1) { return true; }
			if (cs.isolation === 'isolate') { return true; }
			if (cs.mixBlendMode && cs.mixBlendMode !== 'normal') { return true; }
			return fixesDescendants(el);
		}
		/* Being inside a transform does NOT disqualify a host — it only rules
		 * out a position:fixed canvas there, and mountIn() has a sticky mode
		 * for exactly that. Abandoning such a column to the body mount would
		 * leave "behind" broken on any theme that uses a translateZ hack. */
		function viable(el) {
			return paintsOpaque(el) && hasArea(el);
		}
		function depth(el) {
			var n = 0;
			while ((el = el.parentElement)) { n++; }
			return n;
		}
		function pathOf(el) {
			if (!el || el.nodeType !== 1) { return String(el); }
			return el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') +
				(el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.') : '');
		}

		/* Candidate hosts: the filter's selector first, then tier 1 deepest
		 * first, then tier 2 deepest first. Anchors are walked from EVERY
		 * match, not just the first in document order — a wrapper like
		 * #content encloses the real column, and walking up from an ancestor
		 * can never reach what is inside it. */
		function backdropHosts() {
			var out = [], el, i;
			if (CFG.backdropHost) {
				try { el = D.querySelector(CFG.backdropHost); } catch (e) { el = null; }
				if (el && el !== D.body) { out.push(el); }
			}
			var anchors = D.querySelectorAll('main, [role="main"], #main, #content, .site-content, .site-main, article, .entry-content');
			var t1 = [], t2 = [], seen = [];
			for (i = 0; i < anchors.length; i++) {
				for (el = anchors[i]; el && el.nodeType === 1 && el !== D.body; el = el.parentElement) {
					if (seen.indexOf(el) >= 0) { continue; }
					seen.push(el);
					if (!viable(el)) { continue; }
					if (occluder(el)) { t1.push(el); } else if (stacks(el)) { t2.push(el); }
				}
			}
			var byDepth = function (a, b) { return depth(b) - depth(a); };
			t1.sort(byDepth);
			t2.sort(byDepth);
			for (i = 0; i < t1.length; i++) { if (out.indexOf(t1[i]) < 0) { out.push(t1[i]); } }
			for (i = 0; i < t2.length; i++) { if (out.indexOf(t2[i]) < 0) { out.push(t2[i]); } }
			return out;
		}
		/* --- Footer placement. -----------------------------------------
		 * "It basically only appears over my About Us text, which blocks
		 * exactly the type of stuff I want guests to be able to read easily."
		 * Decoration must not sit on body copy, so the default placement
		 * mounts the canvas INSIDE the site footer and draws nothing outside
		 * it. The canvas is absolutely positioned to the footer's padding box,
		 * which takes no flow space — the footer's own height cannot change.
		 * If the theme has no footer, nothing renders: falling back into the
		 * content would be the one outcome the setting exists to prevent. */
		/* A page cached before the upgrade carries a config with no placement
		 * key. Default it to footer, not to the old whole-column backdrop:
		 * the safe direction is the one that cannot cover body copy. */
		var footMode = (CFG.placement || 'footer') === 'footer';
		function footerHosts() {
			var out = [], i, el, list;
			/* The selector comes from the config so the loader and the engine
			 * cannot disagree about what a footer is; the constant is only for
			 * a page cached before the key existed. */
			var sel = CFG.footerSel || CFG.footerHost ||
				'footer#colophon, #colophon, footer.site-footer, .site-footer, footer[role="contentinfo"], #footer, footer';
			try { list = D.querySelectorAll(sel); } catch (e2) { list = []; }
			for (i = 0; i < list.length; i++) {
				el = list[i];
				/* A footer inside an article is a post footer, not the site's. */
				if (el.closest && el.closest('article')) { continue; }
				if (!hasArea(el) || rectOf(el).height < 40) { continue; }
				if (out.indexOf(el) < 0) { out.push(el); }
			}
			return out;
		}
		var footRO = null;
		function footWatch(el) {
			if (footRO) { footRO.disconnect(); footRO = null; }
			if (el && W.ResizeObserver) {
				footRO = new W.ResizeObserver(function () { queueSize(); });
				footRO.observe(el);
			}
		}
		function mountOnBody(z) {
			cv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:' + z + ';';
			D.body.appendChild(cv);
		}
		/* Mount and MEASURE. Two modes:
		 *
		 *  'fixed'  — the normal one. The canvas must come out as the
		 *             viewport, not merely at-least-viewport-sized: a tall
		 *             transformed ancestor would satisfy a ">=" test while
		 *             actually producing a box that scrolls with the page and
		 *             is clipped by its overflow.
		 *
		 *  'sticky' — for a host inside a transformed subtree, where
		 *             position:fixed resolves against that ancestor instead
		 *             of the viewport and is unusable. A sticky FIRST child
		 *             with a negative bottom margin takes no layout space,
		 *             stays viewport-tall, and follows the scroll through the
		 *             host — so the particles ride the content column instead
		 *             of the window. This is the only way to express "behind"
		 *             under a transform, and Bravada puts a translateZ() hack
		 *             on its article element.
		 */
		/* A sticky canvas is viewport-tall, which is right for a column
		 * taller than the window and wrong for a short one: 100vh inside a
		 * 287px column overflows it and lengthens the page, which is a
		 * layout change this plugin promises never to make. Fit it to
		 * whichever is smaller, and keep it fitted as the column grows —
		 * lazy images and late content change that height without a resize
		 * event, and a backdrop that stops short of the fold is worse than
		 * the scroll it saves. */
		var stickyHost = null, stickyRO = null, stickyPad = 0, stickyH = 0;
		function stickyWatch(el) {
			if (stickyRO) { stickyRO.disconnect(); stickyRO = null; }
			stickyHost = el;
		}
		/* The SMALL viewport height: what the window is with the browser's own
		 * chrome SHOWING. Unlike innerHeight it does not move when the iOS URL
		 * bar collapses on scroll — and innerHeight moving is why the canvas
		 * was resized, and the whole scene re-seeded, on nearly every swipe.
		 * Measured once from a probe rather than assumed, which doubles as the
		 * feature test: where 100svh is not supported the probe has no height
		 * and innerHeight is used instead. */
		var svhCache = 0;
		function svhPx() {
			if (svhCache) { return svhCache; }
			var d = D.createElement('div');
			d.style.cssText = 'position:absolute;top:0;left:0;width:0;height:100svh;visibility:hidden;pointer-events:none;';
			D.body.appendChild(d);
			svhCache = MT.round(d.getBoundingClientRect().height) || W.innerHeight;
			D.body.removeChild(d);
			return svhCache;
		}
		function stickyFit() {
			if (!stickyHost) { return; }
			var h = mx2(1, MT.round(mn(svhPx(), mx2(rectOf(stickyHost).height, 1))));
			stickyH = h;
			cv.style.cssText = 'position:sticky;display:block;top:0;left:0;width:100%;height:' + h +
				'px;margin-bottom:-' + (h + stickyPad) + 'px;pointer-events:none;z-index:-1;';
			if (!stickyRO && W.ResizeObserver) {
				stickyRO = new W.ResizeObserver(function () { stickyFit(); queueSize(); });
				stickyRO.observe(stickyHost);
			}
		}
		/* height + margin-bottom cancel the canvas's OWN flow height, and that
		 * is not the whole story: inserting a block as the host's first child
		 * also stops the previous first child's top margin from collapsing
		 * through the host, and that recovered margin is real page height —
		 * exactly 50px on the live site, which the assertion below now
		 * catches. Measure it instead of guessing at it: how much taller is
		 * the document with the canvas than without? Whatever the answer,
		 * take it off the negative margin. Self-correcting, so it survives
		 * margin collapse, a lazy-image reflow, and themes never seen. */
		function stickyBalance() {
			if (!stickyHost || !cv.parentNode) { return 0; }
			/* Take the no-canvas baseline ONCE and compare every round against
			 * it. Toggling display:none repeatedly perturbs the very page it
			 * is measuring — measured on the live site, the first toggle of a
			 * page load reads the true delta and a second or third reads ~36px
			 * of residue, which looks exactly like a regression that is not
			 * there. One toggle, then arithmetic. */
			cv.style.display = 'none';
			var base = D.documentElement.scrollHeight;
			cv.style.display = 'block';
			var d = 0;
			for (var i = 0; i < 3; i++) {
				d = D.documentElement.scrollHeight - base;
				if (!d) { break; }
				stickyPad += d;
				stickyFit();
			}
			return d;
		}
		function mountIn(el, mode) {
			/* z-index:-1 resolves inside the nearest ANCESTOR stacking
			 * context, not inside the element it is written on. Mount into an
			 * element that isn't one and the canvas lands behind that
			 * element's own background — invisible, the very failure this is
			 * meant to fix. `isolation:isolate` makes the host a stacking
			 * context and changes nothing visually. */
			if (!stacks(el)) {
				el.style.isolation = 'isolate';
				diag.notes.push('isolation:isolate applied to ' + pathOf(el) + ' so z-index:-1 resolves inside it');
			}
			if (mode === 'footer') {
				/* Absolute against the footer's padding box: no flow space, so
				 * no layout shift. display:block for the same reason a sticky
				 * canvas needs it — an inline canvas sits on a text baseline. */
				stickyWatch(null);
				if (W.getComputedStyle(el).position === 'static') { el.style.position = 'relative'; }
				/* width/height 100% are NOT redundant next to inset:0. A canvas
				 * is a REPLACED element, and an absolutely positioned replaced
				 * element with width:auto takes its INTRINSIC size (300x150) —
				 * the insets are then over-constrained and ignored. Without
				 * these two the mount is rejected and nothing renders. */
				cv.style.cssText = 'position:absolute;display:block;inset:0;width:100%;height:100%;pointer-events:none;z-index:-1;';
				el.insertBefore(cv, el.firstChild);
				footWatch(el);
			} else if (mode === 'sticky') {
				/* display:block matters: a canvas is inline by default, so it would
				 * sit on a text baseline and add descender space — a layout
				 * shift, which this plugin promises never to cause. */
				stickyWatch(el);
				stickyFit();
				el.insertBefore(cv, el.firstChild);
			} else {
				/* Leaving sticky behind: a stale observer would re-apply the
				 * sticky geometry over this one the next time the old host
				 * resized. */
				stickyWatch(null);
				cv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:-1;';
				el.appendChild(cv);
			}
			var r = cv.getBoundingClientRect();
			var ok;
			if (mode === 'footer') {
				/* Did the canvas get the footer's box? Same question the sticky
				 * acceptance asks: what the canvas GOT, not what the host is
				 * now. */
				ok = r.width >= 1 && MT.abs(r.width - el.clientWidth) <= 2 && r.height >= 40;
			} else if (mode === 'sticky') {
				/* width:100% resolves against the host's CONTENT box, so a
				 * padded column legitimately yields a narrower canvas —
				 * comparing against the border box rejected every padded
				 * host on a narrow viewport. Compare like for like. */
				var hcs = W.getComputedStyle(el);
				var inner = el.clientWidth - (parseFloat(hcs.paddingLeft) || 0) - (parseFloat(hcs.paddingRight) || 0);
				/* Ask whether the canvas GOT the geometry it was given, not
				 * whether it matches the host now: inserting it can change the
				 * host's own height (it un-collapses the next element's top
				 * margin), and comparing a pre-insertion fit against a
				 * post-insertion host rejected a perfectly good mount — 23px
				 * of canvas against a host that had just grown to 38px.
				 * Whether the host is short is the fit's business, below. */
				ok = r.width >= 1 && r.width >= mx2(inner, 1) - 2 && r.height >= mx2(stickyH - 1, 1);
			} else {
				ok = MT.abs(r.width - W.innerWidth) <= 2 && MT.abs(r.height - W.innerHeight) <= 2 &&
					MT.abs(r.top) <= 2 && MT.abs(r.left) <= 2;
			}
			if (ok) {
				/* Re-fit once: the host's height may have changed by the very
				 * act of inserting the canvas. The ResizeObserver keeps it in
				 * step from here. */
				if (mode === 'sticky') { stickyFit(); }
				return true;
			}
			el.removeChild(cv);
			return false;
		}
		function tryHost(el) { return mountIn(el, 'fixed'); }

		/* What is actually painting at a point — the first element at or
		 * above it with a real background. Used to verify the mount: a
		 * painter that is a DESCENDANT of the host sits above the canvas and
		 * is hiding it; the host itself or an ancestor sits below it. */
		function painterAt(x, y) {
			var el = D.elementFromPoint(x, y);
			for (; el && el.nodeType === 1 && el !== D.documentElement; el = el.parentElement) {
				if (paintsOpaque(el)) { return el; }
			}
			return null;
		}
		/* THE post-condition: with the canvas where it is now, does anything
		 * paint OVER it? For a grid of points inside the canvas's own visible
		 * box, find the first element that paints something; if that element
		 * is a DESCENDANT of the canvas's parent it is above the canvas in
		 * paint order and is hiding it. The host itself, or anything above
		 * the host, is below the canvas — that is the good case.
		 *
		 * Hit-testing, not pixel sampling, on purpose. elementFromPoint is
		 * layout, so this is valid in a headless browser whose
		 * visibilityState pauses requestAnimationFrame — the state that made
		 * the last round of measurements meaningless.
		 */
		function coverage() {
			var host = cv.parentElement;
			var out = { measurable: false, reach: 1, cover: null, coverN: 0, total: 0, distinct: 0 };
			if (!host) { return out; }
			/* Only the part of the canvas that is ON SCREEN can be sampled:
			 * elementFromPoint outside the viewport returns null, which says
			 * nothing at all about what paints there. An unmeasurable sample
			 * must never be reported as a covered one — it was, and it made
			 * the engine warn "100% of it is painted over by the theme" about
			 * a backdrop that was working perfectly. */
			var r = cv.getBoundingClientRect();
			var x0 = mx2(r.left, 0), y0 = mx2(r.top, 0);
			var x1 = mn(r.right, W.innerWidth), y1 = mn(r.bottom, W.innerHeight);
			if (x1 - x0 < 8 || y1 - y0 < 8) { return out; }
			var els = [], counts = [], seen = 0, open = 0, i, j, k, p2, x, y;
			for (i = 1; i <= 6; i++) {
				for (j = 1; j <= 6; j++) {
					x = x0 + (x1 - x0) * i / 7;
					y = y0 + (y1 - y0) * j / 7;
					if (x < 0 || y < 0 || x >= W.innerWidth || y >= W.innerHeight) { continue; }
					p2 = painterAt(x, y);
					seen++;
					/* The question is what PAINTS here, not what is topmost:
					 * a working backdrop at z-index:-1 is by design never the
					 * topmost element anywhere content exists. painterAt walks
					 * up to the first element with an opaque background, and
					 * only a DESCENDANT of the host paints above the canvas. */
					if (!p2 || p2 === cv || p2 === host || !host.contains(p2)) { open++; continue; }
					k = els.indexOf(p2);
					if (k < 0) { els.push(p2); counts.push(1); } else { counts[k]++; }
				}
			}
			if (seen < 4) { return out; }
			var best = null, bestN = 0;
			for (i = 0; i < els.length; i++) { if (counts[i] > bestN) { bestN = counts[i]; best = els[i]; } }
			return { measurable: true, reach: open / seen, cover: best, coverN: bestN, total: seen, distinct: els.length };
		}

		/* When the covering element cannot hold the canvas, take its
		 * background colour OFF it and paint that colour on the canvas
		 * instead, over exactly that element's box, every frame. The page
		 * looks identical and the canvas is no longer covered. Only a plain,
		 * fully opaque colour can move this way — an image or a gradient
		 * cannot be faked, so those are left alone and reported. */
		var bgFills = [];
		/* Asked twice: once by the descend decision, which needs to know what
		 * STAYING would be worth, and once by the transfer itself. */
		function canTransfer(el) {
			if (!el || el === cv || bgFills.length >= 3) { return false; }
			var cs2 = W.getComputedStyle(el);
			if (cs2.backgroundImage !== 'none' || alphaOf(cs2) < 0.95) { return false; }
			for (var i = 0; i < bgFills.length; i++) { if (bgFills[i].el === el) { return false; } }
			return true;
		}
		function transferBg(el) {
			if (!canTransfer(el)) { return false; }
			var cs2 = W.getComputedStyle(el);
			/* getComputedStyle returns a LIVE declaration, so read the colour
			 * out before clearing it — reading after gives 'transparent'. */
			var col = cs2.backgroundColor;
			bgFills.push({ el: el, color: col });
			el.style.backgroundColor = 'transparent';
			diag.notes.push('background ' + col + ' moved onto the canvas from ' + pathOf(el));
			return true;
		}
		function drawBgFills() {
			if (!bgFills.length) { return; }
			var cr = cv.getBoundingClientRect(), i, r2;
			for (i = 0; i < bgFills.length; i++) {
				r2 = bgFills[i].el.getBoundingClientRect();
				if (r2.width < 1 || r2.height < 1) { continue; }
				cx.fillStyle = bgFills[i].color;
				cx.fillRect(r2.left - cr.left, r2.top - cr.top, r2.width, r2.height);
			}
		}
		function samplePainters() {
			var counts = [], els = [], i, j, x, y, p, best = null, bestN = 0, total = 0;
			for (i = 1; i <= 4; i++) {
				for (j = 1; j <= 4; j++) {
					x = W.innerWidth * i / 5;
					y = W.innerHeight * j / 5;
					p = painterAt(x, y);
					total++;
					if (!p) { continue; }
					var k = els.indexOf(p);
					if (k < 0) { els.push(p); counts.push(1); k = els.length - 1; } else { counts[k]++; }
					if (counts[k] > bestN) { bestN = counts[k]; best = p; }
				}
			}
			var hits = 0;
			for (i = 0; i < counts.length; i++) { hits += counts[i]; }
			return { el: best, n: bestN, total: total, hits: hits, distinct: els.length };
		}
		var host = null, hostMode = 'fixed', cand = [], diag = { tried: [], notes: [] };
		function desc(el) {
			if (!el || el.nodeType !== 1) { return String(el); }
			var cs = W.getComputedStyle(el), r = rectOf(el);
			return pathOf(el) +
				'  pos=' + cs.position + ' z=' + cs.zIndex + ' bg=' + cs.backgroundColor + (cs.backgroundImage !== 'none' ? ' bgimg' : '') +
				' ' + MT.round(r.width) + 'x' + MT.round(r.height) +
				(cs.transform !== 'none' ? ' TRANSFORM' : '') + (cs.filter && cs.filter !== 'none' ? ' FILTER' : '') + (cs.overflow !== 'visible' ? ' overflow=' + cs.overflow : '');
		}
		if (footMode) {
			cand = footerHosts();
			for (var fi2 = 0; fi2 < cand.length; fi2++) {
				var okf = mountIn(cand[fi2], 'footer');
				diag.tried.push((okf ? 'USED   ' : 'reject ') + desc(cand[fi2]) + '  (footer)');
				if (okf) { host = cand[fi2]; hostMode = 'footer'; break; }
			}
			if (!host) {
				diag.notes.push('no footer element found, and footer placement never falls back into the page content — nothing is rendered');
				if (W.console && W.console.warn) {
					W.console.warn('DCC Seasons: placement is "Site footer only" but no footer element was found, so nothing is rendered. Name one with the dcc_seasons_footer_host filter, or switch Placement to "Across the page content".');
				}
				printDiag();
				return;
			}
		} else if (CFG.layer) {
			cand = backdropHosts();
			for (var hi = 0; hi < cand.length; hi++) {
				var hm = trapped(cand[hi]) ? 'sticky' : 'fixed';
				var okh = mountIn(cand[hi], hm);
				diag.tried.push((okh ? 'USED   ' : 'reject ') + desc(cand[hi]) + '  (' + hm + ')');
				if (okh) { host = cand[hi]; hostMode = hm; break; }
			}
			/* Verify, then FIX — up to four passes, driven by the hit-test
			 * above rather than by a sample of what happens to paint.
			 *
			 * 3.6.1 through 3.9.0 did this once, from a 16-point sample
			 * guarded by four conditions that all had to hold at the same
			 * time. On the live site not one pass fired: the canvas stayed a
			 * child of the theme's column with the article inside it painting
			 * opaque white over the whole thing, and "behind" looked exactly
			 * as broken as it had for three releases. A measured
			 * post-condition cannot fail that way — if the canvas is covered,
			 * something happens, and if nothing can be done the panel says
			 * so in one line.
			 *
			 * Two fixes, in order of preference:
			 *   1. Move INTO the covering element. The canvas then paints
			 *      above that element's own background and below its content,
			 *      which is exactly what "behind" means. Preferred because it
			 *      changes nothing about the page.
			 *   2. Take the covering element's background colour and paint it
			 *      on the canvas instead. For an element that cannot hold the
			 *      canvas — too short, or a stacking context of its own.
			 */
			if (host) {
				fixCoverage(false);
			}
		}
		/* One corrective pass set. Runs at mount, and again once the page
		 * has settled, because the first run can land on a layout that does
		 * not exist a moment later — a column whose images have not loaded is
		 * a few pixels tall, and a canvas fitted to it has no measurable box
		 * at all. Only the settled run is allowed to complain. */
		/* WHAT A HOST IS WORTH: the page area the canvas can ever paint in
		 * it. A sticky canvas slides through its host as the visitor scrolls,
		 * so that is the host's own height times the fraction of the canvas
		 * nothing paints over.
		 *
		 * Reach alone is a trap, and it cost three rounds of reports: a 300px
		 * section that nothing paints over scores 100%, so the descend below
		 * moved into one and reported "behind is working" about a canvas that
		 * could only ever show sprites in a 300px band anchored to that
		 * section — measured on the live homepage, where sprites "begin after
		 * the hero image and stop above the text row" and nothing appears
		 * below it at any scroll position. Descending is only ever worth it
		 * if the new host can paint MORE of the page than the one we are in.
		 * A fixed canvas is viewport-sized wherever it lands, so this
		 * question is only about sticky hosts. */
		function worth(el, reach) {
			return el ? mx2(0, rectOf(el).height) * clamp(reach, 0, 1) : 0;
		}
		/* How much of the SCREEN the canvas can paint right now. The number
		 * "behind is working" should have been quoting all along. */
		function viewShare() {
			var r = cv.getBoundingClientRect();
			var vis = mn(r.bottom, W.innerHeight) - mx2(r.top, 0);
			return W.innerHeight > 0 ? clamp(vis / W.innerHeight, 0, 1) : 0;
		}
		function fixCoverage(settled) {
			var cov, pass, c2, moved, m2, prev2, prevMode;
			for (pass = 0; pass < 4; pass++) {
				cov = coverage();
				diag.notes.push((settled ? 'settled ' : '') + 'pass ' + (pass + 1) + ': ' +
					(cov.measurable
						? 'canvas reaches ' + MT.round(cov.reach * 100) + '% of its own box' +
							(cov.cover ? ' — covered by ' + pathOf(cov.cover) + ' (' + cov.coverN + '/' + cov.total + ' points)' : '')
						: 'not measurable yet — none of the canvas is on screen'));
				if (!cov.measurable || cov.reach >= 0.75 || !cov.cover) { break; }
				c2 = cov.cover; moved = false;
				m2 = trapped(c2) ? 'sticky' : 'fixed';
				/* Would moving there paint more of the page than staying? A
				 * sticky host can only ever paint its own height. */
				/* What staying is worth is not today's reach: if the covering
				 * element's background can be moved onto the canvas, staying
				 * ends at full reach over the whole host. Compare the two
				 * outcomes, not one outcome and one starting point. */
				var stay = canTransfer(c2) ? 1 : cov.reach;
				var keep = worth(host, stay), gain = worth(c2, 1);
				/* Two ways a descend is a bad deal, and only two — 3.10.0's
				 * ordinary descend into the opaque article is neither, and
				 * the mount suite holds that line. A host SHORTER THAN THE
				 * SCREEN can never fill it, whatever its reach; and a host
				 * that gives up most of the paintable page is a bad trade
				 * even when it is taller than the screen. */
				var tall = mn(svhPx(), mx2(W.innerHeight, 1));
				var short2 = rectOf(c2).height < tall;
				var worse = m2 === 'sticky' && (short2 || gain < keep * 0.6);
				if (worse) {
					diag.notes.push('NOT descending into ' + pathOf(c2) + ': it is ' +
						MT.round(rectOf(c2).height) + 'px tall' + (short2 ? ', shorter than the ' + MT.round(tall) +
						'px screen' : '') + ', so the canvas could paint ' + MT.round(gain) +
						'px of page there against ' + MT.round(keep) + 'px where it is' +
						(stay === 1 ? ' once its background moves onto the canvas' : '') +
						' — a taller host that is partly painted over beats a short one that is not');
				}
				/* Never descend in footer placement: the canvas belongs to the
				 * footer box, and a footer child is smaller by definition. The
				 * background transfer below is still allowed. */
				if (viable(c2) && !worse && !footMode) {
					prev2 = host; prevMode = hostMode;
					if (mountIn(c2, m2)) {
						diag.tried.push('USED   ' + desc(c2) + '  (descend, ' + m2 + ')');
						host = c2; hostMode = m2; moved = true;
					} else {
						diag.notes.push('cannot descend into ' + pathOf(c2) + ' — it will not hold the canvas');
						mountIn(prev2, prevMode);
					}
				}
				if (!moved && !transferBg(c2)) {
					diag.notes.push('nothing more can be done about ' + pathOf(c2) +
						(W.getComputedStyle(c2).backgroundImage !== 'none' ? ' (it paints an image, which cannot be moved)' : ''));
					break;
				}
			}
			var pad = stickyBalance();
			if (stickyPad) {
				diag.notes.push('sticky margin balanced by ' + stickyPad + 'px' + (pad ? ' (still ' + pad + 'px out)' : '') +
					' — inserting the canvas as the first child un-collapses the next element\'s top margin');
			}
			var fin = coverage();
			diag.reach = fin.measurable ? fin.reach : null;
			diag.covers = fin.cover ? pathOf(fin.cover) : '';
			diag.distinct = fin.distinct;
			diag.share = viewShare();
			diag.paint = MT.round(worth(host, fin.measurable ? fin.reach : 1));
			/* A canvas can be 100% unpainted-over and still be a letterbox
			 * nobody sees. Say so, in the same breath as the reach. */
			if (settled && diag.share < 0.5 && W.console && W.console.warn) {
				W.console.warn('DCC Seasons: the ambient canvas covers only ' + MT.round(diag.share * 100) +
					'% of the screen (' + MT.round(cv.getBoundingClientRect().height) + 'px of ' + W.innerHeight +
					'px), so sprites can only appear in that band. Run ?dcc_debug=1 as an administrator for the mount decision.');
			}
			if (settled && fin.measurable && fin.reach < 0.5 && W.console && W.console.warn) {
				W.console.warn('DCC Seasons: the ambient canvas is mounted but ' + MT.round((1 - fin.reach) * 100) +
					'% of it is painted over by ' + (fin.cover ? pathOf(fin.cover) : 'the theme') +
					'; "behind" will look like nothing is happening. Run ?dcc_debug=1 as an administrator for the full decision.');
			}
			return fin;
		}

		if (!host) {
			/* No usable host: back to the pre-3.6.1 body mount. On a theme
			 * that paints an opaque content column this cannot express
			 * "behind" and the canvas may be covered — say so rather than
			 * fail silently, and never render nothing. */
			mountOnBody(CFG.layer ? 5 : 99990);
			/* Only worth saying when there WAS an opaque column and none of
			 * the candidates could hold the canvas. A theme with no opaque
			 * content column has nothing to hide the body-level canvas, so
			 * "behind" already works there and a warning would be noise. */
			if (CFG.layer && cand.length && W.console && W.console.warn) {
				W.console.warn('DCC Seasons: no backdrop host found for "behind" layering; the canvas is on the body at z-index 5 and may be covered by the theme. Set one with the dcc_seasons_backdrop_host filter.');
			}
		}
		/* --- Admin-only diagnostics panel (?dcc_debug=1). Everything the
		 * mount decision looked at, in a textarea the owner can copy and
		 * paste back. This exists because the live site cannot be reached
		 * from the build environment, so the DOM has to come to us. --- */
		/* Printed once the page has settled (see below), not at mount: the
		 * first measurement can describe a layout that no longer exists. */
		function printDiag() {
			if (!CFG.diag) {
				return;
			}
			(function () {
				var lines = [], anc = D.querySelector('main, [role="main"], #main, #content, .site-content, .site-main, article, .entry-content');
				var r = cv.getBoundingClientRect();
				lines.push('DCC Seasons ' + (CFG.version || '?') + '  engine=' + (CFG.engineSrc || '').replace(/^.*\//, ''));
				lines.push('layering=' + (CFG.layer ? 'behind' : 'front') + '  richness=' + rich + '  theme=' + (themeKey || 'none') + '  viewport=' + W.innerWidth + 'x' + W.innerHeight + '  dpr=' + (W.devicePixelRatio || 1));
				/* The headline, and the one number that answers "is behind
				 * working": how much of the canvas nothing paints over. */
				if (diag.reach != null) {
					lines.push('CANVAS REACH: ' + MT.round(diag.reach * 100) + '% of its own box is unpainted-over' +
						(diag.reach >= 0.75 ? '  — behind is working'
							: '  — STILL COVERED by ' + (diag.covers || '?') + (diag.distinct > 1 ? ' and ' + (diag.distinct - 1) + ' other element(s)' : '')));
				} else if (CFG.layer && host) {
					/* Never say "covered" about something that could not be
					 * measured: none of the canvas was on screen when this
					 * ran, which is a fact about the scroll position, not
					 * about the theme. Scroll to it and reload to measure. */
					lines.push('CANVAS REACH: not measurable — no part of the canvas box was on screen. Scroll to the content column and reload.');
				}
				/* Where a sprite can be SEEN, and what the two new guardrails
				 * cost — the numbers to quote when the field still looks
				 * wrong on a page this build has never seen. */
				/* The panel prints from the settled pass NORMALLY, but also from the
				 * one path that gives up before the scene exists — footer placement
				 * with no footer. Everything it reads must tolerate that: `var`
				 * hoists the declaration and not the value, so parts and textBoxes
				 * are undefined up there, and an unguarded .length made the panel
				 * throw in precisely the state the owner needs it. */
				var plist = parts || [], tb = textBoxes || [];
				var frn = 0;
				for (var fi = 0; fi < plist.length; fi++) { if (plist[fi].free) { frn++; } }
				lines.push('placement=' + (footMode ? 'footer only' : 'page content') +
					(footMode ? '  footer=' + (host ? pathOf(host) : 'NONE') + '  text boxes kept clear=' + tb.length +
						' (' + (textMs || 0).toFixed(2) + 'ms)' : ''));
				lines.push('open map: ' + (omList
					? omN + '/' + omTot + ' cells open (' + MT.round(omFrac * 100) + '%) in ' + omMs.toFixed(2) + 'ms, ' + omBuilds + ' build(s), cell ' + MAP_CELL + 'px' +
						(mapUsable() ? '' : ' — under 10% open, seeding falls back to even coverage')
					: 'not built (front layering or no host) — the canvas is above the page'));
				lines.push('anti-clump: ' + (repN ? repMs.toFixed(3) + 'ms/frame over ' + repN + ' frames' : 'no frames measured yet') +
					'  spacing target ' + MT.round(sepRun || 0) + 'px  free-air ' + frn + '/' + plist.length + ' particles');
				lines.push('SCREEN REACH: ' + MT.round((diag.share || 0) * 100) + '% of the viewport is canvas' +
					(diag.share >= 0.5 ? '' : '  — LETTERBOX: sprites can only appear in that band') +
					'  (canvas ' + MT.round(r.height) + 'px of ' + W.innerHeight + 'px; the host can hold ' +
					(diag.paint || 0) + 'px of page)');
				lines.push('backdropHost filter=' + (CFG.backdropHost || '(none)') + '  candidates=' + cand.length);
				for (var di = 0; di < diag.tried.length; di++) { lines.push('  ' + diag.tried[di]); }
				for (di = 0; di < diag.notes.length; di++) { lines.push('  ! ' + diag.notes[di]); }
				/* THE decisive line when "behind" still looks wrong: what is
				 * painting the page, and is it above or below the canvas. */
				var sp2 = samplePainters();
				if (sp2.el && sp2.n < sp2.hits / 2 && sp2.hits > 2) {
					/* One canvas can only sit behind ONE element. If the page
					 * is painted by several opaque boxes, say so — that is the
					 * case the mount cannot fully solve, and the fix is to
					 * name the outer one with dcc_seasons_backdrop_host. */
					lines.push('NOTE: ' + sp2.distinct + ' different elements paint the sampled points; a single canvas can only sit behind one of them.');
				}
				if (sp2.el) {
					var rel = sp2.el === host ? 'the host itself (below the canvas — good)'
						: (host && host.contains(sp2.el)) ? 'INSIDE the host — it paints ABOVE the canvas and is hiding it'
						: (host && sp2.el.contains(host)) ? 'an ancestor of the host (below the canvas — good)'
						: 'outside the host';
					lines.push('painting ' + sp2.n + '/' + sp2.total + ' sampled points: ' + desc(sp2.el));
					lines.push('  → that is ' + rel);
				} else {
					lines.push('painting: nothing opaque at the sampled points (the page background shows through)');
				}
				lines.push('canvas: parent=' + (host ? desc(host).split('  ')[0] : 'body (fallback)') + '  mode=' + (host ? hostMode : 'fixed') + '  z=' + cv.style.zIndex + '  rect=' + MT.round(r.left) + ',' + MT.round(r.top) + ' ' + MT.round(r.width) + 'x' + MT.round(r.height) + '  copies=' + D.querySelectorAll('.dcc-seasons-canvas').length);
				lines.push('anchor chain (' + (anc ? desc(anc).split('  ')[0] : 'NO ANCHOR MATCHED') + ' → body):');
				for (var el = anc; el && el.nodeType === 1 && el !== D.body; el = el.parentElement) { lines.push('  ' + desc(el)); }
				lines.push('  ' + desc(D.body));
				var box = D.createElement('div');
				box.setAttribute('aria-hidden', 'true');
				box.style.cssText = 'position:fixed;left:10px;bottom:10px;z-index:2147482000;max-width:min(96vw,720px);background:#0a3d62;color:#f4da62;border:2px solid #f4da62;border-radius:8px;padding:8px;font:11px/1.35 monospace;box-shadow:0 4px 14px rgba(0,0,0,.4);';
				var ta = D.createElement('textarea');
				ta.readOnly = true;
				ta.value = lines.join('\n');
				ta.style.cssText = 'display:block;width:100%;height:190px;box-sizing:border-box;background:#062a44;color:#fff;border:1px solid #f4da62;border-radius:4px;font:11px/1.35 monospace;padding:6px;white-space:pre;resize:vertical;';
				var cap = D.createElement('div');
				cap.textContent = 'DCC Seasons diagnostics — select all, copy, paste to the developer';
				cap.style.cssText = 'margin:0 0 6px;font-weight:700;';
				box.appendChild(cap); box.appendChild(ta);
				D.body.appendChild(box);
				ta.addEventListener('focus', function () { ta.select(); });
			})();
		}
		/* Re-verify when the layout has stopped moving. A column whose images
		 * have not loaded is a few pixels tall, and a canvas fitted to it has
		 * no measurable box — which is how a working backdrop got reported as
		 * 100% covered. Only this run may warn, and the panel is printed from
		 * it, so both describe the page as it finally is. */
		setTimeout(function () {
			/* Anything that rewrites the host's innerHTML — a slider, an
			 * accordion, a theme script re-rendering a container — takes the
			 * canvas with it. Found while building the fixture for the check
			 * above, and cheap to survive. */
			if (CFG.layer && !D.body.contains(cv)) {
				diag.notes.push('the canvas had been removed from the page (the host re-rendered its children); re-mounted');
				ensureMounted();
			}
			if (CFG.layer && host) { fixCoverage(true); }
			/* The map that seeded the first field was built against a layout
			 * whose images had not loaded. Rebuild it now that the page has
			 * settled — the field migrates into the open as it respawns,
			 * which is the only way to correct it without teleporting
			 * anything. */
			buildOpenMap();
			printDiag();
		}, 1200);

		/* Corner accents ride on the same decision as the canvas. */
		/* Corner accents are page-corner decoration by definition, so they
		 * have no place in a footer-only scene. */
		for (var ai = 0; !footMode && ai < accents.length; ai++) {
			accents[ai].style.zIndex = host ? '-1' : (CFG.layer ? '5' : '99990');
			/* position:fixed inside a transformed host resolves against that
			 * host, not the viewport: the accent lands in the column's corner
			 * and, being taller than a short column, lengthens the page.
			 * Absolute is what fixed already means in there — minus the
			 * overflow. */
			if (hostMode === 'sticky') { accents[ai].style.position = 'absolute'; }
			(host || D.body).appendChild(accents[ai]);
		}
		var cx = cv.getContext('2d');

		/* --- Sizing: one source (canvas rect × DPR), window + visualViewport
		 * resize, full re-seed on change. --- */
		var vw = 0, vh = 0, waterY = 0, ground = 0, sizeTimer = 0;
		/* Resizing the canvas is DESTRUCTIVE: writing cv.width clears it, and
		 * this used to re-seed every particle, drop every ripple and kill any
		 * hero or vignette in flight. That is fine once, at startup. It is not
		 * fine on every scroll — and on iOS every scroll is a resize, because
		 * the URL bar collapsing fires visualViewport 'resize'. One swipe, one
		 * restart: the reported "the graphics reset whenever I tap or scroll",
		 * and why a hero flyover could almost never finish on a phone.
		 *
		 * So: do nothing at all when nothing changed, and when something did
		 * change, SLIDE the scene into the new box rather than restart it.
		 * Only a real discontinuity — the first sizing, or a box that has more
		 * than doubled or halved — starts over.
		 */
		var lastDpr = 0;
		function applySize(force) {
			var r = cv.getBoundingClientRect();
			var dpr = mn(W.devicePixelRatio || 1, 2);
			var w = mx2(1, MT.round(r.width));
			var h = mx2(1, MT.round(r.height));
			if (!force && w === vw && h === vh && dpr === lastDpr) {
				return; /* the write to cv.width alone would clear the canvas */
			}
			var ow = vw, oh = vh;
			lastDpr = dpr;
			cv.width = MT.round(w * dpr);
			cv.height = MT.round(h * dpr);
			cx.setTransform(dpr, 0, 0, dpr, 0, 0);
			cx.textAlign = 'center';
			cx.textBaseline = 'middle';
			vw = w; vh = h;
			waterY = vh * 0.92;
			ground = vh - 16;
			var nowMobile = W.innerWidth < 768;
			if (nowMobile !== mobile) {
				mobile = nowMobile;
				FX.reflect = rich === 'full' && V.reflections !== false && !mobile && water && !shed;
			}
			var sx = ow > 0 ? w / ow : 1, sy = oh > 0 ? h / oh : 1;
			var restart = force || ow < 1 || oh < 1 || sx < 0.5 || sx > 2 || sy < 0.5 || sy > 2;
			var k;
			if (restart) {
				for (k = 0; k < parts.length; k++) { seed(parts[k], true); }
				ripples.length = 0;
				if (hero) { hero = null; }
				if (vig) { endVig(); }
			} else {
				for (k = 0; k < parts.length; k++) { scaleXY(parts[k], sx, sy); }
				for (k = 0; k < ripples.length; k++) { scaleXY(ripples[k], sx, sy); }
				if (hero) { scaleXY(hero, sx, sy); }
				if (vig && vig.st) { scaleXY(vig.st, sx, sy); }
			}
			snowCols = FX.snow ? new Float32Array(MT.ceil(vw / 8) + 1) : null;
			/* A real resize changes both the box and what is under it. The
			 * map is rebuilt on the throttle, never inline: this path runs on
			 * the debounce and must stay cheap. */
			sepTarget();
			queueMap(120);
		}
		/* Every coordinate an actor carries, moved into the new box. */
		function scaleXY(o, sx, sy) {
			if (!o) { return; }
			if (typeof o.x === 'number') { o.x *= sx; }
			if (typeof o.y === 'number') { o.y *= sy; }
			if (typeof o.lx === 'number') { o.lx *= sx; }
			if (typeof o.gy === 'number') { o.gy *= sy; }
			if (typeof o.y0 === 'number') { o.y0 *= sy; }
		}
		function queueSize() { clearTimeout(sizeTimer); sizeTimer = setTimeout(applySize, 150); }
		W.addEventListener('resize', queueSize);
		W.addEventListener('orientationchange', function () { svhCache = 0; stickyFit(); queueSize(); });
		if (W.visualViewport) { W.visualViewport.addEventListener('resize', queueSize); }

		/* --- Resolve particle specs (sprite arrays, tofu-checked emoji). --- */
		function resolve(def) {
			var sp = { def: def, b: def.b || 'fall' };
			if (def.s) { sp.kind = 's'; sp.s = def.s; (Array.isArray(def.s) ? def.s : [def.s]).forEach(sprite); }
			else if (def.c) { sp.kind = 'c'; sp.c = def.c; }
			else {
				var g = def.e;
				if (!g || !drawable(g)) {
					var f = def.f || '*';
					if (f.charCodeAt(0) >= 0xD800 && drawable(f)) {
						sp.kind = 'e'; sp.g = f;
						return sp;
					}
					sp.kind = 't'; sp.g = f; sp.color = def.fc || '#888888';
					return sp;
				}
				sp.kind = 'e'; sp.g = g;
			}
			return sp;
		}
		var pool = [];
		(A.particles || []).forEach(function (def) {
			var sp = resolve(def), n = def.w || 1;
			while (n--) { pool.push(sp); }
		});
		/* Evening variant: fishing swaps one leaf slot for fireflies. */
		var firefly = null;
		if (evening && themeKey === 'fall_fishing') {
			firefly = { kind: 'c', c: 'firefly', b: 'firefly', def: { b: 'firefly' } };
			for (var fi = 0; fi < pool.length; fi++) {
				if (pool[fi].kind === 's' && Array.isArray(pool[fi].s)) { pool[fi] = firefly; break; }
			}
		}
		PRIMS.firefly = function (cx2, p, s) {
			var g = 0.5 + 0.5 * sin(p.ph * 2.4);
			cx2.fillStyle = 'rgba(255,236,150,' + (0.25 + 0.4 * g) + ')';
			cx2.beginPath(); cx2.arc(0, 0, 7 * s * (evening ? 1.3 : 1), 0, TAU); cx2.fill();
			cx2.fillStyle = '#FFEC99';
			cx2.beginPath(); cx2.arc(0, 0, 2.2 * s, 0, TAU); cx2.fill();
		};

		/* --- Ripples & pop-rings (both count toward the cap). --- */
		var ripples = [];
		function fxRoom() { return parts.length + ripples.length < maxTotal; }
		function addRipple(x, y, big) {
			if (!fxRoom()) { return; }
			ripples.push({ x: x, y: y, r: big ? 6 : 3, a: 0.8, big: !!big, ring: false });
		}
		function addRing(x, y) {
			if (!fxRoom()) { return; }
			ripples.push({ x: x, y: y, r: 3, a: 0.8, big: false, ring: true });
		}
		function stepRipples(dt) {
			for (var k = ripples.length - 1; k >= 0; k--) {
				var r = ripples[k];
				r.r += dt * (r.big ? 34 : 22);
				r.a -= dt * 0.9;
				if (r.a <= 0) { ripples.splice(k, 1); }
			}
		}
		function drawRipples() {
			cx.lineWidth = 1;
			for (var k = 0; k < ripples.length; k++) {
				var r = ripples[k];
				cx.globalAlpha = alphaBase * r.a;
				cx.strokeStyle = r.ring ? '#FFD43B' : '#9CC3E5';
				cx.beginPath();
				if (r.ring) { cx.arc(r.x, r.y, r.r, 0, TAU); }
				else { cx.ellipse(r.x, r.y, r.r, r.r * 0.3, 0, 0, TAU); }
				cx.stroke();
			}
		}

		/* --- Christmas snow accumulation (≤6px, session-only). --- */
		var snowCols = null;
		function snowLand(x) {
			if (!snowCols) { return; }
			var i = clamp((x / 8) | 0, 0, snowCols.length - 1);
			snowCols[i] = mn(6, snowCols[i] + 0.7);
			if (i > 0) { snowCols[i - 1] = mn(6, snowCols[i - 1] + 0.3); }
			if (i < snowCols.length - 1) { snowCols[i + 1] = mn(6, snowCols[i + 1] + 0.3); }
		}
		function drawSnow() {
			if (!snowCols) { return; }
			cx.globalAlpha = mn(1, alphaBase * 2);
			cx.fillStyle = '#F1F5F9';
			cx.beginPath();
			cx.moveTo(0, waterY);
			for (var i = 0; i < snowCols.length; i++) { cx.lineTo(i * 8, waterY - snowCols[i]); }
			cx.lineTo(vw, waterY);
			cx.closePath();
			cx.fill();
		}

		/* --- Particles. --- */
		var parts = [];
		function dirY() { return up ? -1 : 1; }

		/* --- Open-cell map: WHERE A SPRITE CAN ACTUALLY BE SEEN. ----------
		 * Reported from the live homepage: sprites "only show up in the area
		 * underneath the hero image and above the DCC Cottage Selector
		 * widget". Measured there at 375px: the band from the article top to
		 * the selector is 99-100% open, and below it the page is a wall of
		 * full-bleed cards (8 room cards, 270 painted calendar cells) whose
		 * only open pixels are gutters too narrow to show a whole sprite.
		 * 57% of that column is "open" by area and almost none of it is
		 * usable. Seeding evenly over the CANVAS therefore puts most of the
		 * field where nothing can be seen — which is what "they only show up
		 * in one band, and they still kinda cluster" describes.
		 *
		 * So ask the page, with the same question the mount already asks
		 * (painterAt: what is the first thing that paints here, and is it
		 * INSIDE the host and therefore above the canvas?), on a coarse grid
		 * of the canvas's on-screen box. Cells nothing paints over are open;
		 * seeding draws from those.
		 *
		 * Rebuilt on scroll-settle, on a real resize and after the settled
		 * mount pass, never per frame and never faster than MAP_MIN apart.
		 * getComputedStyle dominates the cost, and the same handful of
		 * ancestors answer for every cell, so each build stamps its verdict
		 * on the element and reuses it. --- */
		/* 48px: finer than a sprite (16-34px) and coarse enough that a phone
		 * viewport is ~8x17 = 136 hit tests. At 40px it was 210 and the build
		 * ran 1.8-3.4ms in the test container — over the 2ms ceiling. */
		/* --- Footer text: the boxes nothing may be drawn over. -----------
		 * Measured from RANGE rects over the text nodes themselves, not from
		 * the elements' block boxes: a footer link's block box is the width
		 * of its column, while the range rect is the width of the words. One
		 * rect per line box, so it is glyph-tight horizontally and line-tight
		 * vertically. Images and inline SVG count as content too.
		 * These become holes in the clip region, so no pixel of any sprite,
		 * ripple, trail or reflection can land on a word. --- */
		var TEXT_PAD = 3, textBoxes = [], textMs = 0;
		function collectRects(el, out, r0) {
			var rects = el.getClientRects ? el.getClientRects() : [], i, rr;
			for (i = 0; i < rects.length; i++) {
				rr = rects[i];
				if (rr.width < 2 || rr.height < 2) { continue; }
				out.push({ x: rr.left - r0.left - TEXT_PAD, y: rr.top - r0.top - TEXT_PAD,
					w: rr.width + TEXT_PAD * 2, h: rr.height + TEXT_PAD * 2 });
			}
		}
		function buildTextBoxes() {
			var t0 = nowMs();
			textBoxes.length = 0;
			if (!footMode || !host) { textMs = 0; return; }
			var r0 = cv.getBoundingClientRect();
			var walk = D.createTreeWalker(host, W.NodeFilter ? W.NodeFilter.SHOW_TEXT : 4, null, false);
			var n, pe, cs2, rg;
			while ((n = walk.nextNode())) {
				if (!n.nodeValue || !/\S/.test(n.nodeValue)) { continue; }
				pe = n.parentElement;
				if (!pe || pe === cv) { continue; }
				cs2 = W.getComputedStyle(pe);
				if (cs2.visibility === 'hidden' || cs2.display === 'none' || +cs2.opacity === 0) { continue; }
				rg = D.createRange();
				rg.selectNodeContents(n);
				collectRects(rg, textBoxes, r0);
			}
			var imgs = host.querySelectorAll('img, svg, picture, video');
			for (n = 0; n < imgs.length; n++) { collectRects(imgs[n], textBoxes, r0); }
			textMs = nowMs() - t0;
		}
		function onText(x, y) {
			for (var i = 0; i < textBoxes.length; i++) {
				var b = textBoxes[i];
				if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { return true; }
			}
			return false;
		}
		/* The guarantee, applied once a frame: everything drawn is clipped to
		 * the canvas MINUS the text boxes. Cheap — one path of a few dozen
		 * rects — and unlike a per-sprite test it also covers trails, ripples
		 * and reflections. */
		function clipText() {
			if (!textBoxes.length) { return false; }
			cx.save();
			cx.beginPath();
			cx.rect(0, 0, vw, vh);
			for (var i = 0; i < textBoxes.length; i++) {
				var b = textBoxes[i];
				cx.rect(b.x, b.y, b.w, b.h);
			}
			cx.clip('evenodd');
			return true;
		}

		var MAP_CELL = 48, MAP_MIN = 400;
		var omC = 0, omR = 0, omCell = null, omList = null, omN = 0, omTot = 0, omMeas = 0, omOpen = 0;
		var omNine = [0, 0, 0, 0, 0, 0, 0, 0, 0], omCol = [0, 0, 0];
		var omFrac = 1, omMs = 0, omBuilds = 0, omAt = -1e9, omStamp = 0, omTimer = 0;
		function nowMs() { return (W.performance && performance.now) ? performance.now() : +new Date(); }
		/* Usable = built, and enough of the page open that steering into it
		 * still leaves room to spread. Below that the honest thing is to seed
		 * as before rather than crowd every sprite into one gutter. */
		function mapUsable() { return !!omList && omN > 0 && omFrac >= 0.1; }
		function paintsStamped(el) {
			if (el._dccPb === omStamp) { return el._dccPo; }
			el._dccPb = omStamp;
			el._dccPo = paintsOpaque(el);
			return el._dccPo;
		}
		function openAt(x, y) {
			var el = D.elementFromPoint(x, y), p2 = null;
			for (; el && el.nodeType === 1 && el !== D.documentElement; el = el.parentElement) {
				if (paintsStamped(el)) { p2 = el; break; }
			}
			/* Same verdict as coverage(): only a DESCENDANT of the host paints
			 * above the canvas. */
			return !p2 || p2 === cv || p2 === host || !host.contains(p2);
		}
		function buildOpenMap() {
			var t0 = nowMs();
			omAt = t0; omBuilds++;
			/* In front mode the canvas is above the page: everything is open,
			 * and sampling would be a lie dressed as a measurement. */
			if ((!CFG.layer && !footMode) || !host || vw < 1 || vh < 1) {
				omList = null; omFrac = 1; omMs = 0; sepTarget(); return;
			}
			buildTextBoxes();
			var r = cv.getBoundingClientRect();
			var sx = vw > 0 ? r.width / vw : 1, sy = vh > 0 ? r.height / vh : 1;
			var c, rw, i, k, x, y, vx, vy, open;
			var iw = W.innerWidth, ih = W.innerHeight;
			omC = mx2(1, MT.ceil(vw / MAP_CELL));
			omR = mx2(1, MT.ceil(vh / MAP_CELL));
			var stepX = vw / omC, stepY = vh / omR;
			omTot = omC * omR;
			if (!omCell || omCell.length !== omTot) { omCell = new Uint8Array(omTot); omList = new Uint16Array(omTot); }
			omStamp++;
			omN = 0; omMeas = 0; omOpen = 0;
			for (i = 0; i < 9; i++) { omNine[i] = 0; }
			omCol[0] = omCol[1] = omCol[2] = 0;
			for (rw = 0; rw < omR; rw++) {
				for (c = 0; c < omC; c++) {
					k = rw * omC + c;
					x = (c + 0.5) * stepX;
					y = (rw + 0.5) * stepY;
					vx = r.left + x * sx;
					vy = r.top + y * sy;
					/* Off-screen is UNMEASURABLE, not covered — elementFromPoint
					 * outside the viewport returns null, which says nothing. The
					 * mount learned this the hard way in 3.11.0. */
					if (vx < 0 || vy < 0 || vx >= iw || vy >= ih) {
						open = 1;                       /* unmeasurable, so not covered */
					} else {
						open = openAt(vx, vy) ? 1 : 0;
						/* A cell over footer text is not somewhere to seed
						 * into: the clip would only make the sprite invisible
						 * there, which wastes it. */
						if (open && onText(x, y)) { open = 0; }
						omMeas++; omOpen += open;
					}
					omCell[k] = open;
					if (open) {
						omList[omN++] = k;
						omNine[mn(2, (y / vh * 3) | 0) * 3 + mn(2, (x / vw * 3) | 0)]++;
						omCol[mn(2, (x / vw * 3) | 0)]++;
					}
				}
			}
			/* The open FRACTION is of what could actually be sampled. Cells
			 * off the bottom of the viewport are unknown, and counting them
			 * as open would keep the map "usable" on a page whose visible
			 * part is solid — the same unmeasurable-is-not-covered trap the
			 * mount fell into in 3.11.0, in the other direction. They still
			 * belong in the candidate pool: nothing is known to paint there. */
			omFrac = omMeas ? omOpen / omMeas : 1;
			omMs = nowMs() - t0;
			sepTarget();
		}
		function queueMap(ms) {
			clearTimeout(omTimer);
			var wait = mx2(ms || 200, MAP_MIN - (nowMs() - omAt));
			omTimer = setTimeout(buildOpenMap, mx2(0, wait));
		}
		/* A sticky canvas rides the viewport, so scrolling changes what is
		 * under it. Settle first: a scroll is a stream of events. */
		W.addEventListener('scroll', function () { queueMap(220); }, { passive: true });

		/* One open cell whose centre lies in the wanted box, found by a
		 * bounded scan from a random start — no allocation, and it degrades
		 * to "no cell" rather than looping when the box has none open.
		 * col 0/1/2 restricts to a third of the width (an entry edge). */
		function pickCell(x0, x1, y0, y1, col) {
			if (!mapUsable()) { return -1; }
			var s = (rand() * omN) | 0, i, k, c, rw, x, y;
			for (i = 0; i < omN && i < 24; i++) {
				k = omList[(s + i) % omN];
				c = k % omC; rw = (k - c) / omC;
				x = (c + 0.5) * vw / omC;
				y = (rw + 0.5) * vh / omR;
				if (x < x0 || x > x1) { continue; }
				if (y1 > y0 && (y < y0 || y > y1)) { continue; }
				if (col >= 0 && mn(2, (x / vw * 3) | 0) !== col) { continue; }
				return k;
			}
			return -1;
		}
		function cellX(k) { var c = k % omC; return clamp(((c + 0.5) + rnd(-0.45, 0.45)) * vw / omC, 0, vw); }
		function cellY(k) { var rw = ((k - (k % omC)) / omC); return clamp(((rw + 0.5) + rnd(-0.45, 0.45)) * vh / omR, 0, vh); }
		/* An open x anywhere on the row a deliberate actor is entering on,
		 * and an open y for a crosser entering from `edge` (-1 either). */
		function openX(x0, x1, y) {
			var k = pickCell(x0, x1, y, y, -1);
			return k < 0 ? rnd(x0, x1) : clamp(cellX(k), x0, x1);
		}
		function openBandY(y0, y1, edge) {
			var k = pickCell(0, vw, y0, y1, edge);
			if (k < 0) { k = pickCell(0, vw, y0, y1, -1); }
			return k < 0 ? rnd(y0, y1) : clamp(cellY(k), y0, y1);
		}

		/* --- Seed-time spatial guardrail. --------------------------------
		 * A uniform random position is free to bunch: modelled offline, 16
		 * particles put six or more into the same ninth of the canvas in
		 * ~10% of fields, and up to nine. Placement now throws up to
		 * SPREAD_TRIES candidates and takes the first that lands in a ninth
		 * still under its even share AND no closer than the spacing target
		 * to a live particle; if none qualifies, the best candidate seen
		 * (fewest neighbours in its ninth, then furthest from anything).
		 * Same model: worst ninth 3 of 16, ~2.8 candidates per particle.
		 *
		 * It runs at SEED time only -- never per frame -- so it cannot fight
		 * the motion, and a resize still rescales rather than re-seeds.
		 * Behaviors that place themselves on purpose (water-line riders,
		 * growers, off-screen entrances) and the hero never come through
		 * here. Pass y1 <= y0 for a fixed y (an entrance): the field is then
		 * spread across x alone, against column totals. --- */
		/* A small field can afford to look harder, and wants more room
		 * between its members: at density 10 there are 90 candidate throws
		 * in a whole seeding pass, which costs nothing. */
		var SPREAD_TRIES = maxParts <= 12 ? 16 : 8;
		var SEP_K = maxParts <= 12 ? 0.6 : 0.45;
		var occ = [0, 0, 0, 0, 0, 0, 0, 0, 0];
		var qta = [0, 0, 0, 0, 0, 0, 0, 0, 0];
		var sepRun = 0;
		/* The pitch an even lattice of this field would have over the part of
		 * the page a sprite can be SEEN in. Seeding and the runtime
		 * anti-clump share it, so they cannot pull against each other. */
		function sepTarget() {
			sepRun = MT.sqrt(mx2(1, vw * vh * (mapUsable() ? omFrac : 1)) / mx2(1, maxParts)) * SEP_K;
		}
		function spreadPlace(p, x0, x1, y0, y1) {
			var flat = !(y1 > y0);
			var useMap = mapUsable();
			var i, j, q, c, r, ct, near, dx, dy, d2, x, y, sc, k, op;
			var live = 0;
			for (i = 0; i < 9; i++) { occ[i] = 0; }
			for (i = 0; i < parts.length; i++) {
				q = parts[i];
				if (q === p || q.dormant) { continue; }
				/* Off-screen particles hold no ninth, but they DO hold the
				 * column they are about to enter, which is the whole point
				 * of the flat pass. */
				if (!(q.x >= 0) || q.x > vw) { continue; }
				if (!flat && (!(q.y >= 0) || q.y > vh)) { continue; }
				c = mn(2, (q.x / vw * 3) | 0);
				r = flat ? 0 : mn(2, (q.y / vh * 3) | 0);
				occ[r * 3 + c]++;
				live++;
			}
			/* The even share is a share of the OPEN cells, not of the area.
			 * A third of a canvas that is 15% visible is not a third of what
			 * anyone can see — sharing by area is exactly what made the field
			 * look random below the fold while obeying the rule. A ninth with
			 * nothing open takes no one. */
			var cells = flat ? 3 : 9;
			for (i = 0; i < cells; i++) {
				op = useMap ? (flat ? omCol[i] : omNine[i]) : 0;
				qta[i] = useMap
					? (op === 0 ? 0 : mx2(1, MT.ceil((live + 1) * op / omN)))
					: mx2(1, MT.ceil((live + 1) / cells));
			}
			var vis = useMap ? omFrac : 1;
			var sep = flat
				? (x1 - x0) * vis / mx2(1, live + 1) * SEP_K
				: MT.sqrt(mx2(1, (x1 - x0) * (y1 - y0) * vis) / mx2(1, live + 1)) * SEP_K;
			var sep2 = sep * sep;
			var bx = x0, by = y0, best = -1e18;
			for (i = 0; i < SPREAD_TRIES; i++) {
				/* Draw the candidate from an OPEN cell when there is a map;
				 * fall back to the whole range when the wanted box has none
				 * (a narrow band can be entirely painted over). */
				k = useMap ? pickCell(x0, x1, flat ? 0 : y0, flat ? 0 : y1, -1) : -1;
				if (k >= 0) {
					x = clamp(cellX(k), x0, x1);
					y = flat ? y0 : clamp(cellY(k), y0, y1);
				} else {
					x = rnd(x0, x1);
					y = flat ? y0 : rnd(y0, y1);
				}
				c = mn(2, mx2(0, (x / vw * 3) | 0));
				r = flat ? 0 : mn(2, mx2(0, (y / vh * 3) | 0));
				ct = occ[r * 3 + c];
				near = 1e12;
				for (j = 0; j < parts.length; j++) {
					q = parts[j];
					if (q === p || q.dormant) { continue; }
					dx = q.x - x; dy = flat ? 0 : q.y - y;
					d2 = dx * dx + dy * dy;
					if (d2 < near) { near = d2; }
				}
				if (ct < qta[flat ? c : r * 3 + c] && near >= sep2) { bx = x; by = y; best = 1e18; break; }
				sc = (near > 1e6 ? 1e6 : near) - ct * 1e7;
				if (sc > best) { best = sc; bx = x; by = y; }
			}
			p.x = bx; p.y = by;
		}

		/* --- Runtime anti-clump. ------------------------------------------
		 * Seeding decides where a sprite STARTS; motion decides where the
		 * field actually is a minute later, and free-air motion re-bunches —
		 * "isn't as bad but still needs to be better" is what a seed-only
		 * rule feels like once it has been running a while. So: a soft
		 * pairwise separation, free-air behaviours only. Below the shared
		 * spacing target the push fades linearly to nothing AT it, so it
		 * never oscillates, never chases a sprite that is already far enough
		 * away, and never becomes the per-frame repulsion 3.14.0 warned
		 * against — it cannot pull a field apart faster than 14px a second.
		 * Sprites that are off the canvas are skipped and the result is
		 * clamped to the box, so a nudge can never push one over an edge and
		 * trigger the respawn 3.13.0 spent a release removing. At most 16
		 * particles is at most 120 pairs. Reduced motion never reaches here:
		 * the loop does not run at all. --- */
		var REPEL_V = 14, repMs = 0, repN = 0;
		function deClump(dt) {
			var s = sepRun;
			if (!(s > 0)) { return; }
			var t0 = CFG.diag ? nowMs() : 0;
			var n = parts.length, i, j, a, b2, dx, dy, d2, d, f, ux, uy, s2 = s * s;
			for (i = 0; i < n; i++) {
				a = parts[i];
				if (!a.free || a.dormant || a.x < 0 || a.x > vw || a.y < 0 || a.y > vh) { continue; }
				for (j = i + 1; j < n; j++) {
					b2 = parts[j];
					if (!b2.free || b2.dormant || b2.x < 0 || b2.x > vw || b2.y < 0 || b2.y > vh) { continue; }
					dx = b2.x - a.x; dy = b2.y - a.y;
					d2 = dx * dx + dy * dy;
					if (d2 >= s2 || d2 < 0.01) { continue; }
					d = MT.sqrt(d2);
					f = (1 - d / s) * REPEL_V * dt;
					ux = dx / d * f; uy = dy / d * f;
					a.x = clamp(a.x - ux, 0, vw); a.y = clamp(a.y - uy, 0, vh);
					b2.x = clamp(b2.x + ux, 0, vw); b2.y = clamp(b2.y + uy, 0, vh);
				}
			}
			if (t0) { repMs = repN ? repMs + (nowMs() - t0 - repMs) * 0.05 : nowMs() - t0; repN++; }
		}

		function seed(p, anywhere) {
			var sp = pick(pool);
			if (!sp) { return p; }
			var def = sp.def;
			p.sp = sp;
			p.b = sp.b;
			p.size = def.sz ? rnd(def.sz[0], def.sz[1]) : rnd(16, 24);
			p.sc = rnd(0.7, 1.4);
			p.rot = 0;
			p.vr = rnd(-1.2, 1.2);
			p.alpha = 1;
			p.ph = rnd(0, TAU);
			p.phv = rnd(0.8, 2);
			p.st = 0;
			p.t = 0;
			p.settled = 0;
			p.pop = 0;
			p.ox = 0; p.oy = 0;
			p.dormant = false;
			p.sKey = Array.isArray(sp.s) ? pick(sp.s) : sp.s;
			p.shim = (rand() * 2) | 0;
			p.trail = null;
			/* Depth layer: FAR = 60% scale, 50% speed, 60% opacity. Only
			 * free-air behaviors — staged/bottom actors stay NEAR. */
			var canFar = 'fall sway tumble flutter fly pulse rise twinkle spin vee wobble'.indexOf(p.b) >= 0;
			p.far = FX.parallax && canFar && rand() < 0.35;
			/* Which behaviours the guardrail owns: free air, nothing staged.
			 * Space-delimited on purpose — a bare indexOf would match 'fly'
			 * inside 'firefly' and hand the crossers to the anti-clump. */
			p.free = FREEAIR.indexOf(' ' + p.b + ' ') >= 0 ? 1 : 0;
			var slow = (def.slow ? 0.45 : 1) * (p.far ? 0.5 : 1);
			var b = p.b;
			var offY = up ? vh + 30 : -30;
			if (anywhere) { spreadPlace(p, 0, vw, 0, vh * 0.8); }
			else { spreadPlace(p, 0, vw, offY, offY); }
			p.vx = rnd(-8, 8) * (p.far ? 0.5 : 1);
			p.vy = rnd(14, 30) * slow * dirY();
			p.sw = 6;
			if (b === 'sway') { p.vy = rnd(8, 16) * slow * dirY(); p.sw = 22; p.vr = rnd(-0.6, 0.6); }
			if (b === 'tumble') { p.vr = rnd(-4, 4); p.sw = 10; }
			if (b === 'spin') { p.vy = rnd(4, 8) * dirY(); p.vr = rnd(0.5, 1); p.sw = 3; }
			if (b === 'wobble') { p.vy = rnd(6, 10); p.sw = 18; p.vr = 0; }
			if (b === 'flutter') {
				spreadPlace(p, 0, vw, vh * 0.05, vh * 0.7);
				p.vx = (sgn()) * rnd(25, 55) * (p.far ? 0.5 : 1);
				p.vy = 0; p.vr = 0;
			}
			if (b === 'float') {
				p.x = rnd(vw * 0.05, vw * 0.95);
				p.y = waterY;
				p.vx = rnd(-4, 4); p.vy = 0; p.vr = 0;
			}
			if (b === 'rise') {
				if (anywhere) { spreadPlace(p, 0, vw, vh * 0.3, vh); }
				else { spreadPlace(p, 0, vw, vh + 20, vh + 20); }
				p.vy = -rnd(15, 35) * (p.far ? 0.5 : 1); p.vr = 0; p.sw = 8;
			}
			if (b === 'grow') {
				p.y = vh + 20;
				p.gy = vh - rnd(30, 110);
				p.st = 1; p.vr = 0; p.vx = 0;
				p.lit = 0;
			}
			if (b === 'berrycycle') {
				p.y = vh + 20;
				p.gy = vh - rnd(36, 80);
				p.st = 1; p.vr = 0; p.vx = 0;
			}
			if (b === 'fly' || b === 'vee') {
				p.dir = sgn();
				p.x = p.dir > 0 ? -50 : vw + 50;
				/* A crosser is only worth watching on a row where something
				 * can be seen, and it enters from one edge — so weight the
				 * band toward open cells on THAT side. */
				p.y = def.low ? openBandY(vh * 0.72, vh * 0.88, p.dir > 0 ? 0 : 2)
					: openBandY(vh * 0.08, vh * 0.55, p.dir > 0 ? 0 : 2);
				p.vx = p.dir * rnd(30, 70) * slow;
				p.vy = 0; p.vr = 0;
				p.n = b === 'vee' ? 2 + ((rand() * 3) | 0) : 1;
				if (anywhere) { p.x = openX(0, vw, p.y); }
			}
			if (b === 'cruise') {
				p.dir = sgn();
				p.x = anywhere ? rnd(0, vw) : (p.dir > 0 ? -60 : vw + 60);
				p.y = waterY;
				p.vx = p.dir * rnd(28, 50);
				p.vy = 0; p.vr = 0;
				p.wake = rnd(2, 4);
			}
			if (b === 'pulse') {
				if (anywhere) { spreadPlace(p, 0, vw, 0, vh); }
				else { spreadPlace(p, 0, vw, vh + 20, vh + 20); }
				p.vy = -rnd(6, 12) * (p.far ? 0.5 : 1); p.vr = 0; p.sw = 10;
			}
			if (b === 'orbit') {
				spreadPlace(p, vw * 0.15, vw * 0.85, vh * 0.15, vh * 0.6);
				p.vx = rnd(-5, 5); p.vy = rnd(-4, -1);
				p.orr = rnd(14, 22); p.vr = 0;
			}
			if (b === 'dangle') {
				spreadPlace(p, vw * 0.1, vw * 0.9, 0, 0);
				p.dy = water ? waterY - 40 : rnd(vh * 0.2, vh * 0.5);
				p.st = 1; p.t = 0; p.vr = 0;
			}
			if (b === 'hang') {
				spreadPlace(p, vw * 0.05, vw * 0.95, p.y, p.y);
				p.len = rnd(30, 80);
				p.vr = 0;
			}
			if (b === 'toss') {
				p.dir = sgn();
				p.x = p.dir > 0 ? -20 : vw + 20;
				p.y = rnd(-40, 0);
				p.vx = p.dir * rnd(120, 220);
				p.vy = rnd(-30, 10);
				p.vr = rnd(-5, 5);
			}
			if (b === 'hop' || b === 'waddle' || b === 'chatter') {
				p.dir = sgn();
				p.x = anywhere ? openX(0, vw, p.y) : (p.dir > 0 ? -30 : vw + 30);
				p.vx = p.dir * (b === 'hop' ? rnd(40, 80) : b === 'chatter' ? rnd(50, 90) : rnd(15, 30));
				p.vy = 0; p.vr = 0;
				p.hopH = rnd(20, 40);
			}
			if (b === 'dart') {
				spreadPlace(p, vw * 0.1, vw * 0.9, vh * 0.1, vh * 0.66);
				p.hx = p.x; p.hy = p.y;
				p.st = 1; p.t = rnd(1, 2.5); p.darts = 4 + ((rand() * 3) | 0); p.vr = 0;
			}
			if (b === 'twinkle') {
				spreadPlace(p, 0, vw, 0, vh * 0.85);
				p.vx = 2; p.vy = 0; p.vr = 0;
				p.t = rnd(6, 10);
			}
			if (b === 'jump') {
				p.st = 1; p.t = rnd(3, 10); p.vr = 0;
			}
			if (b === 'firefly') {
				spreadPlace(p, 0, vw, vh * 0.4, vh * 0.85);
				p.vx = rnd(-8, 8); p.vy = rnd(-6, 6); p.vr = 0;
			}
			if (b === 'frogger') {
				p.st = 1; p.t = rnd(2, 5); p.pad = null; p.vr = 0;
				p.x = rnd(vw * 0.2, vw * 0.8); p.y = waterY;
			}
			if (def.cl) {
				p.color = pick(def.cl);
				p.color2 = pick(def.cl);
				var guard = 4;
				while (p.color2 === p.color && guard--) { p.color2 = pick(def.cl); }
				p.deco = rand() < 0.5 ? 1 : 0;
			}
			return p;
		}

		function settleLand(p) {
			p.settled = 1;
			p.vy = 0;
			p.vx = rnd(-8, 8);
			p.t = 2;
			p.y = waterY;
			addRipple(p.x, waterY);
			if (themeKey === 'christmas') { snowLand(p.x); }
		}

		/* --- Pointer awareness: observation only. The canvas never takes
		 * events; we listen on the document and gently repel nearby NEAR
		 * particles (≤30px, spring back). A click landing on a particle pops
		 * it — the page receives the click untouched. --- */
		var ptr = { x: -9999, y: -9999, on: false };
		function onMove(e) { ptr.x = e.clientX; ptr.y = e.clientY; ptr.on = true; }
		function pokeAt(x, y) {
			var best = null, bd = 26 * 26;
			for (var k = 0; k < parts.length; k++) {
				var p = parts[k];
				if (p.dormant || p.alpha <= 0 || p.far || p.pop) { continue; }
				var dx = p.x + p.ox - x, dy = p.y + p.oy - y;
				var d2 = dx * dx + dy * dy;
				if (d2 < bd) { bd = d2; best = p; }
			}
			if (best) {
				best.pop = 0.001; /* pop animation: spin, shrink, fade */
				best.vr = rnd(6, 10) * (sgn());
				best.vx += rnd(-30, 30);
				addRing(x, y);
			}
		}
		function onClick(e) { pokeAt(e.clientX, e.clientY); }
		function onTouch(e) {
			var t = e.touches && e.touches[0];
			if (t) { pokeAt(t.clientX, t.clientY); }
		}
		if (FX.pointer) {
			D.addEventListener('pointermove', onMove, { passive: true });
			D.addEventListener('click', onClick, { passive: true });
			D.addEventListener('touchstart', onTouch, { passive: true });
		}
		function repel(p, dt) {
			if (!FX.pointer || !ptr.on || p.far) {
				p.ox *= 0.9; p.oy *= 0.9;
				return;
			}
			var dx = p.x - ptr.x, dy = p.y - ptr.y;
			var d2 = dx * dx + dy * dy;
			if (d2 < 4900 && d2 > 0.01) {
				var d = sqrt(d2);
				var f = (1 - d / 70) * 30;
				p.ox += ((dx / d) * f - p.ox) * mn(1, dt * 8);
				p.oy += ((dy / d) * f - p.oy) * mn(1, dt * 8);
			} else {
				p.ox *= 0.92; p.oy *= 0.92;
			}
		}

		function step(p, dt, t) {
			var b = p.b, off = 40;
			p.ph += dt * p.phv;
			p.rot += p.vr * dt;
			if (p.pop) { /* click reaction: spin off and fade fast */
				p.pop += dt;
				p.x += p.vx * dt;
				p.y += p.vy * dt;
				p.alpha = clamp(1 - p.pop * 2, 0, 1);
				p.sc *= 1 - dt * 1.2;
				if (p.pop > 0.55) { seed(p); }
				return;
			}
			switch (b) {
				case 'fall': case 'sway': case 'tumble': case 'spin':
					if (p.settled) {
						p.x += p.vx * dt;
						p.t -= dt;
						p.alpha = clamp(p.t / 2, 0, 1);
						if (p.t <= 0) { seed(p); }
						return;
					}
					p.x += p.vx * dt + sin(p.ph) * p.sw * dt;
					p.y += p.vy * dt;
					if (p.sp.def.glint) { p.alpha = rand() < 0.03 ? 1 : 0.75; }
					if (p.sp.def.fx === 'trail') { /* quill ink squiggle */
						if (!p.trail) { p.trail = []; }
						if (!p.trail.length || abs(p.trail[p.trail.length - 1][1] - p.y) > 6) {
							p.trail.push([p.x, p.y]);
							if (p.trail.length > 8) { p.trail.shift(); }
						}
					}
					if (!up && water && p.sp.def.st && !p.far && p.y >= waterY) { settleLand(p); return; }
					if (p.y > vh + off || p.y < -off) { seed(p); }
					break;
				case 'wobble':
					p.x += sin(p.ph) * 18 * dt + p.vx * dt * 0.3;
					p.y += p.vy * dt;
					p.alpha = 0.35 + 0.35 * sin(p.ph * 0.7);
					if (p.y > vh + off) { seed(p); }
					break;
				case 'flutter':
					p.x += p.vx * dt;
					p.y += sin(p.ph * 2) * 30 * dt;
					if (rand() < dt * 0.4) { p.vx = -p.vx; }
					if (p.x < -off || p.x > vw + off) { seed(p); }
					break;
				case 'float':
					p.x += p.vx * dt + sin(p.ph * 0.4) * 4 * dt;
					p.y = waterY + sin(p.ph) * 3;
					p.rot = sin(p.ph) * 0.08;
					if (p.x < -off || p.x > vw + off) { seed(p); }
					break;
				case 'rise':
					p.x += sin(p.ph) * p.sw * dt;
					p.y += p.vy * dt;
					p.alpha = clamp(p.y / (vh * 0.3), 0, 1);
					if (p.y < -off) { seed(p); }
					break;
				case 'grow':
					if (p.st === 1) {
						p.y += (p.gy - p.y) * mn(1, dt * 2);
						if (abs(p.y - p.gy) < 2) { p.st = 2; p.t = rnd(2.5, 4.5); p.litAt = t; }
					} else if (p.st === 2) {
						p.rot = sin(p.ph) * 0.05;
						p.t -= dt;
						if (p.t <= 0) { p.st = 3; p.t = 1; }
					} else {
						p.t -= dt;
						p.alpha = clamp(p.t, 0, 1);
						if (p.t <= 0) { seed(p); }
					}
					break;
				case 'berrycycle':
					/* bloom → hold → morph to berry → drop off */
					if (p.st === 1) {
						p.y += (p.gy - p.y) * mn(1, dt * 2);
						p.morph = 0;
						if (abs(p.y - p.gy) < 2) { p.st = 2; p.t = 2; }
					} else if (p.st === 2) {
						p.t -= dt;
						if (p.t <= 0) { p.st = 3; p.t = 2; }
					} else if (p.st === 3) {
						p.t -= dt;
						p.morph = clamp(1 - p.t / 2, 0, 1);
						if (p.t <= 0) { p.st = 4; p.vy = 30; }
					} else {
						p.vy += 200 * dt;
						p.y += p.vy * dt;
						p.rot += dt * 3;
						if (p.y > vh + off) { seed(p); }
					}
					break;
				case 'fly': case 'vee':
					p.x += p.vx * dt;
					p.y += sin(p.ph) * 6 * dt;
					if ((p.dir > 0 && p.x > vw + 60) || (p.dir < 0 && p.x < -60)) { seed(p); }
					break;
				case 'cruise':
					p.x += p.vx * dt;
					p.y = waterY - p.size * 0.18 + sin(p.ph) * 2;
					p.rot = sin(p.ph) * 0.04;
					p.wake -= dt;
					if (p.wake <= 0) {
						addRipple(p.x - p.dir * p.size * 0.6, waterY + 2);
						p.wake = rnd(2, 4);
					}
					if ((p.dir > 0 && p.x > vw + 80) || (p.dir < 0 && p.x < -80)) { seed(p); }
					break;
				case 'pulse':
					p.x += sin(p.ph) * p.sw * dt;
					p.y += p.vy * dt;
					if (p.y < -off) { seed(p); }
					break;
				case 'orbit':
					p.x += p.vx * dt;
					p.y += p.vy * dt;
					if (p.y < -off || p.x < -off || p.x > vw + off) { seed(p); }
					break;
				case 'dangle':
					if (p.st === 1) {
						p.y += 40 * dt;
						if (p.y >= p.dy) { p.st = 2; p.t = rnd(1.5, 3); }
					} else if (p.st === 2) {
						p.t -= dt;
						p.x += sin(p.ph) * 3 * dt;
						if (p.t <= 0) { p.st = 3; }
					} else if (p.st === 3) {
						p.y -= 60 * dt;
						if (p.y <= 0) { p.st = 4; p.t = rnd(3, 8); p.alpha = 0; }
					} else {
						p.t -= dt;
						if (p.t <= 0) { seed(p); p.alpha = 1; }
					}
					break;
				case 'hang':
					p.rot = sin(p.ph) * 0.12;
					break;
				case 'toss':
					p.vy += 160 * dt;
					p.x += p.vx * dt;
					p.y += p.vy * dt;
					if (water && p.y >= waterY) { addRipple(p.x, waterY); seed(p); return; }
					if (p.y > vh + off || p.x < -60 || p.x > vw + 60) { seed(p); }
					break;
				case 'hop':
					p.x += p.vx * dt;
					p.y = ground - abs(sin(p.ph * 3)) * p.hopH;
					if (p.x < -60 || p.x > vw + 60) { seed(p); }
					break;
				case 'waddle': case 'chatter':
					p.x += p.vx * dt;
					p.y = ground + sin(p.ph * 6) * 2;
					p.rot = sin(p.ph * 6) * 0.08;
					if (p.x < -60 || p.x > vw + 60) { seed(p); }
					break;
				case 'dart':
					if (p.st === 1) {
						p.x = p.hx + sin(p.ph * 5) * 3;
						p.y = p.hy + cos(p.ph * 4) * 3;
						p.t -= dt;
						if (p.t <= 0) {
							p.st = 2;
							p.tx = clamp(p.hx + rnd(-150, 150), 20, vw - 20);
							p.ty = clamp(p.hy + rnd(-100, 100), 20, vh * 0.7);
						}
					} else {
						p.x += (p.tx - p.x) * mn(1, dt * 6);
						p.y += (p.ty - p.y) * mn(1, dt * 6);
						if (abs(p.x - p.tx) < 4 && abs(p.y - p.ty) < 4) {
							p.hx = p.tx; p.hy = p.ty;
							p.st = 1; p.t = rnd(1, 2.5);
							if (--p.darts <= 0) { seed(p); }
						}
					}
					break;
				case 'twinkle':
					p.alpha = 0.25 + 0.75 * abs(sin(p.ph));
					p.x += p.vx * dt;
					p.t -= dt;
					if (p.t <= 0) { seed(p, true); p.t = rnd(6, 10); }
					break;
				case 'firefly':
					p.x += p.vx * dt + sin(p.ph * 0.7) * 10 * dt;
					p.y += p.vy * dt + cos(p.ph * 0.5) * 8 * dt;
					if (p.x < -off || p.x > vw + off || p.y < vh * 0.2 || p.y > vh) { seed(p); }
					break;
				case 'jump':
					if (p.st === 1) {
						p.alpha = 0;
						p.t -= dt;
						if (p.t <= 0) {
							p.st = 2;
							p.x = rnd(vw * 0.1, vw * 0.9);
							p.y = waterY + 6;
							p.vy = -rnd(290, 350);
							p.vx = rnd(-40, 40);
							p.alpha = 1;
							addRipple(p.x, waterY);
						}
					} else {
						p.vy += 420 * dt;
						p.x += p.vx * dt;
						p.y += p.vy * dt;
						p.rot = atan2(p.vy, p.vx * 4) * 0.5;
						if (p.vy > 0 && p.y >= waterY) {
							addRipple(p.x, waterY, true);
							p.st = 1; p.t = rnd(4, 12); p.alpha = 0;
						}
					}
					break;
				case 'frogger':
					/* sit on a lily pad, hop to another every few seconds */
					if (p.st === 1) {
						if (p.pad && !p.pad.dormant && p.pad.b === 'float') {
							p.x = p.pad.x; p.y = p.pad.y - p.size * 0.5;
						} else { p.y = waterY - p.size * 0.4; }
						p.t -= dt;
						if (p.t <= 0) {
							var pads = [];
							for (var q = 0; q < parts.length; q++) {
								var c = parts[q];
								if (c !== p && !c.dormant && c.b === 'float' && c.alpha > 0) { pads.push(c); }
							}
							p.st = 2;
							p.pad = pads.length ? pick(pads) : null;
							p.jx = p.x; p.jy = p.y;
							p.tx = p.pad ? p.pad.x : rnd(vw * 0.1, vw * 0.9);
							p.ty = (p.pad ? p.pad.y : waterY) - p.size * 0.5;
							p.t = 0;
						}
					} else {
						p.t += dt * 2.2;
						var u = mn(1, p.t);
						p.x = lerp(p.jx, p.tx, u);
						p.y = lerp(p.jy, p.ty, u) - sin(u * MT.PI) * 46;
						if (u >= 1) {
							p.st = 1; p.t = rnd(3, 6);
							if (!p.pad) { addRipple(p.x, waterY); }
						}
					}
					break;
			}
		}

		/* --- Facing + drawing --- */
		function facingRight(p) {
			var b = p.b;
			if (b === 'fly' || b === 'vee' || b === 'hop' || b === 'waddle' || b === 'chatter' || b === 'cruise') {
				return p.dir > 0;
			}
			if (b === 'frogger') { return p.tx > p.jx; }
			return p.vx > 0;
		}

		function drawGlyph(p, s, flip, t) {
			var sp = p.sp;
			if (flip && sp.kind === 'c') { flip = false; }
			if (flip) { cx.save(); cx.scale(-1, 1); }
			if (sp.kind === 'e' || sp.kind === 't') {
				cx.font = MT.round(p.size * s) + FT;
				if (sp.def.glow) {
					cx.save();
					cx.globalAlpha *= 0.35 * (evening ? 1.3 : 1);
					cx.fillStyle = '#FF922B';
					cx.beginPath();
					cx.arc(0, 0, p.size * 0.65 * s * (evening ? 1.3 : 1), 0, TAU);
					cx.fill();
					cx.restore();
				}
				if (sp.kind === 't') { cx.fillStyle = sp.color; }
				cx.fillText(sp.g, 0, 0);
			} else if (sp.kind === 's') {
				var key = p.sKey;
				if (sp.def.fx === 'letter') { key = p.y > vh * 0.5 ? 'letter1' : 'letter0'; }
				if (sp.def.glow) { /* jack-o'-lantern flicker glow */
					var fl = 0.3 + 0.15 * sin(p.ph * 7) + (evening ? 0.12 : 0);
					cx.save();
					cx.globalAlpha *= fl;
					cx.fillStyle = '#FFB44D';
					cx.beginPath();
					cx.arc(0, 0, p.size * 0.8 * s, 0, TAU);
					cx.fill();
					cx.restore();
				}
				var im = sprite(key);
				if (im.ready) {
					var w = p.size * 1.3 * s, h = w * im.ratio;
					cx.drawImage(im.img, -w / 2, -h / 2, w, h);
					fxExtras(p, s, w, h, t);
				}
			} else if (sp.kind === 'c') {
				PRIMS[sp.c](cx, p, s, t);
			}
			if (flip) { cx.restore(); }
		}

		/* Sprite draw extras: smoke, glint sweep, tree lights, balloon
		 * string, letter hearts, bead shine handled in art, orbit arrows,
		 * trailing chicks. */
		function fxExtras(p, s, w, h, t) {
			var fx = p.sp.def.fx || (evening && p.sKey === 'pontoon' ? 'deck' : 0);
			if (!fx) { return; }
			if (fx === 'smoke') {
				cx.strokeStyle = 'rgba(160,160,160,.6)';
				cx.lineWidth = 1.4;
				cx.lineCap = 'round';
				for (var i = 0; i < 2; i++) {
					var phw = p.ph * 1.4 + i * 2;
					cx.beginPath();
					cx.moveTo((i - 0.5) * w * 0.3, -h * 0.5);
					cx.quadraticCurveTo((i - 0.5) * w * 0.3 + sin(phw) * 5, -h * 0.75, (i - 0.5) * w * 0.3 + sin(phw * 1.3) * 7, -h * 0.95);
					cx.stroke();
				}
			} else if (fx === 'glint') {
				var gx = ((t / 1800) % 1) * w * 1.6 - w * 0.8;
				cx.save();
				cx.globalAlpha *= 0.55;
				cx.strokeStyle = '#FFFFFF';
				cx.lineWidth = 2;
				cx.beginPath();
				cx.moveTo(gx - 3, h * 0.4);
				cx.lineTo(gx + 3, -h * 0.4);
				cx.stroke();
				cx.restore();
			} else if (fx === 'lights' && p.st >= 2) {
				/* pine pops its lights on string by string after growing */
				var strings = mn(3, 1 + (((t - (p.litAt || t)) / 700) | 0));
				var cols = ['#FFD43B', '#E03131', '#4DABF7'];
				for (var r2 = 0; r2 < strings; r2++) {
					var yy = -h * 0.32 + r2 * h * 0.22;
					var wid = w * (0.24 + r2 * 0.14);
					for (var k2 = -1; k2 <= 1; k2++) {
						cx.fillStyle = cols[(r2 + k2 + 3) % 3];
						cx.beginPath();
						cx.arc(k2 * wid, yy + abs(k2) * 2, 1.6, 0, TAU);
						cx.fill();
					}
				}
			} else if (fx === 'string') {
				cx.strokeStyle = 'rgba(160,160,160,.8)';
				cx.lineWidth = 1;
				cx.beginPath();
				cx.moveTo(0, h * 0.5);
				cx.quadraticCurveTo(sin(p.ph * 1.6) * 6, h * 0.9, sin(p.ph) * 8, h * 1.3);
				cx.stroke();
			} else if (fx === 'letter' && p.y > vh * 0.5) {
				/* three tiny hearts drift up from the opened letter */
				cx.fillStyle = '#FA5252';
				cx.font = 10 + FT;
				for (var m2 = 0; m2 < 3; m2++) {
					var lp = (p.ph * 0.5 + m2 * 0.33) % 1;
					cx.globalAlpha = alphaBase * (1 - lp);
					cx.fillText('♥', (m2 - 1) * 8 + sin(p.ph + m2) * 3, -h * 0.6 - lp * 22);
				}
				cx.globalAlpha = alphaBase;
			} else if (fx === 'orbitarrows') {
				cx.save();
				cx.rotate(p.ph);
				cx.strokeStyle = '#2F9E44';
				cx.lineWidth = 2;
				for (var a2 = 0; a2 < 2; a2++) {
					cx.beginPath();
					cx.arc(0, 0, w * 0.62, a2 * MT.PI + 0.3, a2 * MT.PI + 2.4);
					cx.stroke();
				}
				cx.restore();
			} else if (fx === 'chicks') {
				/* turkey leads two chicks — drawn behind, un-mirrored space */
				var cim = sprite('chick');
				if (cim.ready) {
					for (var c2 = 1; c2 <= 2; c2++) {
						var cw = w * 0.42;
						cx.drawImage(cim.img, w * 0.55 + c2 * cw * 0.9 - cw / 2, h * 0.5 - cw * cim.ratio + sin(p.ph * 6 + c2) * 1.5 - 1, cw, cw * cim.ratio);
					}
				}
			} else if (fx === 'deck' && evening) {
				var dcols = ['#FFD43B', '#FFE066'];
				for (var d2 = -2; d2 <= 2; d2++) {
					cx.fillStyle = dcols[(d2 + 2) % 2];
					cx.beginPath();
					cx.arc(d2 * w * 0.18, -h * 0.28, 1.5, 0, TAU);
					cx.fill();
				}
			}
		}

		function drawP(p, t) {
			if (p.dormant || p.alpha <= 0) { return; }
			var b = p.b;
			var layerA = p.far ? 0.6 : 1;
			var layerS = p.far ? 0.6 : 1;
			cx.save();
			cx.globalAlpha = alphaBase * clamp(p.alpha, 0, 1) * layerA * (evening ? 0.9 : 1);
			if (b === 'dangle' && p.st !== 4) {
				cx.strokeStyle = 'rgba(90,90,90,.6)';
				cx.lineWidth = 1;
				cx.beginPath(); cx.moveTo(p.x, 0); cx.lineTo(p.x, p.y); cx.stroke();
			}
			if (b === 'hang') {
				cx.strokeStyle = 'rgba(120,120,120,.5)';
				cx.lineWidth = 1;
				cx.beginPath(); cx.moveTo(p.x, 0); cx.lineTo(p.x + sin(p.ph) * 8, p.len); cx.stroke();
			}
			if (p.trail && p.trail.length > 1) { /* quill ink squiggle */
				cx.strokeStyle = 'rgba(52,58,64,.4)';
				cx.lineWidth = 1;
				cx.beginPath();
				for (var q2 = 0; q2 < p.trail.length; q2++) {
					var tp = p.trail[q2];
					cx[q2 ? 'lineTo' : 'moveTo'](tp[0] + sin(q2 * 2.6) * 4, tp[1]);
				}
				cx.stroke();
			}
			var px = p.x + p.ox, py = p.y + p.oy;
			if (b === 'hang') { px = p.x + sin(p.ph) * 8; py = p.len + p.size * 0.5; }
			cx.translate(px, py);
			if (p.rot) { cx.rotate(p.rot); }
			var s = p.sc * layerS;
			var flip = !!(p.sp.def.face && facingRight(p));
			if (b === 'pulse') { s *= 1 + 0.18 * sin(p.ph * 2.2); }
			if (b === 'berrycycle') { /* blossom morphs into a swelling berry */
				var mo = p.morph || 0;
				if (mo < 1) {
					cx.save();
					cx.globalAlpha *= (1 - mo);
					var bim = sprite('blossom');
					if (bim.ready) { var bw = p.size * (1 - mo * 0.4); cx.drawImage(bim.img, -bw / 2, -bw / 2, bw, bw); }
					cx.restore();
				}
				if (mo > 0 || p.st === 4) {
					var rim = sprite('berry');
					if (rim.ready) {
						var rw = p.size * (0.4 + 0.9 * (p.st === 4 ? 1 : mo));
						cx.globalAlpha *= (p.st === 4 ? 1 : mx2(0.25, mo));
						cx.drawImage(rim.img, -rw / 2, -rw / 2, rw, rw * rim.ratio);
					}
				}
			} else if (b === 'orbit') {
				for (var k = 0; k < 2; k++) {
					cx.save();
					cx.translate(cos(p.ph + k * MT.PI) * p.orr, sin(p.ph + k * MT.PI) * p.orr * 0.5);
					drawGlyph(p, s * 0.85, flip, t);
					cx.restore();
				}
			} else if (b === 'vee') {
				var offs = [[0, 0], [-24, 12], [-24, -12], [-48, 24]];
				for (var m = 0; m < p.n && m < offs.length; m++) {
					cx.save();
					cx.translate(offs[m][0] * (p.dir > 0 ? 1 : -1), offs[m][1]);
					drawGlyph(p, s * (m ? 0.85 : 1), flip, t);
					cx.restore();
				}
			} else if (p.sp.def.worm && p.b === 'dangle' && p.st === 2) {
				drawGlyph(p, s, flip, t);
				cx.font = MT.round(p.size * 0.7) + FT;
				cx.fillText(drawable('🪱') ? '🪱' : '~', 0, p.size * 0.8);
			} else {
				drawGlyph(p, s, flip, t);
			}
			cx.restore();
		}

		/* --- Waterline reflections: near actors just above the water get a
		 * flipped, squashed 25% mirror; floaters get a broken shimmer. --- */
		function drawReflections(t) {
			if (!FX.reflect) { return; }
			for (var k = 0; k < parts.length; k++) {
				var p = parts[k];
				if (p.dormant || p.far || p.alpha <= 0) { continue; }
				if (p.b === 'float' || p.b === 'cruise') {
					cx.save();
					cx.globalAlpha = alphaBase * 0.28 * (0.6 + 0.4 * sin(p.ph * 2));
					cx.strokeStyle = '#DDEAF5';
					cx.lineWidth = 1.4;
					var wd = p.size * 0.5;
					cx.beginPath();
					cx.moveTo(p.x - wd, waterY + 5); cx.lineTo(p.x - wd * 0.3, waterY + 5);
					cx.moveTo(p.x + wd * 0.15, waterY + 8); cx.lineTo(p.x + wd * 0.7, waterY + 8);
					cx.stroke();
					cx.restore();
					continue;
				}
				var dy = waterY - p.y;
				if (dy <= 0 || dy > 60) { continue; }
				cx.save();
				cx.globalAlpha = alphaBase * 0.25 * clamp(p.alpha, 0, 1);
				cx.translate(p.x + p.ox, waterY + dy * 0.55);
				cx.scale(1, -0.55);
				if (p.rot) { cx.rotate(-p.rot); }
				drawGlyph(p, p.sc, !!(p.sp.def.face && facingRight(p)), t);
				cx.restore();
			}
			if (hero && hero.kind === 'bass' && hero.g && waterY - hero.y > 0 && waterY - hero.y < 90) {
				cx.save();
				cx.globalAlpha = alphaBase * 0.25;
				cx.translate(hero.x, waterY + (waterY - hero.y) * 0.55);
				cx.scale(1, -0.55);
				cx.font = 40 + FT;
				cx.fillText(hero.g, 0, 0);
				cx.restore();
			}
		}

		/* --- Burst mode (New Year's): firework emitter + auto-year. --- */
		var nextBurst = 0, yearFx = null, flash = null;
		var yearNow = localNow();
		var yearText = String(yearNow.getFullYear() + (yearNow.getMonth() >= 6 ? 1 : 0));
		var sparkCl = A.sparkCl || ['#FFD43B', '#CED4DA'];
		var bursts = [];
		function fire(t) {
			var bx = rnd(vw * 0.18, vw * 0.82), by = rnd(vh * 0.12, vh * 0.42);
			var col = pick(sparkCl), n = 26, sp = [];
			for (var i = 0; i < n; i++) {
				var a = (i / n) * TAU + rnd(-0.09, 0.09), v = rnd(150, 265);
				sp.push({ x: bx, y: by, vx: cos(a) * v, vy: sin(a) * v });
			}
			bursts.push({ s: sp, life: 0, col: col });
			if (bursts.length > 2) { bursts.shift(); }
			flash = { x: bx, y: by, a: 1 };
			/* The rising year is New Year's only — Independence Day shares the
			 * burst machinery and must not announce "2027" in July. */
			if (themeKey === 'new_years') { yearFx = { x: bx, y: by, a: 1.4 }; }
			nextBurst = t + rnd(1400, 2800);
		}
		function stepBursts(dt) {
			for (var k = bursts.length - 1; k >= 0; k--) {
				var b2 = bursts[k];
				b2.life += dt;
				var fade = clamp(1 - b2.life / 1.6, 0, 1);
				if (fade <= 0) { bursts.splice(k, 1); continue; }
				cx.save();
				cx.globalAlpha = mn(1, alphaBase * 1.9) * fade;
				cx.strokeStyle = b2.col;
				cx.lineWidth = 2.6;
				cx.lineCap = 'round';
				cx.beginPath();
				for (var i = 0; i < b2.s.length; i++) {
					var q = b2.s[i];
					q.vy += 130 * dt;
					q.x += q.vx * dt;
					q.y += q.vy * dt;
					cx.moveTo(q.x - q.vx * 0.055, q.y - q.vy * 0.055);
					cx.lineTo(q.x, q.y);
				}
				cx.stroke();
				cx.restore();
			}
		}
		function drawFlash(dt) {
			if (!flash) { return; }
			flash.a -= dt * 3.2;
			if (flash.a <= 0) { flash = null; return; }
			cx.save();
			cx.globalAlpha = clamp(flash.a * 0.5, 0, 1);
			cx.fillStyle = '#FFF3C4';
			cx.beginPath();
			cx.arc(flash.x, flash.y, 26 * (1.4 - flash.a), 0, TAU);
			cx.fill();
			cx.restore();
		}

		/* --- Heroes: rare crossers. The heron (3-frame wingbeat, occasional
		 * full landing sequence) is always in the rotation. --- */
		var hero = null, heroNext = 0;
		var heroPool = ['heron'];
		if (A.hero) { heroPool.push(A.hero); }
		var HERON_FRAMES = ['heron0', 'heron1', 'heron2', 'heron1'];
		function spawnHero(t) {
			if (!FX.heroes || vig) { heroNext = t + 4000; return; }
			var kind = pick(heroPool);
			var dir = sgn();
			hero = { kind: kind, dir: dir, t: 0, ph: 0 };
			if (kind === 'heron') {
				hero.x = dir > 0 ? -110 : vw + 110;
				hero.y = rnd(vh * 0.15, vh * 0.45);
				hero.vx = dir * rnd(60, 90);
				hero.w = 96;
				HERON_FRAMES.forEach(sprite); sprite('heronstand');
				/* The only day the heron flies inverted: April Fool's, rarely. */
				hero.invert = themeKey === 'april_fools' && rand() < 0.25;
				/* Classic landing sequence: glide in → land → stand → leave. */
				hero.land = !hero.invert && water && rand() < (themeKey === 'classic' || themeKey === 'florida_keys' ? 0.5 : 0.15);
				if (hero.land) { hero.lx = rnd(vw * 0.25, vw * 0.75); hero.st = 1; }
			} else if (kind === 'eagle' || kind === 'witch') {
				var g = kind === 'eagle' ? '🦅' : '🧙‍♀️';
				if (!drawable(g)) { hero = null; heroNext = t + 5000; return; }
				hero.g = g;
				hero.x = dir > 0 ? -60 : vw + 60;
				hero.y = rnd(vh * 0.1, vh * 0.4);
				hero.vx = dir * rnd(70, 110);
			} else if (kind === 'sleigh') {
				hero.x = dir > 0 ? -140 : vw + 140;
				hero.y = rnd(vh * 0.08, vh * 0.3);
				hero.vx = dir * rnd(80, 120);
				hero.w = 120;
				sprite('sleigh');
			} else if (kind === 'manatee') {
				hero.x = dir > 0 ? -110 : vw + 110;
				hero.y = vh * 0.955;
				hero.vx = dir * rnd(22, 34);
				hero.w = 96;
				hero.rip = 0;
				hero.calf = rand() < 0.5; /* mom with calf */
				sprite('manatee');
			} else if (kind === 'bass') {
				hero.g = drawable('🐟') ? '🐟' : (drawable('🐠') ? '🐠' : null);
				if (!hero.g) { hero = null; heroNext = t + 5000; return; }
				hero.x = rnd(vw * 0.15, vw * 0.85);
				hero.y = waterY + 8;
				hero.vy = -rnd(340, 400);
				hero.vxj = rnd(-50, 50);
				addRipple(hero.x, waterY, true);
			} else if (kind === 'pelican') {
				/* Brown pelicans commute low over the water on stiff,
				 * motionless wings, dropping into a few beats only when
				 * they start to sink. Flying it high and flapping the
				 * whole way is the one thing that would read wrong. */
				hero.x = dir > 0 ? -120 : vw + 120;
				hero.y = water ? waterY - rnd(16, 46) : rnd(vh * 0.3, vh * 0.55);
				hero.vx = dir * rnd(52, 78);
				hero.w = 110;
				hero.fl = 0;
				hero.gl = rnd(1.6, 3);
				sprite('pelican'); sprite('pelican1');
			} else if (kind === 'ducks') {
				hero.x = dir > 0 ? -90 : vw + 90;
				hero.y = ground;
				hero.vx = dir * rnd(30, 45);
			} else if (kind === 'rainbow') {
				hero.corner = rand() < 0.5 ? 0 : 1;
				hero.t = 0;
				sprite('rainbow');
			}
		}
		function stepHero(dt, t) {
			if (!hero) {
				if (!heroNext) { heroNext = t + rnd(heroEvery[0], heroEvery[1]) * 1000; }
				else if (t >= heroNext && !vig) { spawnHero(t); heroNext = 0; }
				return;
			}
			var h = hero;
			h.ph += dt * 2;
			h.t += dt;
			if (h.kind === 'rainbow') {
				if (h.t > 7) { hero = null; }
				return;
			}
			if (h.kind === 'bass') {
				h.vy += 420 * dt;
				h.x += h.vxj * dt;
				h.y += h.vy * dt;
				if (h.vy > 0 && h.y >= waterY) { addRipple(h.x, waterY, true); hero = null; }
				return;
			}
			if (h.kind === 'heron' && h.land) {
				if (h.st === 1) { /* glide toward the landing spot */
					h.x += h.vx * dt;
					var dxl = h.lx - h.x;
					if ((h.dir > 0 && dxl < 140) || (h.dir < 0 && dxl > -140)) {
						h.y += (waterY - 26 - h.y) * mn(1, dt * 1.6);
						h.vx *= 1 - dt * 0.8;
					}
					if (abs(dxl) < 12 || abs(h.vx) < 12) {
						h.st = 2; h.t2 = 2.5;
						addRipple(h.x, waterY);
					}
				} else if (h.st === 2) { /* stand a moment */
					h.y = waterY - 26;
					h.t2 -= dt;
					if (h.t2 <= 0) { h.st = 3; addRipple(h.x, waterY); }
				} else { /* take off */
					h.vx += h.dir * 60 * dt;
					h.x += h.vx * dt;
					h.y -= 55 * dt;
					if ((h.dir > 0 && h.x > vw + 150) || (h.dir < 0 && h.x < -150) || h.y < -80) { hero = null; }
				}
				return;
			}
			h.x += h.vx * dt;
			if (h.kind === 'pelican') {
				/* glide → sink slowly → two beats of lift → glide again */
				h.fl -= dt;
				if (h.fl <= -h.gl) { h.fl = 0.5; h.gl = rnd(1.8, 3.4); }
				h.y += (h.fl > 0 ? -26 : 9) * dt;
				if (water) { h.y = clamp(h.y, waterY - 64, waterY - 10); }
			} else if (h.kind !== 'manatee' && h.kind !== 'ducks') { h.y += sin(h.ph) * 8 * dt; }
			if (h.kind === 'manatee') {
				h.rip -= dt;
				if (h.rip <= 0) { addRipple(h.x + h.dir * 40, waterY + 2); h.rip = rnd(2, 4); }
			}
			if ((h.dir > 0 && h.x > vw + 150) || (h.dir < 0 && h.x < -150)) { hero = null; }
		}
		function drawHero(t) {
			if (!hero) { return; }
			var h = hero;
			cx.save();
			if (h.kind === 'rainbow') {
				/* upgraded corner moment: rainbow + pot + leprechaun hat,
				 * coin arcs clinking in, a clover strip that grows and fades */
				var a = h.t < 1 ? h.t : (h.t > 6 ? clamp(7 - h.t, 0, 1) : 1);
				cx.globalAlpha = clamp(alphaBase * 1.6 * a, 0, 1);
				var im = sprite('rainbow');
				if (im.ready) {
					var w = 150, hh = w * im.ratio;
					var x = h.corner ? vw - w - 10 : 10;
					cx.drawImage(im.img, x, vh - hh - 6, w, hh);
					/* coin arc into the pot */
					if (h.t > 1.4 && h.t < 4.4) {
						var potX = x + w * 0.81, potY = vh - hh * 0.18;
						for (var c3 = 0; c3 < 3; c3++) {
							var cu = (h.t - 1.4 - c3 * 0.5) / 0.9;
							if (cu > 0 && cu < 1) {
								var cxx = lerp(x + w * 0.2, potX, cu);
								var cyy = lerp(vh - hh * 0.9, potY, cu) - sin(cu * MT.PI) * 46;
								cx.fillStyle = '#F1C40F';
								cx.beginPath(); cx.arc(cxx, cyy, 3.2, 0, TAU); cx.fill();
								if (cu > 0.94) { addRing(potX, potY - 6); }
							}
						}
					}
					/* clover strip along the bottom */
					cx.fillStyle = '#2F9E44';
					for (var v3 = 0; v3 < 6; v3++) {
						var gu = clamp((h.t - 0.6 - v3 * 0.18) / 0.5, 0, 1);
						if (gu > 0) {
							var gx2 = (h.corner ? vw - 190 : 40) + v3 * 26;
							cx.font = MT.round(8 + gu * 6) + FT;
							cx.fillText('☘', gx2, vh - 4 - gu * 4);
						}
					}
				}
				cx.restore();
				return;
			}
			cx.globalAlpha = mn(1, alphaBase * 2) * (h.kind === 'manatee' ? 0.55 : 1) * (evening ? 0.92 : 1);
			cx.translate(h.x, h.y);
			if (h.kind === 'heron') {
				var stand = h.land && h.st === 2;
				var frame = stand ? 'heronstand' : HERON_FRAMES[((t / 260) | 0) % 4];
				var him = sprite(frame);
				if (him.ready) {
					if (h.dir > 0) { cx.scale(-1, 1); }
					if (h.invert) { cx.scale(1, -1); }
					var hw = stand ? 52 : h.w;
					cx.drawImage(him.img, -hw / 2, -hw * him.ratio / 2, hw, hw * him.ratio);
				}
			} else if (h.kind === 'sleigh' || h.kind === 'manatee' || h.kind === 'pelican') {
				var sim = sprite(h.kind === 'pelican' ? (h.fl > 0 ? 'pelican1' : 'pelican') : h.kind);
				if (sim.ready) {
					if (h.dir > 0) { cx.scale(-1, 1); }
					cx.drawImage(sim.img, -h.w / 2, -h.w * sim.ratio / 2, h.w, h.w * sim.ratio);
					if (h.kind === 'manatee' && h.calf) {
						cx.drawImage(sim.img, h.w * 0.42, -h.w * sim.ratio * 0.1, h.w * 0.5, h.w * 0.5 * sim.ratio);
					}
				}
			} else if (h.kind === 'bass') {
				cx.rotate(atan2(h.vy, h.vxj * 4) * 0.5);
				if (h.vxj > 0) { cx.scale(-1, 1); }
				cx.font = 40 + FT;
				cx.fillText(h.g, 0, 0);
			} else if (h.kind === 'eagle' || h.kind === 'witch') {
				cx.font = 42 + FT;
				if (h.kind === 'witch') { cx.rotate(h.dir * -0.15); }
				if (h.dir > 0) { cx.scale(-1, 1); }
				cx.fillText(h.g, 0, 0);
			} else if (h.kind === 'ducks') {
				var duck = drawable('🦆') ? '🦆' : '🐤';
				var chick = drawable('🐥') ? '🐥' : '🐤';
				var duckling = function (g, ox, oy, fs) {
					cx.save();
					cx.translate(ox, oy);
					if (h.dir > 0) { cx.scale(-1, 1); }
					cx.font = fs + FT;
					cx.fillText(g, 0, 0);
					cx.restore();
				};
				duckling(duck, 0, sin(h.ph * 3) * 2, 30);
				duckling(chick, -h.dir * 30, sin(h.ph * 3 + 1) * 2, 20);
				duckling(chick, -h.dir * 54, sin(h.ph * 3 + 2) * 2, 20);
			}
			cx.restore();
		}

		/* --- Vignette director: rare 5–12s choreographed scenes. One at a
		 * time, ≥90s apart, first ≥20s in, never alongside a hero, actors
		 * borrow (dormant) pool slots so the cap holds. --- */
		var vig = null, vigNext = 0, countdownDone = false;
		var VA = mn(1, alphaBase * 2.2); /* scenes read a touch stronger */
		function dspr(key, x, y, w, flipX, rot, alpha) {
			var im = sprite(key);
			if (!im.ready) { return; }
			cx.save();
			cx.globalAlpha = clamp(alpha == null ? VA : alpha, 0, 1);
			cx.translate(x, y);
			if (rot) { cx.rotate(rot); }
			if (flipX) { cx.scale(-1, 1); }
			cx.drawImage(im.img, -w / 2, -w * im.ratio / 2, w, w * im.ratio);
			cx.restore();
		}
		function dtxt(g, x, y, fs, color, alpha, rot, flipX) {
			cx.save();
			cx.globalAlpha = clamp(alpha == null ? VA : alpha, 0, 1);
			cx.translate(x, y);
			if (rot) { cx.rotate(rot); }
			if (flipX) { cx.scale(-1, 1); }
			cx.font = (fs | 0) + FT;
			cx.textAlign = 'center';
			if (color) { cx.fillStyle = color; }
			cx.fillText(g, 0, 0);
			cx.restore();
		}
		function sBeg(color, width, alpha) {
			cx.save();
			cx.globalAlpha = alpha == null ? VA * 0.7 : alpha;
			cx.strokeStyle = color;
			cx.lineWidth = width;
			cx.beginPath();
		}
		function sEnd() { cx.stroke(); cx.restore(); }
		function moonDraw(mx, my, a) {
			cx.save();
			cx.globalAlpha = clamp(a * 0.5, 0, 1);
			cx.fillStyle = '#F4EFD8';
			cx.beginPath(); cx.arc(mx, my, 46, 0, TAU); cx.fill();
			cx.globalAlpha = clamp(a * 0.18, 0, 1);
			cx.beginPath(); cx.arc(mx, my, 58, 0, TAU); cx.fill();
			cx.restore();
		}

		function crosserScene(key, w, yOff, speed, onWater) {
			return { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.dir = sgn(); st.x = st.dir > 0 ? -60 : vw + 60; st.ph = 0; st.wk = 1; }
				st.ph += dt * 3.6;
				st.x += st.dir * speed * dt;
				if (onWater) {
					st.wk -= dt;
					if (st.wk <= 0) { addRipple(st.x - st.dir * 20, waterY + 2); st.wk = rnd(0.9, 1.6); }
				}
				var y = onWater ? waterY - 6 : vh - yOff;
				dspr(key, st.x, y + sin(st.ph) * 1.8 + (onWater ? 0 : abs(sin(st.ph)) * -5), w, st.dir > 0, sin(st.ph) * 0.07);
				return (st.dir > 0 && st.x > vw + 70) || (st.dir < 0 && st.x < -70);
			} };
		}
		function flightScene(key, n, w) {
			return { actors: 3, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.dir = sgn(); st.x = st.dir > 0 ? -90 : vw + 90; st.ph = 0; }
				st.ph += dt * 2.4;
				st.x += st.dir * 72 * dt;
				for (var i = 0; i < n; i++) {
					dspr(key, st.x - st.dir * i * 46, vh * 0.26 + i * 22 + sin(st.ph + i) * 9, w * (i ? 0.82 : 1), st.dir > 0, sin(st.ph + i) * 0.09);
				}
				return (st.dir > 0 && st.x > vw + 160) || (st.dir < 0 && st.x < -160);
			} };
		}
		var SCENES = {
			/* Labor Day: three pontoons in loose formation, wakes overlapping */
			flotilla: { actors: 3, run: function (st, dt) {
				if (!st.on) {
					st.on = 1; st.dir = sgn();
					st.boats = [0, 1, 2].map(function (i) {
						return { x: (st.dir > 0 ? -80 : vw + 80) - st.dir * i * 110, y: waterY - 8 - (i % 2) * 10, v: st.dir * rnd(42, 52), ph: rnd(0, TAU), wk: rnd(1, 2) };
					});
				}
				var alive = 0;
				st.boats.forEach(function (b2) {
					b2.x += b2.v * dt; b2.ph += dt * 2;
					b2.wk -= dt;
					if (b2.wk <= 0) { addRipple(b2.x - st.dir * 22, waterY + 2); b2.wk = rnd(1.4, 2.4); }
					if ((st.dir > 0 && b2.x < vw + 90) || (st.dir < 0 && b2.x > -90)) { alive++; }
					dspr('pontoon', b2.x, b2.y + sin(b2.ph) * 2, 40, st.dir > 0, sin(b2.ph) * 0.04);
					if (evening) { /* deck lights */
					cx.save(); cx.globalAlpha = VA; cx.fillStyle = '#FFD43B';
					for (var li = -1; li <= 1; li++) { cx.beginPath(); cx.arc(b2.x + li * 10, b2.y - 10, 1.5, 0, TAU); cx.fill(); }
					cx.restore();
				}
				});
				return alive === 0;
			} },
			/* Fall Fishing: THE full cast — 10 seconds of story */
			fullcast: { actors: 4, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.ph = 0; st.x = rnd(vw * 0.3, vw * 0.7); st.p = 1; st.t2 = 0; }
				st.t2 += dt; st.ph += dt * 3;
				var x = st.x;
				if (st.p === 1) { /* lure arcs in on a line from the top edge */
					var u = mn(1, st.t2 / 1.2);
					var lx = lerp(x - 260, x, easeIO(u)), ly = lerp(-30, waterY, u * u);
					sBeg('#9BA4AD', 1);
					cx.moveTo(lx - 40, 0); cx.quadraticCurveTo(lx - 10, ly * 0.5, lx, ly); sEnd();
					dspr('lure', lx, ly, 16, false, u * 2);
					if (u >= 1) { st.p = 2; st.t2 = 0; addRipple(x, waterY, true); }
				} else if (st.p === 2) { /* bobber settles */
					dspr('bobber', x, waterY - 4 + sin(st.ph) * 2.5, 16);
					lineTo0(x);
					if (st.t2 > 2) { st.p = 3; st.t2 = 0; }
				} else if (st.p === 3) { /* underwater shadow circles in */
					dspr('bobber', x, waterY - 4 + sin(st.ph) * 2, 16);
					lineTo0(x);
					cx.save();
					cx.globalAlpha = VA * 0.28;
					cx.fillStyle = '#20303C';
					var sx = x + cos(st.ph * 0.8) * (60 - st.t2 * 18);
					cx.beginPath(); cx.ellipse(sx, waterY + 8, 26, 6, 0, 0, TAU); cx.fill();
					cx.restore();
					if (st.t2 > 2.5) { st.p = 4; st.t2 = 0; addRipple(x, waterY, true); }
				} else if (st.p === 4) { /* STRIKE — bass leaps, line bends */
					var u2 = mn(1, st.t2 / 1.4);
					var by = waterY - sin(u2 * MT.PI) * 110;
					var bx2 = x + u2 * 30;
					sBeg('#9BA4AD', 1);
					cx.moveTo(bx2 - 40, 0); cx.quadraticCurveTo(bx2 - 60, by * 0.7, bx2, by); sEnd();
					dspr('bass', bx2, by, 46, true, (u2 - 0.5) * 1.6);
					if (st.t2 < 0.3) { for (var dd = 0; dd < 2; dd++) { addRipple(x + rnd(-14, 14), waterY); } }
					if (u2 >= 1) { st.p = 5; st.t2 = 0; addRipple(bx2, waterY, true); }
				} else { /* both exit */
					return st.t2 > 1;
				}
				return false;
				function lineTo0(bx3) {
					sBeg('#9BA4AD', 1);
					cx.moveTo(bx3 - 40, 0); cx.quadraticCurveTo(bx3 - 12, waterY * 0.55, bx3, waterY - 10); sEnd();
				}
			} },
			/* dragonfly lands on the bobber, wings flick twice, departs */
			dragonlands: { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.x = rnd(vw * 0.3, vw * 0.7); st.p = 1; st.t2 = 0; st.dx = st.x - 160; st.dy = waterY - 140; }
				st.t2 += dt;
				dspr(st.tgt || 'bobber', st.x, waterY - 4, 16);
				if (st.p === 1) {
					var u = mn(1, st.t2 / 1.6);
					var fx2 = lerp(st.dx, st.x, easeIO(u)), fy = lerp(st.dy, waterY - 18, easeIO(u));
					dspr('dragonfly', fx2, fy, 26, false, sin(st.t2 * 6) * 0.1);
					if (u >= 1) { st.p = 2; st.t2 = 0; }
				} else if (st.p === 2) { /* wings flick twice (scale pulse) */
					var fl = st.t2 < 0.5 || (st.t2 > 1 && st.t2 < 1.5) ? 1 + sin(st.t2 * 25) * 0.15 : 1;
					dspr('dragonfly', st.x, waterY - 18, 26 * fl);
					if (st.t2 > 2.6) { st.p = 3; st.t2 = 0; }
				} else {
					var u3 = mn(1, st.t2 / 1.2);
					dspr('dragonfly', st.x + u3 * 120, waterY - 18 - u3 * 150, 26, true);
					return u3 >= 1;
				}
				return false;
			} },
			/* Halloween: the witch crosses a faint full moon */
			witchmoon: { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.mx = rand() < 0.5 ? vw * 0.2 : vw * 0.8; st.my = vh * 0.16; st.t2 = 0; }
				st.t2 += dt;
				var a = st.t2 < 1 ? st.t2 : (st.t2 > 5 ? clamp(6 - st.t2, 0, 1) : 1);
				moonDraw(st.mx, st.my, a);
				if (st.t2 > 1.2 && st.t2 < 4.2) {
					var u = (st.t2 - 1.2) / 3;
					var wx = lerp(st.mx - 140, st.mx + 140, u);
					if (drawable('🧙‍♀️')) { dtxt('🧙‍♀️', wx, st.my + sin(u * 6) * 6, 34, null, VA, -0.12); }
					else { dspr('witchhat', wx, st.my, 30, false, -0.2); }
				}
				return st.t2 > 6;
			} },
			/* Christmas: sleigh crosses high and drops a parachuting gift */
			giftdrop: { actors: 3, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.dir = sgn(); st.sx = st.dir > 0 ? -130 : vw + 130; st.gy = -30; st.gd = false; st.t2 = 0; st.ph = 0; st.land = 0; }
				st.t2 += dt; st.ph += dt * 2;
				st.sx += st.dir * 95 * dt;
				var sleighOn = (st.dir > 0 && st.sx < vw + 140) || (st.dir < 0 && st.sx > -140);
				if (sleighOn) { dspr('sleigh', st.sx, vh * 0.14 + sin(st.ph) * 4, 110, st.dir > 0); }
				if (!st.gd && ((st.dir > 0 && st.sx > vw / 2) || (st.dir < 0 && st.sx < vw / 2))) {
					st.gd = true; st.gx = st.sx; st.gy = vh * 0.17;
				}
				if (st.gd && !st.land) {
					st.gy += 55 * dt;
					st.gx += sin(st.ph * 1.4) * 14 * dt;
					var target = waterY - (snowCols ? snowCols[clamp((st.gx / 8) | 0, 0, snowCols.length - 1)] : 0) - 8;
					/* parachute */
					cx.save(); cx.globalAlpha = VA;
					cx.fillStyle = '#E03131';
					cx.beginPath(); cx.arc(st.gx, st.gy - 22, 14, MT.PI, 0); cx.closePath(); cx.fill();
					cx.strokeStyle = '#B8860B'; cx.lineWidth = 1;
					cx.beginPath();
					cx.moveTo(st.gx - 13, st.gy - 21); cx.lineTo(st.gx - 5, st.gy - 6);
					cx.moveTo(st.gx + 13, st.gy - 21); cx.lineTo(st.gx + 5, st.gy - 6);
					cx.stroke(); cx.restore();
					dspr('gift', st.gx, st.gy, 20);
					if (st.gy >= target) { st.land = st.t2; }
				} else if (st.land) {
					dspr('gift', st.gx, st.gy, 20);
					if (st.t2 - st.land > 3) { return true; }
				}
				return !sleighOn && !st.gd;
			} },
			/* evening-only: the sleigh silhouette crosses the moon */
			sleighmoon: { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.mx = vw * 0.75; st.my = vh * 0.15; st.t2 = 0; }
				st.t2 += dt;
				var a = st.t2 < 1 ? st.t2 : (st.t2 > 5 ? clamp(6 - st.t2, 0, 1) : 1);
				moonDraw(st.mx, st.my, a);
				if (st.t2 > 1 && st.t2 < 4.6) {
					var u = (st.t2 - 1) / 3.6;
					dspr('sleigh', lerp(st.mx - 150, st.mx + 150, u), st.my + sin(u * 5) * 5, 100, true);
				}
				return st.t2 > 6;
			} },
			/* New Year's: the cork goes off in a corner. The cork sprite was
			 * retired in 3.15.0 (it read as a mushroom); what flies is the
			 * theme's own sparkle, on the same arc and trail. */
			corkpop: { actors: 3, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.t2 = 0; st.bx = 40; st.by = vh - 40; st.trail = []; }
				st.t2 += dt;
				var tilt = clamp(st.t2 / 0.8, 0, 1) * -0.6;
				dspr('bottle', st.bx, st.by, 18, false, tilt);
				if (st.t2 > 0.9) {
					var u = clamp((st.t2 - 0.9) / 1.4, 0, 1);
					var cxx = st.bx + 14 + u * vw * 0.3;
					var cyy = st.by - 30 - sin(mn(1, u * 1.2) * MT.PI * 0.9) * vh * 0.4;
					if (u < 1) {
						st.trail.push([cxx, cyy]);
						if (st.trail.length > 14) { st.trail.shift(); }
						dspr('sparkle', cxx, cyy, 14, false, u * 9);
					}
					cx.save(); cx.globalAlpha = VA * 0.8; cx.strokeStyle = '#F783AC'; cx.lineWidth = 1.6;
					cx.beginPath();
					for (var q3 = 0; q3 < st.trail.length; q3++) {
						cx[q3 ? 'lineTo' : 'moveTo'](st.trail[q3][0], st.trail[q3][1] + sin(q3) * 3);
					}
					cx.stroke(); cx.restore();
					if (st.t2 < 1.5) { addRing(st.bx + 12, st.by - 32); }
					if (rand() < dt * 4) { addRing(st.bx + rnd(-4, 10), st.by - rnd(20, 60)); }
				}
				return st.t2 > 5.5;
			} },
			/* Snowbird: flamingo V glides down, lands one by one, departs */
			arrival: { actors: 3, run: function (st, dt) {
				if (!st.on) {
					st.on = 1; st.t2 = 0;
					var bx4 = rnd(vw * 0.3, vw * 0.7);
					st.birds = [0, 1, 2].map(function (i) {
						return { tx: bx4 + (i - 1) * 56, x: -60 - i * 46, y: vh * 0.1 + i * 24, land: 1.6 + i * 0.8, st2: 1, ph: rnd(0, TAU) };
					});
				}
				st.t2 += dt;
				var g = drawable('🦩') ? '🦩' : null;
				var done = true;
				st.birds.forEach(function (b3) {
					b3.ph += dt * 3;
					if (b3.st2 === 1) {
						done = false;
						var u = clamp(st.t2 / b3.land, 0, 1);
						b3.x = lerp(b3.x0 == null ? (b3.x0 = b3.x) : b3.x0, b3.tx, easeIO(u));
						b3.y = lerp(vh * 0.1, waterY - 12, u * u);
						if (u >= 1) { b3.st2 = 2; addRipple(b3.tx, waterY); }
					} else if (b3.st2 === 2) {
						b3.x = b3.tx; b3.y = waterY - 12 + sin(b3.ph) * 2;
						if (st.t2 > 6) { b3.st2 = 3; addRipple(b3.tx, waterY); }
						done = false;
					} else {
						b3.x += 90 * dt; b3.y -= 70 * dt;
						if (b3.x < vw + 60 && b3.y > -60) { done = false; }
					}
					if (g) { dtxt(g, b3.x, b3.y, 26, null, VA, 0, true); }
					else { dtxt('v', b3.x, b3.y, 22, '#F783AC'); }
				});
				return done;
			} },
			/* shared crosser: sprite walks/paddles across the bottom or water */
			flagfly: flightScene('flagcloth', 3, 42),
			doveflight: flightScene('dove', 3, 34),
			stilts: crosserScene('stilts', 34, 52, 55, 0),
			kayaker: crosserScene('kayak', 48, 0, 60, 1),
			/* Mardi Gras: golden doubloon shower into the water */
			doubloons: { actors: 3, run: function (st, dt) {
				if (!st.on) {
					st.on = 1; st.t2 = 0; st.corner = rand() < 0.5 ? 0 : vw;
					st.coins = [0, 1, 2, 3, 4, 5].map(function (i) { return { d: i * 0.35, u: 0, tx: rnd(vw * 0.25, vw * 0.75) }; });
				}
				st.t2 += dt;
				var done = true;
				st.coins.forEach(function (c4) {
					var u = clamp((st.t2 - c4.d) / 1.6, 0, 1);
					if (u <= 0) { done = false; return; }
					if (u < 1) {
						done = false;
						var xx = lerp(st.corner, c4.tx, u);
						var yy = lerp(-20, waterY, u) - sin(u * MT.PI) * vh * 0.3;
						dspr('doubloon', xx, yy, 16, false, u * 8);
					} else if (!c4.spl) {
						c4.spl = 1; addRipple(c4.tx, waterY); addRing(c4.tx, waterY - 4);
					}
				});
				return done && st.t2 > 3;
			} },
			/* Valentine's: two swans meet, necks forming a heart */
			swans: { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.t2 = 0; st.cxm = vw / 2; }
				st.t2 += dt;
				var u = clamp(st.t2 / 3, 0, 1);
				var gap = lerp(vw * 0.5, 21, easeIO(u));
				var y = waterY - 12 + sin(st.t2 * 2) * 1.5;
				if (st.t2 > 5.5) { gap = 21 + (st.t2 - 5.5) * 60; }
				dspr('swan', st.cxm - gap, y, 34, true);
				dspr('swan', st.cxm + gap, y, 34, false);
				if (u >= 1 && st.t2 < 5.5) {
					dtxt('♥', st.cxm, y - 26 + sin(st.t2 * 3) * 2, 12, '#FA5252', VA * clamp(st.t2 - 3, 0, 1));
					if (rand() < dt) { addRipple(st.cxm + rnd(-20, 20), waterY); }
				}
				return st.t2 > 7.5;
			} },
			/* Strawberry: a falling berry lands neatly in the basket */
			catch1: { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.t2 = 0; st.x = rnd(vw * 0.3, vw * 0.7); st.by = -20; st.sq = 1; }
				st.t2 += dt;
				var caught = st.by >= vh - 34;
				if (st.t2 > 1.2 && !caught) {
					st.by += 160 * dt;
					dspr('berry', st.x, st.by, 20, false, st.t2 * 3);
				}
				if (caught && !st.hit) { st.hit = st.t2; }
				if (st.hit) { st.sq = 1 + sin((st.t2 - st.hit) * 12) * 0.12 * MT.exp(-(st.t2 - st.hit) * 3); }
				dspr('basket', st.x, vh - 24, 30 * st.sq);
				return st.hit && st.t2 - st.hit > 2.5;
			} },
			/* Easter: the egg hunt */
			egghunt: { actors: 3, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.t2 = 0; st.gx = [vw * 0.3, vw * 0.5, vw * 0.7].map(function (v) { return v + rnd(-30, 30); }); st.p = 1; st.bx = -30; st.color = '#BFDBFE'; }
				st.t2 += dt;
				/* grass tufts grow */
				st.gx.forEach(function (gx3, i) {
					var gu = clamp((st.t2 - i * 0.3) / 0.8, 0, 1);
					cx.save(); cx.globalAlpha = VA; cx.strokeStyle = '#2F9E44'; cx.lineWidth = 2; cx.lineCap = 'round';
					for (var bl = -2; bl <= 2; bl++) {
						cx.beginPath();
						cx.moveTo(gx3 + bl * 4, vh - 4);
						cx.lineTo(gx3 + bl * 5, vh - 4 - gu * (14 - abs(bl) * 2));
						cx.stroke();
					}
					cx.restore();
				});
				var ex = st.gx[1] + 12;
				var hasEgg = st.p < 4;
				if (st.t2 > 1 && hasEgg) { /* the decorated egg sits behind a tuft */
					cx.save(); cx.globalAlpha = VA; cx.translate(ex, vh - 14);
					PRIMS.egg(cx, { size: 22, color: st.color, color2: '#E64980', deco: 1 }, 1);
					cx.restore();
				}
				if (st.t2 > 2.4 && st.p === 1) { st.p = 2; }
				if (st.p === 2) { /* bunny hops in */
					st.bx += 85 * dt;
					dspr('bunny', st.bx, vh - 18 - abs(sin(st.t2 * 7)) * 16, 26, true);
					if (st.bx >= ex - 22) { st.p = 3; st.sn = st.t2; }
				} else if (st.p === 3) { /* stop, sniff */
					dspr('bunny', st.bx, vh - 18 + sin((st.t2 - st.sn) * 10) * 1.5, 26, true);
					if (st.t2 - st.sn > 1.2) { st.p = 4; }
				} else if (st.p === 4) { /* carry pose, hop off */
					st.bx += 95 * dt;
					dspr('bunnycarry', st.bx, vh - 20 - abs(sin(st.t2 * 7)) * 14, 28, true);
					if (st.bx > vw + 40) { return true; }
				}
				return false;
			} },
			/* Easter: the hatch — wobble, crack ×3, chick pops out */
			hatch: { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.t2 = 0; st.x = rnd(vw * 0.35, vw * 0.65); st.p = 1; }
				st.t2 += dt;
				var y = vh - 20;
				if (st.p === 1) {
					var wob = sin(st.t2 * (4 + st.t2 * 3)) * 0.14 * mn(1, st.t2 / 2);
					cx.save(); cx.globalAlpha = VA; cx.translate(st.x, y); cx.rotate(wob);
					PRIMS.egg(cx, { size: 26, color: '#FDE68A', color2: '#7C3AED', deco: 0 }, 1);
					/* crack stages */
					var stg = mn(3, 1 + (st.t2 / 1.2) | 0);
					cx.strokeStyle = '#8A6D1A'; cx.lineWidth = 1.2;
					cx.beginPath();
					if (stg >= 1) { cx.moveTo(-4, -8); cx.lineTo(0, -3); }
					if (stg >= 2) { cx.lineTo(4, -7); cx.lineTo(7, -1); }
					if (stg >= 3) { cx.moveTo(0, -3); cx.lineTo(-2, 3); cx.lineTo(3, 6); }
					cx.stroke();
					cx.restore();
					if (st.t2 > 3.6) { st.p = 2; st.pop2 = st.t2; }
				} else {
					var pu = clamp((st.t2 - st.pop2) / 0.5, 0, 1);
					cx.save(); cx.globalAlpha = VA * (1 - pu * 0.6); cx.translate(st.x, y);
					PRIMS.egg(cx, { size: 26, color: '#FDE68A', color2: '#7C3AED', deco: 0 }, 1);
					cx.restore();
					var wx2 = st.x + (st.t2 - st.pop2) * 70;
					dspr('chick', wx2, y - 12 - sin(mn(1, pu) * MT.PI) * 24 + sin(st.t2 * 10) * 1.5, 18, true);
					if (wx2 > vw + 30) { return true; }
				}
				return false;
			} },
			/* April Fool's: the jester hits the banana peel */
			bananaslip: { actors: 2, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.t2 = 0; st.px = rnd(vw * 0.4, vw * 0.65); st.jx = -30; st.p = 1; st.ph = 0; }
				st.t2 += dt; st.ph += dt * 6;
				dspr('peel', st.px, vh - 10, 22);
				if (st.p === 1) {
					st.jx += 90 * dt;
					dspr('jester', st.jx, vh - 22 + sin(st.ph) * 2, 28, true, sin(st.ph) * 0.06);
					if (st.jx >= st.px - 8) { st.p = 2; st.slip = st.t2; }
				} else if (st.p === 2) { /* slip! circling stars */
					var su = clamp((st.t2 - st.slip) / 0.4, 0, 1);
					dspr('jester', st.px + su * 16, vh - 14, 28, true, su * -1.4);
					for (var s4 = 0; s4 < 3; s4++) {
						dtxt('★', st.px + 16 + cos(st.ph + s4 * 2.1) * 16, vh - 34 + sin(st.ph + s4 * 2.1) * 7, 10, '#F1C40F');
					}
					if (st.t2 - st.slip > 1.8) { st.p = 3; }
				} else { /* up and off */
					st.jx += 110 * dt;
					dspr('jester', st.jx, vh - 22, 28, true);
					if (st.jx > vw + 40) { return true; }
				}
				return false;
			} },
			/* Spring: mama duck parade on the water */
			duckparade: { actors: 3, run: function (st, dt) {
				if (!st.on) { st.on = 1; st.dir = sgn(); st.x = st.dir > 0 ? -140 : vw + 140; st.ph = 0; st.wk = 1; }
				st.ph += dt * 3;
				st.x += st.dir * 42 * dt;
				st.wk -= dt;
				if (st.wk <= 0) { addRipple(st.x - st.dir * 10, waterY + 2); st.wk = rnd(1.2, 2); }
				var duck = drawable('🦆') ? '🦆' : '🐤';
				var chick = drawable('🐥') ? '🐥' : '🐤';
				var flip = st.dir > 0;
				dtxt(duck, st.x, waterY - 8 + sin(st.ph) * 2, 28, null, VA, 0);
				for (var i4 = 1; i4 <= 4; i4++) {
					dtxt(chick, st.x - st.dir * (22 + i4 * 20), waterY - 5 + sin(st.ph + i4) * 2, 15, null, VA, 0);
				}
				if (flip) { /* facing handled by glyph choice being symmetric enough at this size */ }
				return (st.dir > 0 && st.x > vw + 160) || (st.dir < 0 && st.x < -160);
			} },
			/* Spring: dragonfly lands on a lotus */
			dragonlotus: { actors: 2, run: function (st, dt) {
				if (!st.tgt) { st.tgt = 'lilypad'; }
				return SCENES.dragonlands.run.call(this, st, dt);
			} }
		};
		var VIGS = {
			labor_day: ['flotilla'],
			patriot_day: ['flagfly'],
			mlk: ['doveflight'],
			fall_fishing: ['fullcast', 'dragonlands'],
			halloween: ['witchmoon'],
			christmas: ['giftdrop'],
			new_years: ['corkpop'],
			snowbird: ['arrival'],
			mardi_gras: ['stilts', 'doubloons'],
			valentines: ['swans'],
			strawberry: ['catch1'],
			easter: ['egghunt', 'hatch'],
			april_fools: ['bananaslip'],
			spring_canal: ['duckparade', 'kayaker', 'dragonlotus']
		};
		var vigList = (FX.vig && VIGS[themeKey]) ? VIGS[themeKey].slice() : [];
		if (FX.vig && themeKey === 'christmas' && evening) { vigList.push('sleighmoon'); }

		function startVig(name) {
			var sc = SCENES[name];
			if (!sc) { return; }
			var need = sc.actors || 3, freed = 0;
			for (var k = 0; k < parts.length && freed < need; k++) {
				if (!parts[k].dormant) { parts[k].dormant = true; freed++; }
			}
			vig = { name: name, st: { t: 0 }, sc: sc };
		}
		function endVig(t) {
			if (!vig) { return; }
			vig = null;
			for (var k = 0; k < parts.length; k++) {
				if (parts[k].dormant) { parts[k].dormant = false; seed(parts[k]); }
			}
			vigNext = (t || 0) + ((DEBUG && CFG.vigGap) || rnd(90, 150) * 1000);
		}
		function stepVig(dt, t) {
			/* THE showstopper: the real New Year's countdown, wall-clock. */
			if (themeKey === 'new_years' && FX.vig && !countdownDone) {
				var nw = localNow();
				if (nw.getMonth() === 11 && nw.getDate() === 31 && nw.getHours() === 23 && nw.getMinutes() === 59 && nw.getSeconds() >= 50) {
					if (!vig || vig.name !== 'countdown') {
						if (vig) { endVig(t); }
						vig = { name: 'countdown', st: {}, sc: null };
					}
				}
			}
			if (vig && vig.name === 'countdown') {
				var nw2 = localNow();
				var left = nw2.getMonth() === 11 && nw2.getDate() === 31 ? 60 - nw2.getSeconds() : 0;
				if (left > 0 && left <= 10) {
					cx.save();
					cx.font = 'bold 96px sans-serif';
					cx.textAlign = 'center';
					cx.lineWidth = 7;
					cx.strokeStyle = '#7A4E00';
					cx.strokeText(String(left), vw / 2, vh * 0.4);
					cx.fillStyle = '#FFD43B';
					cx.fillText(String(left), vw / 2, vh * 0.4);
					cx.restore();
				} else { /* midnight! triple mega-burst + the year in gold */
					vig.st.after = (vig.st.after || 0) + dt;
					if (!vig.st.boom) { vig.st.boom = 1; fire(t); fire(t); fire(t); nextBurst = t + 800; }
					dtxt(yearText, vw / 2, vh * 0.4, 84, '#FFD43B', mn(1, VA * 1.4) * clamp(3 - vig.st.after, 0, 1));
					if (vig.st.after > 3) { countdownDone = true; endVig(t); }
				}
				return;
			}
			if (vig) {
				if (vig.sc.run(vig.st, dt, t)) { endVig(t); }
				return;
			}
			if (!vigList.length || hero) { return; }
			if (!vigNext) { vigNext = t + ((DEBUG && CFG.vigFirst) || 20000 + rnd(0, 8000)); return; } /* let the page settle */
			if (t >= vigNext) { startVig(pick(vigList)); }
		}

		/* --- Boot + main loop with the degrade ladder. --- */
		applySize();
		/* Before the first field, not after: seeding without a map would put
		 * this field where 3.14.0 put it, and it would stay there until every
		 * one of its members had respawned. */
		buildOpenMap();
		for (var i = 0; i < maxParts && pool.length; i++) { parts.push(seed({}, true)); }

		var running = !D.hidden, last = 0, raf = 0;
		var frameAvg = 4, shed = 0;
		function degrade(cost, t) {
			frameAvg = frameAvg * 0.95 + cost * 0.05;
			if (frameAvg <= 8) { return; }
			if (shed === 0) { FX.reflect = false; shed = 1; frameAvg = 4; }
			else if (shed === 1) {
				FX.parallax = false; shed = 2; frameAvg = 4;
				for (var k = 0; k < parts.length; k++) { parts[k].far = false; }
			} else if (shed === 2) { FX.vig = false; vigList = []; if (vig) { endVig(t); } shed = 3; frameAvg = 4; }
		}
		/* A slider, an accordion, a theme script rewriting the host's
		 * innerHTML takes the canvas with it, and 3.11.0 only noticed if that
		 * happened before the settled pass — a one-shot check cannot cover a
		 * re-render at an arbitrary later time, which is the whole risk. The
		 * frame loop is already running, so liveness costs one tree walk a
		 * frame and there is no observer to disconnect or leak. Re-mounts are
		 * rate-limited and capped: if something is determined to remove the
		 * canvas, lose gracefully rather than fight it every frame. */
		var remounts = 0, remountNext = 0;
		function ensureMounted() {
			/* Its own clock, so every caller rate-limits on the same scale —
			 * passing in a frame timestamp from one caller and something else
			 * from another would let one of them disable the other. */
			var now = (W.performance && performance.now) ? performance.now() : +new Date();
			if (!CFG.layer || D.body.contains(cv) || remounts >= 20 || now < remountNext) { return; }
			remountNext = now + 1000;
			remounts++;
			/* The old margin correction belongs to the old layout; carrying it
			 * into the re-mount distorts the acceptance check. */
			stickyPad = 0;
			if (!host || !D.body.contains(host) || !mountIn(host, hostMode)) {
				/* The host went with it, or will not take the canvas back. */
				host = null;
				stickyWatch(null);
				mountOnBody(CFG.layer ? 5 : 99990);
			}
			if (hostMode === 'sticky' && host) { stickyFit(); stickyBalance(); }
			applySize(true); /* a re-mount IS a discontinuity */
			/* Whatever re-rendered the page may have changed what paints over
			 * the canvas, so re-run the corrective loop rather than assume the
			 * old decision still holds. Bounded, and at most once a second. */
			if (host) { fixCoverage(true); }
			buildOpenMap();
			if (remounts === 1 && W.console && W.console.info) {
				W.console.info('DCC Seasons: the ambient canvas was removed from the page (the host re-rendered its children) and has been re-mounted.');
			}
		}
		function frame(t) {
			raf = 0;
			if (!running) { return; }
			ensureMounted();
			var t0 = (W.performance && performance.now) ? performance.now() : 0;
			var dt = last ? mn((t - last) / 1000, 0.05) : 0.016;
			last = t;
			cx.clearRect(0, 0, vw, vh);
			var clipped = footMode && clipText();
			drawBgFills();
			drawSnow();
			if (burstMode) {
				if (!nextBurst) { nextBurst = t + 1500; }
				else if (t >= nextBurst) { fire(t); }
				stepBursts(dt);
				drawFlash(dt);
				if (yearFx) {
					yearFx.a -= dt * 0.42;
					yearFx.y -= dt * 12;
					if (yearFx.a <= 0) { yearFx = null; }
					else {
						cx.save();
						cx.globalAlpha = clamp(mn(1, alphaBase * 2.4) * clamp(yearFx.a, 0, 1), 0, 1);
						cx.font = 'bold 46px sans-serif';
						cx.lineWidth = 4;
						cx.strokeStyle = '#7A4E00';
						cx.strokeText(yearText, yearFx.x, yearFx.y);
						cx.fillStyle = sparkCl[0];
						cx.fillText(yearText, yearFx.x, yearFx.y);
						cx.restore();
					}
				}
			}
			var k, p;
			deClump(dt);
			for (k = 0; k < parts.length; k++) {
				p = parts[k];
				if (p.dormant) { continue; }
				repel(p, dt);
				step(p, dt, t);
			}
			/* FAR layer first, then water, then NEAR */
			for (k = 0; k < parts.length; k++) { p = parts[k]; if (!p.dormant && p.far) { drawP(p, t); } }
			stepRipples(dt);
			drawRipples();
			for (k = 0; k < parts.length; k++) {
				p = parts[k];
				if (p.dormant || p.far) { continue; }
				drawP(p, t);
			}
			stepVig(dt, t);
			stepHero(dt, t);
			drawHero(t);
			drawReflections(t);
			if (DEBUG && DBG && W.DCCSeasonsEngine._slow) {
				var until = performance.now() + W.DCCSeasonsEngine._slow;
				while (performance.now() < until) { /* synthetic load for tests */ }
			}
			if (clipped) { cx.restore(); }
			if (t0) { degrade(performance.now() - t0, t); }
			raf = W.requestAnimationFrame(frame);
		}
		function play() { if (!raf && running) { last = 0; raf = W.requestAnimationFrame(frame); } }
		D.addEventListener('visibilitychange', function () {
			running = !D.hidden && !reduced();
			if (running) { play(); }
		});
		if (mq && mq.addEventListener) {
			mq.addEventListener('change', function () {
				if (reduced()) {
					running = false;
					cv.style.display = 'none';
				} else {
					cv.style.display = '';
					running = !D.hidden;
					play();
				}
			});
		}
		if (DEBUG && DBG) {
			W.DCCSeasonsEngine._state = {
				get fx() { return FX; },
				get parts() { return parts; },
				get live() { var n = 0; for (var k = 0; k < parts.length; k++) { if (!parts[k].dormant) { n++; } } return n; },
				get ripples() { return ripples.length; },
				get cap() { return maxTotal; },
				get vig() { return vig && vig.name; },
				get hero() { return hero && hero.kind; },
				get evening() { return evening; },
				get snowMax() { var m = 0; if (snowCols) { for (var k = 0; k < snowCols.length; k++) { m = mx2(m, snowCols[k]); } } return m; },
				get frameAvg() { return frameAvg; },
				get shed() { return shed; },
				get vw() { return vw; },
				get vh() { return vh; },
				get waterY() { return waterY; },
				get sep() { return sepRun; },
				get share() { return viewShare(); },
				get placement() { return footMode ? 'footer' : 'content'; },
				get hostPath() { return host ? pathOf(host) : ''; },
				get textBoxes() { return textBoxes.slice(0); },
				get textMs() { return textMs; },
				get paintable() { return worth(host, 1); },
				get openMap() {
					return { n: omN, total: omTot, frac: omFrac, ms: omMs, builds: omBuilds,
						cell: MAP_CELL, usable: mapUsable(), measured: omMeas, openMeasured: omOpen,
						nine: omNine.slice(0), col: omCol.slice(0) };
				},
				get repel() { return { ms: repMs, frames: repN }; },
				buildMap: function () { buildOpenMap(); return omFrac; },
				/* Re-seeding the live array is exactly what a restart does. */
				reseed: function (anywhere) { for (var k = 0; k < parts.length; k++) { seed(parts[k], anywhere); } }
			};
		}
		play();
	}

	W.DCCSeasonsEngine = { start: start };
})();
