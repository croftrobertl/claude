/* DCC Seasons — deferred loader: picks the active theme from the visitor's
 * LOCAL date (cache-safe), binds the tap counter, and lazy-loads the two
 * engines — engine.js (every animated layer, after idle) and matrix.js (the
 * easter egg, only on the launching tap). Dependency-free. */
(function () {
	'use strict';
	var W = window, D = document, CFG = W.DCC_SEASONS;
	if (!CFG || !CFG.enabled) { return; }

	var mq = W.matchMedia ? W.matchMedia('(prefers-reduced-motion: reduce)') : null;
	function reduced() { return !!(mq && mq.matches); }

	/* The year-round base theme. Mirrors Schedule::BASE_THEME. */
	var BASE_THEME = 'florida_keys';

	function pad(n) { return (n < 10 ? '0' : '') + n; }
	function ymd(y, m, d) { return y + '-' + pad(m) + '-' + pad(d); }
	var now = new Date();
	var today = ymd(now.getFullYear(), now.getMonth() + 1, now.getDate());

	/* ---- Schedule rules → dates, resolved HERE from the visitor's local
	 * clock (cache-safe: the HTML never carries "today"). Mirrors
	 * class-schedule.php; the test suite cross-checks the two. ---- */
	var ANCH = CFG.anchors || {};
	function easter(y) { /* Gregorian computus */
		var a = y % 19, b = (y / 100) | 0, c = y % 100, d = (b / 4) | 0, e = b % 4;
		var f = ((b + 8) / 25) | 0, g = ((b - f + 1) / 3) | 0, h = (19 * a + b - d - g + 15) % 30;
		var i2 = (c / 4) | 0, k = c % 4, l = (32 + 2 * e + 2 * i2 - h - k) % 7;
		var m = ((a + 11 * h + 22 * l) / 451) | 0, mo = ((h + l - 7 * m + 114) / 31) | 0;
		return [mo, ((h + l - 7 * m + 114) % 31) + 1];
	}
	function nthWeekday(y, m, wd, n) {
		if (n > 0) { return 1 + ((wd - new Date(y, m - 1, 1).getDay() + 7) % 7) + (n - 1) * 7; }
		var days = new Date(y, m, 0).getDate();
		return days - ((new Date(y, m - 1, days).getDay() - wd + 7) % 7);
	}
	/* One rule for one year → 'YYYY-MM-DD', or null for a rule this build
	 * doesn't understand (a stale row must never throw on the front end). */
	function resolve(rule, y) {
		if (!rule) { return null; }
		var on = rule.on || 'fixed', off = rule.off | 0, m, d, a;
		if (on === 'fixed') {
			m = rule.m | 0; d = rule.d | 0;
			if (m < 1 || m > 12 || d < 1 || d > 31) { return null; }
			d = Math.min(d, new Date(y, m, 0).getDate());
		} else {
			a = ANCH[on];
			if (!a) { return null; }
			if (a.type === 'fixed') { m = a.m; d = a.d; }
			else if (a.type === 'nth') { m = a.m; d = nthWeekday(y, m, a.wd, a.n); }
			else { var ed = easter(y); m = ed[0]; d = ed[1]; off += a.off | 0; }
		}
		var dt = new Date(y, m - 1, d + off);
		return ymd(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
	}
	/* The instance of a row that begins in year y → [start, end]; an end
	 * before its start belongs to the following year. */
	function resolveRow(r, y) {
		if (r.year && r.year !== y) { return null; }
		var s = resolve(r.start, y), e = resolve(r.end, y);
		if (!s || !e) { return null; }
		if (e < s) { e = resolve(r.end, y + 1); }
		return [s, e];
	}
	function days(s, e) { return Math.round((new Date(e) - new Date(s)) / 864e5); }
	/* ---- Which row wins a day: the four rules of Schedule::active(),
	 * identically (tools/test-schedule.js walks 2027-2036 through both).
	 * The holiday and clash tables come from PHP in the config. ---- */
	var HOL = CFG.holidays || {}, CLASH = CFG.clashWins || [];
	function addDays(date, n) {
		var p = date.split('-'), dt = new Date(+p[0], +p[1] - 1, +p[2] + n);
		return ymd(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
	}
	function ownDay(theme, y) { return HOL[theme] ? resolve({ on: HOL[theme], off: 0 }, y) : null; }
	/* Every row instance containing date, in row order. Legacy rows
	 * (pre-3.7.0 Y-m-d strings) still match, for a cached old config. */
	function hits(rows, date) {
		var y = +date.slice(0, 4), out = [], i, yy, r, rr;
		for (i = 0; i < rows.length; i++) {
			r = rows[i];
			if (typeof r.start === 'string') {
				if (r.start <= date && date <= r.end) { out.push({ row: r, span: days(r.start, r.end) }); }
				continue;
			}
			for (yy = y - 1; yy <= y; yy++) {
				rr = resolveRow(r, yy);
				if (rr && rr[0] <= date && date <= rr[1]) { out.push({ row: r, span: days(rr[0], rr[1]) }); }
			}
		}
		return out;
	}
	function narrowest(h) {
		var best = null;
		for (var i = 0; i < h.length; i++) { if (!best || h[i].span < best.span) { best = h[i]; } }
		return best;
	}
	function nearest(theme, date) {
		var y = +date.slice(0, 4), best = [1e9, false], yy, o, d;
		for (yy = y - 1; yy <= y + 1; yy++) {
			o = ownDay(theme, yy);
			if (!o) { continue; }
			d = days(date, o);
			if (Math.abs(d) < best[0]) { best = [Math.abs(d), d > 0]; }
		}
		return best;
	}
	function claim(rows, date) {
		var h = hits(rows, date), y = +date.slice(0, 4), own = [], th = {}, i, j, x;
		for (i = 0; i < h.length; i++) {
			if (ownDay(h[i].row.theme, y) === date) { own.push(h[i]); th[h[i].row.theme] = true; }
		}
		if (own.length) {
			for (j = 0; j < CLASH.length; j++) {
				if (th[CLASH[j][0]] && th[CLASH[j][1]]) {
					own = own.filter(function (o) { return o.row.theme !== CLASH[j][1]; });
				}
			}
			return narrowest(own);
		}
		var hol = [], ht = {}, nt = 0;
		for (i = 0; i < h.length; i++) {
			if (HOL[h[i].row.theme]) {
				hol.push(h[i]);
				if (!ht[h[i].row.theme]) { ht[h[i].row.theme] = true; nt++; }
			}
		}
		if (nt > 1) {
			var best = null, bd = 1e9, bup = false, n2;
			for (i = 0; i < hol.length; i++) {
				x = hol[i];
				n2 = nearest(x.row.theme, date);
				if (n2[0] < bd || (n2[0] === bd && n2[1] && !bup)) { best = x; bd = n2[0]; bup = n2[1]; }
			}
			return best;
		}
		return narrowest(h);
	}
	function activeRow(rows, date) {
		var w = claim(rows, date);
		if (!w) { return null; }
		var t = w.row.theme;
		if (w.span > 0 && ownDay(t, +date.slice(0, 4)) !== date) {
			var p = claim(rows, addDays(date, -1)), n = claim(rows, addDays(date, 1));
			/* A lone day of a long theme goes to the theme that starts next,
			 * never onto a one-day holiday. */
			if ((!p || p.row.theme !== t) && (!n || n.row.theme !== t) && n && n.span > 0) { return n.row; }
		}
		return w.row;
	}
	var row = activeRow(CFG.schedule || [], today);
	var themeKey = row ? row.theme : null;
	var theme = themeKey && CFG.themes && CFG.themes[themeKey] ? CFG.themes[themeKey] : null;
	/* Nothing claims today: the year-round base theme is the baseline face
	 * of the site. The default schedule has a full-year row so this is only
	 * reached on a schedule the owner has cut a hole in. */
	if (!theme && CFG.themes && CFG.themes[BASE_THEME]) {
		themeKey = BASE_THEME;
		theme = CFG.themes[BASE_THEME];
	}

	/* Admin-only preview (?dcc_season=<key>|off). The flag is only present
	 * in the config when PHP verified manage_options server-side. */
	if (CFG.preview) {
		if (CFG.preview === 'off') {
			row = null; theme = null; themeKey = null;
		} else if (CFG.themes && CFG.themes[CFG.preview]) {
			themeKey = CFG.preview;
			theme = CFG.themes[themeKey];
			row = { theme: themeKey, label: CFG.previewLabel || themeKey };
		}
	}

	function loadScript(src, cb, fail) {
		var sc = D.createElement('script');
		sc.src = src;
		sc.async = true;
		sc.onload = cb;
		/* A failed fetch (a flaky phone connection) must not leave the
		 * caller waiting for good: remove the dead tag and let it retry. */
		sc.onerror = function () {
			if (sc.parentNode) { sc.parentNode.removeChild(sc); }
			if (fail) { fail(); }
		};
		(D.head || D.documentElement).appendChild(sc);
	}

	/* ---- Ambient engine (lazy, after idle — never in the critical path).
	 * Loads on themed days AND theme-less days: the heron hero is the
	 * plugin's year-round signature. Not loaded under reduced motion. */
	function ambient() {
		/* The engine draws every animated layer — falling sprites, the
		 * background layer, corner accents, scenes, heroes — and since 4.5.0
		 * each has its own switch (Rob: "Ambient" = falling sprites only).
		 * So it loads whenever ANY of them is on: CFG.engine, computed by
		 * Settings::engine_needed(). A config cached before 4.5.0 has no
		 * CFG.engine and keeps the old meaning. */
		var wantEngine = CFG.engine !== undefined ? !!CFG.engine : !!CFG.ambient;
		if (!wantEngine || reduced() || !CFG.engineSrc) { return; }
		/* Footer placement with no footer renders nothing, so fetching the
		 * engine to discover that costs ~221KB (77KB over the wire, 4.14.0) for no
		 * effect. Measured: on a
		 * page with no footer the engine was fetched in full and produced
		 * zero canvases. The selector is the config's, the same one the
		 * engine mounts by, so the two cannot disagree. */
		/* ...but NOT when an administrator has asked for the diagnostics
		 * panel: that panel is drawn by the engine, and skipping the fetch
		 * would leave ?dcc_debug=1 silent in precisely the state it exists to
		 * explain. The saving is for visitors; the explanation is for whoever
		 * is debugging. */
		if (!CFG.diag && (CFG.placement || 'footer') === 'footer') {
			var sel = CFG.footerSel || CFG.footerHost ||
				'footer#colophon, #colophon, footer.site-footer, .site-footer, footer[role="contentinfo"], #footer, footer';
			var found;
			try { found = D.querySelector(sel); } catch (e) { found = null; }
			if (!found) {
				if (W.console && W.console.warn) {
					W.console.warn('DCC Seasons: placement is "Site footer only" but this page has no footer element, so the ambient engine was not loaded. Name one with the dcc_seasons_footer_host filter, or switch Placement to "Across the page content".');
				}
				return;
			}
		}
		var loading = false;
		function go() {
			if (loading) { return; }
			loading = true;
			loadScript(CFG.engineSrc, function () {
				if (W.DCCSeasonsEngine) {
					W.DCCSeasonsEngine.start({
						cfg: CFG,
						theme: theme,
						themeKey: themeKey,
						row: row,
						mq: mq
					});
				}
			});
		}
		/* WHEN the engine is fetched (4.12.1). It used to be
		 * requestIdleCallback(timeout 3000), with setTimeout(go, 1500) where
		 * that does not exist — and on a phone the 1.5 s timer fired while the
		 * hero photograph and the booking widget were still loading, so the
		 * engine's bytes competed with them. Now NOTHING starts before the
		 * window load event: after it, whichever comes first of a short breath
		 * (START_DELAY, then idle time if the browser offers it) and the
		 * visitor's first scroll or tap. Once running, every effect is
		 * identical — this changes only the moment the fetch begins. */
		var START_DELAY = 400;    /* ms after load before the fetch */
		var LOAD_NET = 10000;     /* …and a net, in case 'load' never fires */
		var EV = ['scroll', 'pointerdown', 'touchstart', 'keydown'];
		var evOpt = { passive: true, capture: true };
		var armed = false, tid = 0;
		function fire() {
			for (var i = 0; i < EV.length; i++) { W.removeEventListener(EV[i], fire, evOpt); }
			if (tid) { clearTimeout(tid); tid = 0; }
			if (W.requestIdleCallback) { W.requestIdleCallback(go, { timeout: 1000 }); }
			else { go(); }
		}
		function arm() {
			if (armed) { return; }
			armed = true;
			for (var i = 0; i < EV.length; i++) { W.addEventListener(EV[i], fire, evOpt); }
			tid = setTimeout(fire, START_DELAY);
		}
		if (D.readyState === 'complete') { arm(); }
		else {
			W.addEventListener('load', arm);
			/* A page whose last image never resolves never fires 'load'. The
			 * net is deliberately long: it is a failure mode, not a path. */
			setTimeout(arm, LOAD_NET);
		}
	}

	/* ---- Tap targets. The selector is a comma-separated list. Taps are
	 * counted by DELEGATION — one pair of listeners on the document that
	 * asks "did this tap land inside a target?" — rather than by binding
	 * each matching element. Two reasons, both bugs in the old approach:
	 *
	 *  1. Nested targets double-counted. The #masthead fallback was bound
	 *     unconditionally and it CONTAINS #site-title, so one physical tap
	 *     bubbled through both listeners and counted twice: with tap_count
	 *     4 the egg opened on the second tap (measured).
	 *  2. Targets were bound once at load. A theme that re-renders its
	 *     header (a sticky bar built on scroll, say) left the new element
	 *     unbound, so taps stopped counting after a scroll.
	 *
	 * Delegation counts each event exactly once and matches whatever is in
	 * the DOM at tap time. Only VISIBLE matches count (Bravada renders
	 * #branding and #site-title at 0px on this site).
	 *
	 * There is NO fallback (4.7.1, Rob: the egg is homepage only). Until
	 * 4.7.1 a page with no visible configured target bound #masthead
	 * instead, so with the default ".home #header-page-title .entry-title"
	 * four taps on any other page's header opened the egg — measured on
	 * live /contact/. A page without the configured target has no egg. */
	function validSelectors(list) {
		var out = [];
		for (var k = 0; k < list.length; k++) {
			var sel = String(list[k]).replace(/^\s+|\s+$/g, '');
			if (!sel) { continue; }
			try { D.querySelectorAll(sel); out.push(sel); } catch (e) {}
		}
		return out;
	}
	function visible(el) {
		var r = el.getBoundingClientRect();
		return r.width >= 10 && r.height >= 10;
	}
	/* The configured selectors only; any that do not parse are dropped.
	 * A cached pre-4.7.1 config's tapFallback is ignored on purpose. */
	function tapSelector() {
		return validSelectors(String(CFG.tapSelector || '').split(',')).join(',');
	}

	/* ---- Easter egg: N taps (one shared counter, one count per tap). */
	function egg() {
		if (!CFG.egg) { return; }
		if (theme && theme.egg === false) { return; } /* Patriot Day / MLK Day */
		var eggCfg = (theme && theme.egg) || (CFG.themes && CFG.themes.classic && CFG.themes.classic.egg);
		if (!eggCfg) { return; }

		var sel = tapSelector();
		if (!sel) { return; }

		var taps = [], lastTouch = 0, loading = false;
		var need = Math.max(2, CFG.tapCount || 5), win = CFG.tapWindow || 3000;

		function samePage(a) {
			return a && a.href && a.host === W.location.host &&
				a.pathname.replace(/\/$/, '') === W.location.pathname.replace(/\/$/, '');
		}
		function hit(e) {
			var t = e.target;
			if (!t || !t.closest) { return null; }
			var el = t.closest(sel);
			return el && visible(el) ? el : null;
		}
		function onTap(e) {
			if (!hit(e)) { return; }
			var t = Date.now();
			if (e.type === 'click') {
				/* Cancel the pointless self-reload when the tapped link
				 * points at the page we're on, so tap counting survives;
				 * links to OTHER pages still navigate normally. */
				var a = e.target && e.target.closest ? e.target.closest('a') : null;
				if (a && samePage(a)) { e.preventDefault(); }
				if (t - lastTouch < 700) { return; } /* ghost click after touch */
			} else {
				lastTouch = t;
			}
			taps.push(t);
			while (taps.length && t - taps[0] > win) { taps.shift(); }
			if (taps.length >= need) {
				taps = [];
				launch();
			}
		}
		D.addEventListener('touchstart', onTap, { passive: true });
		D.addEventListener('click', onTap, false);

		function open() {
			W.DCCSeasonsMatrix.launch({
				egg: eggCfg,
				label: (row && row.label) || '',
				reduced: reduced(),
				i18n: CFG.i18n || {}
			});
		}
		function launch() {
			if (W.DCCSeasonsMatrix) { open(); return; }
			if (loading || !CFG.matrixSrc) { return; }
			loading = true;
			loadScript(CFG.matrixSrc, function () {
				loading = false;
				if (W.DCCSeasonsMatrix) { open(); }
			}, function () { loading = false; }); /* the next 5 taps try again */
		}
	}

	W.DCCSeasonsSchedule = { resolve: resolve, resolveRow: resolveRow, activeRow: activeRow, easter: easter, nthWeekday: nthWeekday };

	function init() { ambient(); egg(); }
	if (D.readyState === 'loading') {
		D.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
