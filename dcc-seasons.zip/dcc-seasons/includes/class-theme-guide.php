<?php
/**
 * The Theme guide tab on the Seasons settings page (4.4.0).
 *
 * One card per theme, catalogue style, generated at RUNTIME from the same
 * theme config the front end receives (Themes::themes()), the saved
 * settings and the engine itself: the admin page loads engine.js and reads
 * DCCSeasonsEngine.guide — its sprites, accents, scene lists, timing and
 * phone-scaling rules — so the guide cannot drift from what plays. Nothing
 * here lists themes or effects by hand; the only hand-written table is
 * names(), the plain-English (translatable) name of each drawing, and
 * tools/test-guide.js fails if anything shown lacks one.
 *
 * Assets load only on this tab (Settings::assets()), never on the front end.
 *
 * @package DCC_Seasons
 */

namespace DCC_Seasons;

defined('ABSPATH') || exit;

final class Theme_Guide {

    public const TAB = 'guide';
    /** The Preview tab (4.14.3): one whole theme on the real home page. */
    public const TAB_PREVIEW = 'preview';

    private static function tab(): string {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        return isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : '';
    }

    /** Is the Theme guide (or the Preview, which is built on it) being viewed? */
    public static function is_tab(): bool {
        return in_array(self::tab(), [self::TAB, self::TAB_PREVIEW], true);
    }

    public static function is_preview(): bool {
        return self::tab() === self::TAB_PREVIEW;
    }

    /** The theme the Preview tab shows: the one asked for, else today's. */
    public static function preview_key(): string {
        $themes = Themes::themes();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $k = isset($_GET['theme']) ? sanitize_key(wp_unslash($_GET['theme'])) : '';
        if ($k !== '' && isset($themes[$k])) {
            return $k;
        }
        $row = Schedule::active(Themes::schedule((array) Settings::options()['schedule']), current_time('Y-m-d'));
        return $row && isset($themes[$row['theme']]) ? (string) $row['theme'] : (string) array_key_first($themes);
    }

    /** Settings | Theme guide tabs. */
    public static function tabs(): void {
        $base = admin_url('admin.php?page=' . Settings::SLUG);
        $cur  = self::is_tab() ? self::tab() : '';
        echo '<nav class="nav-tab-wrapper dcc-seasons-tabs" aria-label="' . esc_attr__('Seasons sections', 'dcc-seasons') . '">';
        foreach (['' => __('Settings', 'dcc-seasons'), self::TAB => __('Theme guide', 'dcc-seasons'), self::TAB_PREVIEW => __('Preview', 'dcc-seasons')] as $t => $label) {
            $on = $cur === $t;
            echo '<a href="' . esc_url($t === '' ? $base : add_query_arg('tab', $t, $base)) . '" class="nav-tab' . ($on ? ' nav-tab-active' : '') . '"' . ($on ? ' aria-current="page"' : '') . '>' . esc_html($label) . '</a>';
        }
        echo '</nav>';
    }

    /** The guide's scripts and styles; called by Settings::assets() on this tab only. */
    public static function enqueue(): void {
        wp_enqueue_style('dcc-seasons-guide', DCC_SEASONS_URL . 'assets/css/theme-guide.css', [], DCC_SEASONS_VERSION);
        /* 4.13.4: every art file (each pack once), before the engine reads them */
        $art = [];
        foreach (Plugin::art_files() as $p) {
            wp_enqueue_script('dcc-seasons-art-' . $p, DCC_SEASONS_URL . 'assets/js/art-' . $p . Plugin::suffix() . '.js', [], DCC_SEASONS_VERSION, true);
            $art[] = 'dcc-seasons-art-' . $p;
        }
        wp_enqueue_script('dcc-seasons-engine', DCC_SEASONS_URL . 'assets/js/engine' . Plugin::suffix() . '.js', $art, DCC_SEASONS_VERSION, true);
        wp_enqueue_script('dcc-seasons-guide', DCC_SEASONS_URL . 'assets/js/theme-guide.js', ['dcc-seasons-engine'], DCC_SEASONS_VERSION, true);
        wp_add_inline_script('dcc-seasons-guide', 'window.DCCSeasonsGuideData = ' . wp_json_encode(self::payload()) . ';', 'before');
        if (self::is_preview()) {
            wp_enqueue_style('dcc-seasons-preview', DCC_SEASONS_URL . 'assets/css/preview.css', [], DCC_SEASONS_VERSION);
            wp_enqueue_script('dcc-seasons-preview', DCC_SEASONS_URL . 'assets/js/preview.js', ['dcc-seasons-guide'], DCC_SEASONS_VERSION, true);
        }
    }

    /** The tab's markup: a container the script fills. */
    public static function render(): void {
        if (self::is_preview()) {
            self::render_preview();
            return;
        }
        echo '<div id="dcc-seasons-guide" class="dcc-guide" aria-live="polite"><p class="description">' .
            esc_html__('Loading the theme guide…', 'dcc-seasons') . '</p></div>';
        echo '<noscript><p>' . esc_html__('The theme guide draws each theme with the effects engine, which needs JavaScript.', 'dcc-seasons') . '</p></noscript>';
    }

    /** A theme's preview URL (works for logged-in administrators only). */
    public static function preview_url(string $key): string {
        return home_url('/?dcc_season=' . rawurlencode($key));
    }

    /**
     * The Preview tab (4.14.3, Rob's Step 0): pick a theme and see all of it
     * on the real home page — its falling pieces with every variant in turn,
     * its background layer and corner accent, each scene and each flyer on a
     * play button, and the easter egg — at 390, 768 or 1440, with the
     * theme's own guide card below. The frame is the site's own front page
     * with the administrator's ?dcc_season= preview; dcc_play and
     * dcc_variants are honored for an administrator (or the check key) only.
     */
    private static function render_preview(): void {
        $key    = self::preview_key();
        $labels = Themes::labels();
        $opt    = Settings::options();
        $base   = admin_url('admin.php');
        echo '<div id="dcc-seasons-preview" class="dcc-pv" data-theme="' . esc_attr($key) . '" data-home="' . esc_url(add_query_arg(['dcc_season' => $key, 'dcc_variants' => 1], home_url('/'))) . '"'
            . ' data-taps="' . esc_attr((string) max(2, (int) ($opt['tap_count'] ?? 4))) . '" data-tapsel="' . esc_attr((string) ($opt['tap_selector'] ?? '')) . '">';
        echo '<h2 class="dcc-pv-title">' . esc_html__('Preview a Whole Theme', 'dcc-seasons') . '</h2>';
        echo '<form class="dcc-pv-pick" method="get" action="' . esc_url($base) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(Settings::SLUG) . '"><input type="hidden" name="tab" value="' . esc_attr(self::TAB_PREVIEW) . '">';
        echo '<label for="dcc-pv-theme">' . esc_html__('Theme', 'dcc-seasons') . '</label> <select id="dcc-pv-theme" name="theme" onchange="this.form.submit()">';
        foreach ($labels as $k => $label) {
            echo '<option value="' . esc_attr((string) $k) . '"' . selected($key, (string) $k, false) . '>' . esc_html((string) $label) . '</option>';
        }
        echo '</select> <noscript><button class="button">' . esc_html__('Show', 'dcc-seasons') . '</button></noscript></form>';
        echo '<div class="dcc-pv-stage"><p class="description">' . esc_html__('Loading the preview…', 'dcc-seasons') . '</p></div>';
        echo '</div>';
        echo '<div id="dcc-seasons-guide" class="dcc-guide" data-only="' . esc_attr($key) . '" aria-live="polite"></div>';
    }

    /**
     * Everything the cards are built from, read at request time.
     */
    public static function payload(): array {
        $opt    = Settings::options();
        $labels = Themes::labels();
        $year   = (int) current_time('Y');
        $rows   = Themes::schedule((array) $opt['schedule']);

        /* Walk the year through the REAL resolver (Rob's four calendar
         * rules), so each card's dates are the days that theme actually
         * plays — not its row's raw range. */
        $runs = [];
        $prev = null;
        for ($ts = gmmktime(12, 0, 0, 1, 1, $year); (int) gmdate('Y', $ts) === $year; $ts += 86400) {
            $d   = gmdate('Y-m-d', $ts);
            $row = Schedule::active($rows, $d);
            $t   = $row ? (string) $row['theme'] : '';
            if ($t !== '' && $t === $prev) {
                $runs[$t][count($runs[$t]) - 1][1] = $d;
            } elseif ($t !== '') {
                $runs[$t][] = [$d, $d];
            }
            $prev = $t;
        }

        $map     = array_merge(Themes::subtle_defaults(), Settings::subtle_map($opt));
        $effects = Settings::subtle_effects();

        return [
            'year'     => $year,
            'themes'   => Themes::themes(),
            'labels'   => $labels,
            'runs'     => $runs,
            'preview'  => array_combine(array_keys($labels), array_map([self::class, 'preview_url'], array_keys($labels))),
            'subtle'   => array_map(static function ($k) use ($effects) {
                return ['key' => (string) $k, 'name' => ($k !== '' && isset($effects[$k])) ? (string) $effects[$k] : ''];
            }, $map),
            'every'     => Plugin::EVERY,
            'settings' => [
                'enabled'   => !empty($opt['enabled']),
                'ambient'   => !empty($opt['ambient']),
                'egg'       => !empty($opt['egg']),
                'subtle'    => !empty($opt['subtle']),
                'subtleIntensity' => (float) ($opt['subtle_intensity'] ?? 0.6),
                'richness'  => (string) $opt['richness'],
                'vignettes' => !empty($opt['fx_vignettes']),
                'evening'   => !empty($opt['fx_evening']),
                'density'   => (int) $opt['density'],
            ],
            'names'    => self::names(),
            'i18n'     => self::strings($opt),
        ];
    }

    /** UI strings the script needs, translatable. */
    private static function strings(array $opt): array {
        return [
            'notScheduled' => __('Not scheduled', 'dcc-seasons'),
            /* the Preview tab (4.14.3) */
            'pvWidth'      => __('Screen width', 'dcc-seasons'),
            'pvPlay'       => __('Play', 'dcc-seasons'),
            'pvPieces'     => __('Falling Pieces and Background', 'dcc-seasons'),
            'pvScene'      => __('Scene', 'dcc-seasons'),
            'pvHero'       => __('Flyer', 'dcc-seasons'),
            'pvEgg'        => __('Easter Egg', 'dcc-seasons'),
            'pvEggNone'    => __('The easter egg opens from the home page title, so it plays only in the home page frame.', 'dcc-seasons'),
            'pvNote'       => __('The real home page, as a guest sees it on this theme\'s days. Every variant of a piece takes its turn, so all of them show. A scene or a flyer plays about a second after you press it, then again a few seconds after it leaves.', 'dcc-seasons'),
            'pvOpen'       => __('Open in a new tab', 'dcc-seasons'),
            'preview'      => __('Preview this theme', 'dcc-seasons'),
            'newTab'       => __('(opens in a new tab)', 'dcc-seasons'),
            'off'          => __('Switched off in Settings', 'dcc-seasons'),
            'sprites'      => __('Falling and drifting', 'dcc-seasons'),
            'boatsBirds'   => __('Boats and birds', 'dcc-seasons'),
            'desktop'      => __('desktop', 'dcc-seasons'),
            'phone'        => __('phone', 'dcc-seasons'),
            /* translators: 1: number on a 1280px screen, 2: number on a 390px phone */
            'onScreen'     => __('%1$s on screen at 1280px · %2$s on a 390px phone', 'dcc-seasons'),
            'lessThanOne'  => __('under 1', 'dcc-seasons'),
            'subtle'       => __('Background layer', 'dcc-seasons'),
            'accent'       => __('Corner accent', 'dcc-seasons'),
            'accentNote'   => __('Fixed in a corner of the screen.', 'dcc-seasons'),
            'accentPicNote' => __('In the header picture: centered under the tagline on the home page, under the page title on every other page.', 'dcc-seasons'),
            'scenes'       => __('Scenes', 'dcc-seasons'),
            /* translators: 1: first delay range in seconds, 2: repeat range in seconds */
            'sceneTiming'  => __('First scene %1$s s after the page opens. After that, scene and hero take turns: one every %2$s s, never two at once.', 'dcc-seasons'),
            'oneOf'        => __('One of these plays each time, picked at random.', 'dcc-seasons'),
            'evenings'     => __('Evenings only', 'dcc-seasons'),
            'hero'         => __('Hero', 'dcc-seasons'),
            /* translators: 1: seconds after the first scene ends, 2: repeat range in seconds */
            'heroTiming'   => __('On the first page of a visit it crosses about %1$s s after the first scene ends. After that it takes turns with the scenes: one appearance every %2$s s, never two at once. Each crossing picks one of these at random.', 'dcc-seasons'),
            /* translators: 1: first delay range in seconds, 2: repeat range in seconds */
            'heroTimingOnly' => __('Crosses the screen %1$s s after the page opens, then again every %2$s s. Each crossing picks one of these at random.', 'dcc-seasons'),
            'egg'          => __('Matrix egg', 'dcc-seasons'),
            /* From the SETTINGS (Settings::egg_howto), never hard-coded: the
             * target and the count are Rob's and can change. */
            /* translators: %s: how to open the egg, e.g. "Tap the title in the homepage banner 4 times" */
            'eggNote'      => sprintf(__('%s: the Matrix rain falls in these colours and characters, then this finale. Pages without that target have no egg.', 'dcc-seasons'), Settings::egg_howto($opt)),
            'special'      => __('Special', 'dcc-seasons'),
            /* translators: 1: sprite name, 2: accent name, 3: seconds */
            'turns'        => __('%1$s and the %2$s take turns: %3$s s each, the accent first, cross-fading. Never both on screen.', 'dcc-seasons'),
            /* translators: %d: minimum number of sprites */
            'phoneMin'     => __('On a phone it never shows fewer than %d sprites.', 'dcc-seasons'),
            'countdown'    => __('At 11:59:50 pm on 31 December, a 10-second countdown to midnight takes over the screen.', 'dcc-seasons'),
            'spritesOff'   => __('“Falling and drifting sprites” is off in Settings, so those lines (and the boats and birds, and anything that needs a sprite) are tagged below. The background layer, corner accents, scenes, heroes and the Matrix egg still play.', 'dcc-seasons'),
            'masterOff'    => __('DCC Seasons is switched off in Settings (Master enable), so guests see none of this.', 'dcc-seasons'),
            /* translators: %d: year */
            'datesIn'      => __('Dates in %d', 'dcc-seasons'),
            'intro'        => __('Every theme, in the order the year plays them, with everything a guest can see in it. Built from the plugin itself each time this page loads, so it always matches what plays.', 'dcc-seasons'),
            'loadError'    => __('The effects engine did not load, so the guide cannot be drawn. Reload the page; if it persists, check that engine.min.js is present in the plugin folder.', 'dcc-seasons'),
        ];
    }

    /**
     * Plain-English names for every drawing the guide shows, keyed the way
     * the engine keys them: sprites by SVGS key, heroes by kind, scenes by
     * scene name. Translatable. tools/test-guide.js fails on a missing one.
     */
    public static function names(): array {
        return [
            'sprites' => [
                'acorn' => __('Acorn', 'dcc-seasons'), 'balloon' => __('Balloon', 'dcc-seasons'),
                /* 4.13.0 — Thanksgiving's leaves and harvest pieces. The four
                 * leaves are named for their species, because that is the
                 * point of them: they are the trees that actually grow on
                 * the canal, not generic fall leaves. */
                'leafo' => __('Live oak leaf', 'dcc-seasons'),
                'leafc' => __('Bald cypress leaf', 'dcc-seasons'),
                'leafm' => __('Red maple leaf', 'dcc-seasons'),
                'leafm2' => __('Red maple leaf, turning', 'dcc-seasons'),
                'leafs' => __('Sweetgum leaf', 'dcc-seasons'),
                'gourd1' => __('Ribbed gourd', 'dcc-seasons'),
                'gourd2' => __('Crookneck gourd', 'dcc-seasons'),
                'gourd3' => __('Green Gourd', 'dcc-seasons'),
                'corn' => __('Indian corn', 'dcc-seasons'),
                'cranberry' => __('Cranberry sprig', 'dcc-seasons'),
                'banana' => __('Banana', 'dcc-seasons'), 'bass' => __('Largemouth bass', 'dcc-seasons'),
                'bat' => __('Bat', 'dcc-seasons'), 'beads' => __('Mardi Gras beads', 'dcc-seasons'),
                'berry' => __('Strawberry', 'dcc-seasons'), 'blossom' => __('Strawberry blossom', 'dcc-seasons'),
                'bobber' => __('Fishing bobber', 'dcc-seasons'), 'bunny' => __('Bunny', 'dcc-seasons'),
                'burger' => __('Burger', 'dcc-seasons'), 'candycorn' => __('Candy corn', 'dcc-seasons'),
                'cannabis' => __('Cannabis leaf', 'dcc-seasons'), 'cherry' => __('Cherry blossom', 'dcc-seasons'),
                'chick' => __('Chick', 'dcc-seasons'), 'clover' => __('Four-leaf clover', 'dcc-seasons'),
                'cooler' => __('Cooler', 'dcc-seasons'), 'disguise' => __('Groucho glasses', 'dcc-seasons'),
                'doubloon' => __('Doubloon', 'dcc-seasons'), 'dove' => __('Dove', 'dcc-seasons'),
                'dragonfly' => __('Dragonfly', 'dcc-seasons'), 'flagcloth' => __('American flag', 'dcc-seasons'),
                'flamingo' => __('Flamingo', 'dcc-seasons'), 'fleur' => __('Fleur-de-lis', 'dcc-seasons'),
                'flipflop' => __('Flip-flop', 'dcc-seasons'), 'flutes' => __('Champagne flutes', 'dcc-seasons'),
                'ghost' => __('Ghost', 'dcc-seasons'), 'gift' => __('Gift', 'dcc-seasons'),
                'globe' => __('Globe', 'dcc-seasons'), 'grill' => __('Grill', 'dcc-seasons'),
                'hibiscus' => __('Hibiscus', 'dcc-seasons'), 'holly' => __('Holly', 'dcc-seasons'),
                'hook' => __('Fish hook', 'dcc-seasons'), 'horseshoe' => __('Horseshoe', 'dcc-seasons'),
                'ibis' => __('White ibis', 'dcc-seasons'), 'icecream' => __('Ice cream cone', 'dcc-seasons'),
                'jack1' => __('Jack-o’-lantern', 'dcc-seasons'), 'jack2' => __('Jack-o’-lantern', 'dcc-seasons'),
                'jack3' => __('Jack-o’-lantern', 'dcc-seasons'), 'jester' => __('Jester hat', 'dcc-seasons'),
                'joint' => __('Joint', 'dcc-seasons'), 'jonboat' => __('Jon boat', 'dcc-seasons'),
                'kayak' => __('Kayak', 'dcc-seasons'), 'ladybug' => __('Ladybug', 'dcc-seasons'),
                'letter0' => __('Love letter', 'dcc-seasons'), 'lilypad' => __('Lily pad', 'dcc-seasons'),
                'mask' => __('Carnival mask', 'dcc-seasons'), 'medal' => __('Medal', 'dcc-seasons'),
                'necktie' => __('Necktie', 'dcc-seasons'), 'olive' => __('Olive branch', 'dcc-seasons'),
                'orange' => __('Orange', 'dcc-seasons'), 'ballred' => __('Red glass ball', 'dcc-seasons'), 'ballgold' => __('Gold glass ball', 'dcc-seasons'), 'ballblue' => __('Blue glass ball', 'dcc-seasons'),
                'candycane' => __('Candy cane', 'dcc-seasons'), 'palmxmas' => __('Sabal palm with lights', 'dcc-seasons'),
                'flamingoxmas' => __('Flamingo in a Santa hat', 'dcc-seasons'), 'wreath' => __('Wreath', 'dcc-seasons'),
                'peace' => __('Peace sign', 'dcc-seasons'), 'peacehand' => __('Peace hand', 'dcc-seasons'),
                'petal' => __('Petal', 'dcc-seasons'), 'pie' => __('Pie', 'dcc-seasons'),
                'pine' => __('Pine tree', 'dcc-seasons'), 'platemi' => __('Michigan licence plate', 'dcc-seasons'),
                'plateny' => __('New York licence plate', 'dcc-seasons'), 'plateoh' => __('Ohio licence plate', 'dcc-seasons'),
                'pontoon' => __('Pontoon boat', 'dcc-seasons'), 'poppy' => __('Poppy', 'dcc-seasons'),
                'quill' => __('Quill', 'dcc-seasons'), 'recycle' => __('Recycling symbol', 'dcc-seasons'),
                'ribbon' => __('Ribbon', 'dcc-seasons'), 'sabalpalm' => __('Sabal palm', 'dcc-seasons'),
                'sparkle' => __('Sparkle', 'dcc-seasons'), 'sparkler' => __('Sparkler', 'dcc-seasons'),
                'spider' => __('Spider', 'dcc-seasons'), 'sprout' => __('Sprout', 'dcc-seasons'),
                'suitcase' => __('Suitcase', 'dcc-seasons'), 'tacklebox' => __('Tackle box', 'dcc-seasons'),
                'tophat' => __('Top hat', 'dcc-seasons'), 'tree' => __('Tree', 'dcc-seasons'),
                'tulip' => __('Tulip', 'dcc-seasons'), 'turkey' => __('Turkey', 'dcc-seasons'),
                'umbrella' => __('Beach umbrella', 'dcc-seasons'), 'van' => __('Hippie van', 'dcc-seasons'),
                'watermelon' => __('Watermelon', 'dcc-seasons'), 'witchhat' => __('Witch’s hat', 'dcc-seasons'),
                // corner accents
                'web' => __('Spider web', 'dcc-seasons'), 'cornucopia' => __('Cornucopia', 'dcc-seasons'),
                'sunshades' => __('Sun in sunglasses', 'dcc-seasons'), 'hands' => __('Hands holding the Earth', 'dcc-seasons'),
                'sun' => __('Sun', 'dcc-seasons'),
                // 4.13.5: the Anniversary's pieces, and the sandhill crane
                // drawn in code (the Anniversary's pair and Florida Keys)
                'anheart' => __('Blush heart', 'dcc-seasons'), 'anrings' => __('Two gold rings', 'dcc-seasons'),
                'ancrystal' => __('Cut crystal drop', 'dcc-seasons'), 'antoast' => __('Champagne flutes clinking', 'dcc-seasons'),
                'andate' => __('Gold date band (11·11·11)', 'dcc-seasons'), 'anyear' => __('Crystal year count', 'dcc-seasons'),
                'anpct1' => __('Gold percentage', 'dcc-seasons'), 'anpct2' => __('Gold percentage', 'dcc-seasons'),
                'sandhill' => __('Sandhill crane', 'dcc-seasons'),
            ],
            'prims' => [
                'star' => __('Star', 'dcc-seasons'), 'confetti' => __('Confetti', 'dcc-seasons'),
                'bubble' => __('Champagne bubble', 'dcc-seasons'), 'egg' => __('Easter egg', 'dcc-seasons'),
                'heart' => __('Heart', 'dcc-seasons'), 'tulip' => __('Tulip', 'dcc-seasons'),
            ],
            'heroes' => [
                'heron' => __('Great blue heron', 'dcc-seasons'), 'eagle' => __('Bald eagle', 'dcc-seasons'),
                'osprey' => __('Osprey carrying a fish', 'dcc-seasons'), 'witch' => __('Witch and her cat', 'dcc-seasons'),
                'bass' => __('Jumping largemouth bass', 'dcc-seasons'), 'sleigh' => __('Santa’s sleigh', 'dcc-seasons'), 'santa' => __('Santa and his reindeer', 'dcc-seasons'),
                'manatee' => __('Manatee', 'dcc-seasons'), 'rainbow' => __('Rainbow and pot of gold', 'dcc-seasons'),
            ],
            'scenes' => [
                'flotilla' => __('A pontoon flotilla cruises by', 'dcc-seasons'),
                'fullcast' => __('A full cast: lure, bobber, and a bass on the line', 'dcc-seasons'),
                'dragonlands' => __('A dragonfly lands', 'dcc-seasons'),
                'dragonlotus' => __('A dragonfly lands on a lily pad', 'dcc-seasons'),
                'witchmoon' => __('The witch crosses the moon', 'dcc-seasons'),
            'cranemoon'    => __('Cranes across the full moon', 'dcc-seasons'),
                'gatorglide' => __('A gator glides by and sinks', 'dcc-seasons'),
                'floatdrift' => __('A flamingo pool float drifts by with a lost flip-flop', 'dcc-seasons'),
                'mulletskip' => __('A mullet skips three times, another answers', 'dcc-seasons'),
                'hibfloat' => __('A hibiscus bloom drops, floats, and a fish nibbles it', 'dcc-seasons'),
                'anhinga' => __('An anhinga dries its wings on a snag', 'dcc-seasons'),
                'ospreycatch' => __('An osprey dives and catches a fish', 'dcc-seasons'),
                'cranes' => __('A sandhill crane pair dances', 'dcc-seasons'),
                'limpkinsnail' => __('A limpkin pulls up an apple snail', 'dcc-seasons'),
                'giftdrop' => __('The sleigh drops a gift onto the water', 'dcc-seasons'),
                'sleighmoon' => __('Santa’s reindeer cross the moon', 'dcc-seasons'),
                'corkpop' => __('A champagne cork pops', 'dcc-seasons'),
                'arrival' => __('Three flamingos fly in and land', 'dcc-seasons'),
                'flagfly' => __('Flags fly across', 'dcc-seasons'),
                'doveflight' => __('Doves fly across', 'dcc-seasons'),
                'stilts' => __('A stilt walker crosses', 'dcc-seasons'),
                'kayaker' => __('A kayaker paddles by', 'dcc-seasons'),
                'doubloons' => __('Doubloons are tossed', 'dcc-seasons'),
                'swans' => __('Two swans meet', 'dcc-seasons'),
                'catch1' => __('Strawberries fall into a basket', 'dcc-seasons'),
                'egghunt' => __('A bunny hunts for eggs', 'dcc-seasons'),
                'hatch' => __('An egg hatches a chick', 'dcc-seasons'),
                'bananaslip' => __('A jester slips on a banana peel', 'dcc-seasons'),
                'duckparade' => __('A mother duck leads her ducklings', 'dcc-seasons'),
                'annivdance' => __('A sandhill crane pair dances under the title', 'dcc-seasons'),
            ],
        ];
    }
}
