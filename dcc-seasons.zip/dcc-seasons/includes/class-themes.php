<?php
/**
 * Theme definitions and the pre-seeded schedule.
 *
 * A theme has two halves:
 *  - 'ambient': the site-wide subtle particle layer, run by the lazy-loaded
 *      engine (assets/js/engine.js). Keys:
 *        mode      'drift' (default) or 'burst' (firework emitters)
 *        water     true → the invisible waterline along the bottom ~8% of
 *                  the viewport is active (settle/float/jump/submerged,
 *                  reflections, cruise wakes)
 *        up        true → fall-family behaviors run upward (April Fool's)
 *        hero      extra rare crosser besides the year-round heron
 *        max       optional per-theme cap below the density option
 *        particles particle specs (see below)
 *      Particle spec keys (short — they ship as JSON):
 *        e  emoji glyph            f  fallback glyph if e can't render
 *        fc fallback tint          s  SVG sprite key OR array of keys
 *                                     (engine registry; picked per spawn)
 *        c  canvas primitive key   b  behavior/personality name
 *        w  spawn weight           st 1 → settles on the waterline
 *        sz [min,max] px           cl color list for tinted primitives
 *        glow 1 → soft halo        face 'L' → native art faces LEFT, the
 *                                     engine mirrors it travelling right
 *        fx draw extra: smoke | glint | lights | string | letter | trail |
 *           orbitarrows | shine | chicks (trailing chicks on a waddler)
 *      Behaviors: fall sway flutter wobble float rise grow fly vee pulse
 *      orbit tumble dangle hang toss hop waddle dart twinkle chatter jump
 *      spin cruise frogger berrycycle (mode 'burst' adds the firework
 *      emitter + auto-year text). Vignettes, heroes, corner accents,
 *      parallax, reflections, evening variants and the degrade ladder live
 *      in the engine keyed by theme.
 *  - 'egg': the Matrix-rain recolor/re-glyph config. (The false-to-disable
 *      form still works but no theme uses it — every theme ships full.)
 *      Optional 'finale': a glyph (or 'YEAR') the rain briefly organizes
 *      into ~18s in, via an alpha-mask of that glyph.
 *
 * Everything here ships to the client as JSON; JS picks the active row from
 * the visitor's local date so cached HTML stays date-agnostic.
 *
 * @package DCC_Seasons
 */

namespace DCC_Seasons;

if (!defined('ABSPATH')) {
    exit;
}

class Themes {

    /**
     * Half-width katakana + digits — the classic Matrix glyph set.
     *
     * @return string[]
     */
    private static function katakana(): array {
        return preg_split('//u', 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ0123456789', -1, PREG_SPLIT_NO_EMPTY);
    }

    /**
     * All theme definitions, filterable via 'dcc_seasons_themes'.
     *
     * @return array<string, array>
     */
    public static function themes(): array {
        $katakana = self::katakana();
        // The four real leaf species on the canal (maple, oak, cypress,
        // sweetgum) — shared by the fall themes.
        $leaves = ['leafm', 'leafo', 'leafc', 'leafs'];

        $themes = [
            'labor_day' => [
                'ambient' => [
                    'water'     => true,
                    'particles' => [
                        ['c' => 'star', 'cl' => ['#B22234', '#F1F3F5', '#3C3B6E'], 'b' => 'fall', 'w' => 2],
                        ['s' => 'burger', 'b' => 'fall', 'w' => 2],
                        ['s' => 'grill', 'b' => 'grow', 'fx' => 'smoke', 'sz' => [26, 32]],
                        ['s' => 'cooler', 'b' => 'tumble', 'sz' => [20, 26]],
                        ['s' => 'umbrella', 'b' => 'grow'],
                        ['s' => 'pontoon', 'b' => 'cruise', 'face' => 'L', 'w' => 2, 'sz' => [32, 40]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FF5252', '#F1F3F5', '#5C7CFA'],
                    'glyphs' => ['★', '▮', '✦', '1', '0'],
                ],
            ],

            // Patriot Day — full celebratory-patriotic theme (the "gentle"
            // variant was retired in 3.2.0 at the owner's request).
            'patriot_day' => [
                'ambient' => [
                    'hero'      => 'eagle',
                    'particles' => [
                        /* Minimal and sober by instruction: the flag,
                         * carried slowly, and nothing else but a few quiet
                         * stars. The twinkling star and the sparkle that
                         * used to be here are celebration, which is the
                         * wrong register for 11 September. */
                        ['s' => 'flagcloth', 'b' => 'fly', 'face' => 'L', 'w' => 3, 'sz' => [26, 34]],
                        ['c' => 'star', 'cl' => ['#B22234', '#F1F3F5', '#3C3B6E'], 'b' => 'fall', 'w' => 1],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FF5252', '#F1F3F5', '#5C7CFA'],
                    'glyphs' => ['★', '✦', '▮', '1', '0'],
                    'finale' => '★',
                ],
            ],

            'fall_fishing' => [
                'ambient' => [
                    'water'     => true,
                    'hero'      => 'bass',
                    'particles' => [
                        ['s' => $leaves, 'b' => 'sway', 'st' => 1, 'w' => 4],
                        ['s' => 'bobber', 'b' => 'float', 'w' => 2],
                        ['s' => 'hook', 'b' => 'dangle', 'worm' => 1],
                        ['s' => 'bass', 'b' => 'jump', 'face' => 'L', 'w' => 2],
                        ['s' => 'tacklebox', 'b' => 'grow', 'sz' => [24, 30]],
                        ['s' => 'dragonfly', 'b' => 'dart'],
                    ],
                ],
                'egg' => [
                    'colors' => ['#1864AB', '#0B7285', '#12B886'],
                    'glyphs' => ['~', '≈', 'ﾂ', 'ｼ', 'ﾉ', '0', '1'],
                ],
            ],

            'halloween' => [
                'ambient' => [
                    'hero'      => 'witch',
                    'particles' => [
                        ['s' => ['jack1', 'jack2', 'jack3'], 'b' => 'fall', 'glow' => 1, 'w' => 3],
                        ['s' => 'ghost', 'b' => 'wobble', 'w' => 2],
                        ['s' => 'bat', 'b' => 'flutter', 'w' => 2],
                        ['s' => 'spider', 'b' => 'dangle'],
                        ['s' => 'candycorn', 'b' => 'fall'],
                        ['s' => 'witchhat', 'b' => 'fall'],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FF7A00', '#9C36B5'],
                    'glyphs' => ['☠', 'ﾊ', 'ｷ', 'ﾒ', '0', '1'],
                    'finale' => '🎃',
                ],
            ],

            'thanksgiving' => [
                'ambient' => [
                    'water'     => true,
                    'particles' => [
                        ['s' => $leaves, 'b' => 'sway', 'st' => 1, 'w' => 5],
                        ['s' => 'acorn', 'b' => 'fall', 'w' => 2],
                        ['s' => 'pie', 'b' => 'fall', 'fx' => 'smoke'],
                        // Turkey 2.0 leads two chicks along the bottom.
                        ['s' => 'turkey', 'b' => 'waddle', 'face' => 'L', 'fx' => 'chicks', 'sz' => [26, 32]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#E8890C', '#A05A2C'],
                    'glyphs' => ['ﾅ', 'ｵ', 'ﾂ', '✦', '1', '0'],
                    'finale' => '🦃',
                ],
            ],

            'christmas' => [
                'ambient' => [
                    'water'     => true,
                    'hero'      => 'sleigh',
                    'particles' => [
                        ['s' => 'snowflake', 'b' => 'fall', 'st' => 1, 'w' => 4, 'sz' => [10, 26]],
                        ['s' => 'ornament', 'b' => 'hang', 'fx' => 'glint', 'w' => 2],
                        ['s' => 'holly', 'b' => 'hang'],
                        ['s' => 'gift', 'b' => 'fall'],
                        // Pine grows from the bottom, then pops its lights on.
                        ['s' => 'pine', 'b' => 'grow', 'fx' => 'lights', 'sz' => [28, 38]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#2F9E44', '#E03131'],
                    'glyphs' => ['❄', '✦', '*', 'ｼ', 'ﾒ', '0'],
                    'finale' => '🎄',
                ],
            ],

            'new_years' => [
                'ambient' => [
                    'mode'      => 'burst',
                    'particles' => [
                        ['c' => 'confetti', 'cl' => ['#FFD43B', '#E03131', '#339AF0', '#2F9E44', '#CED4DA'], 'b' => 'tumble', 'w' => 3],
                        ['s' => 'flutes', 'b' => 'rise'],
                        ['c' => 'bubble', 'cl' => ['#FFD43B', '#F8F0C8'], 'b' => 'rise', 'w' => 2],
                        ['s' => 'sparkle', 'b' => 'twinkle', 'w' => 2],
                    ],
                    'sparkCl'   => ['#FFD43B', '#CED4DA', '#FAB005', '#F1F3F5'],
                ],
                'egg' => [
                    'colors' => ['#FFD43B', '#CED4DA'],
                    'glyphs' => ['2', '0', '2', '7', '✦', '★'],
                    'finale' => 'YEAR',
                ],
            ],

            'snowbird' => [
                'ambient' => [
                    'water'     => true,
                    'hero'      => 'manatee',
                    'particles' => [
                        ['s' => 'flamingo', 'b' => 'vee', 'face' => 'L', 'w' => 2],
                        ['s' => 'suitcase', 'b' => 'tumble', 'sz' => [22, 28]],
                        ['s' => 'orange', 'b' => 'fall', 'w' => 2],
                        // Real plate colors + state silhouettes.
                        ['s' => ['plateny', 'plateoh', 'platemi'], 'b' => 'fall', 'sz' => [26, 32]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#4DABF7', '#A5D8FF'],
                    'glyphs' => ['~', 'ﾂ', 'ｿ', '✦', '0', '1'],
                ],
            ],

            // MLK Day — celebratory and dignified: doves in flight, a
            // gold/white palette, hearts. Full richness like every other
            // theme (the "gentle" variant was retired in 3.2.0).
            'mlk' => [
                'ambient' => [
                    'particles' => [
                        ['s' => 'dove', 'b' => 'fly', 'face' => 'L', 'w' => 3, 'sz' => [26, 34]],
                        ['s' => 'olive', 'b' => 'sway', 'w' => 2],
                        ['c' => 'heart', 'cl' => ['#B8860B', '#F1F3F5', '#FFD43B'], 'b' => 'pulse', 'w' => 2],
                        ['s' => 'sparkle', 'b' => 'twinkle'],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FFD43B', '#F1F3F5', '#B8860B'],
                    'glyphs' => ['♥', '✦', 'ﾒ', '✧', '0'],
                    'finale' => '♥',
                ],
            ],

            'mardi_gras' => [
                'ambient' => [
                    'particles' => [
                        ['s' => 'beads', 'b' => 'toss', 'fx' => 'shine', 'w' => 3],
                        ['s' => 'doubloon', 'b' => 'tumble', 'glint' => 1, 'w' => 2],
                        ['s' => 'fleur', 'b' => 'fall'],
                        ['s' => 'mask', 'b' => 'fall', 'sz' => [26, 32]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#7C3AED', '#2F9E44', '#F1C40F'],
                    'glyphs' => ['⚜', '*', 'ｻ', '✦', '0'],
                    'finale' => '⚜',
                ],
            ],

            'valentines' => [
                'ambient' => [
                    'water'     => true,
                    'particles' => [
                        // Petals, not whole roses — they land and drift.
                        ['s' => 'petal', 'b' => 'sway', 'st' => 1, 'w' => 3],
                        ['c' => 'heart', 'cl' => ['#FA5252', '#E64980', '#F783AC'], 'b' => 'pulse', 'w' => 2],
                        ['s' => 'balloon', 'b' => 'rise', 'fx' => 'string', 'sz' => [24, 30]],
                        // Opens mid-fall and releases three tiny hearts.
                        ['s' => 'letter0', 'b' => 'fall', 'fx' => 'letter', 'sz' => [22, 26]],
                        ['c' => 'heart', 'cl' => ['#F06595', '#FA5252'], 'b' => 'orbit'],
                    ],
                ],
                'egg' => [
                    'colors' => ['#F06595', '#FA5252'],
                    'glyphs' => ['♥', '♡', 'ﾒ', '1'],
                    'finale' => '♥',
                ],
            ],

            'presidents' => [
                'ambient' => [
                    'particles' => [
                        ['s' => 'tophat', 'b' => 'tumble', 'w' => 2, 'sz' => [24, 30]],
                        // Quill leaves a brief ink squiggle as it sways down.
                        ['s' => 'quill', 'b' => 'sway', 'fx' => 'trail'],
                        ['s' => 'cherry', 'b' => 'fall'],
                        ['c' => 'star', 'cl' => ['#B22234', '#F1F3F5', '#3C3B6E'], 'b' => 'fall', 'w' => 2],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FF5252', '#F1F3F5', '#5C7CFA'],
                    'glyphs' => ['★', '✦', '0', '1'],
                ],
            ],

            'strawberry' => [
                'ambient' => [
                    'water'     => true,
                    'particles' => [
                        ['s' => 'berry', 'b' => 'tumble', 'w' => 3, 'sz' => [20, 26]],
                        ['s' => 'blossom', 'b' => 'sway', 'st' => 1, 'w' => 2],
                        // Bloom → petals → berry swells → drops off.
                        ['s' => 'blossom', 'b' => 'berrycycle'],
                        ['s' => 'ladybug', 'b' => 'waddle', 'face' => 'L', 'sz' => [12, 16]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#E03131', '#2F9E44'],
                    'glyphs' => ['ｽ', 'ﾍ', '✿', '0', '1'],
                ],
            ],

            'st_patricks' => [
                'ambient' => [
                    'hero'      => 'rainbow',
                    'particles' => [
                        ['s' => 'clover', 'b' => 'tumble', 'w' => 4],
                        ['s' => 'horseshoe', 'b' => 'fall'],
                    ],
                ],
                'egg' => [
                    'colors' => ['#00FF41'],
                    'glyphs' => array_merge($katakana, ['☘', '☘', '☘']),
                    'finale' => '☘',
                ],
            ],

            'easter' => [
                'ambient' => [
                    'particles' => [
                        ['c' => 'egg', 'cl' => ['#F9A8D4', '#A7F3D0', '#BFDBFE', '#FDE68A', '#D8B4FE'], 'b' => 'tumble', 'w' => 4, 'sz' => [20, 30]],
                        ['s' => 'bunny', 'b' => 'hop', 'face' => 'L', 'sz' => [24, 30]],
                        ['s' => 'chick', 'b' => 'waddle', 'face' => 'L', 'sz' => [16, 20]],
                        ['c' => 'tulip', 'cl' => ['#E64980', '#FAB005', '#7C3AED'], 'b' => 'grow', 'w' => 2],
                    ],
                ],
                'egg' => [
                    'colors' => ['#F9A8D4', '#A7F3D0', '#BFDBFE', '#FDE68A'],
                    'glyphs' => ['✿', 'ｵ', '✦', 'ﾒ', '0'],
                    'finale' => '🥚',
                ],
            ],

            'april_fools' => [
                'ambient' => [
                    'up'        => true,
                    'particles' => [
                        ['s' => 'banana', 'b' => 'tumble', 'w' => 2],
                        ['s' => 'jester', 'b' => 'fall', 'w' => 3],
                        ['s' => 'disguise', 'b' => 'fall', 'sz' => [24, 30]],
                        // The whoopee cushion was retired in 3.15.0 (it read as
                        // neither a cushion nor a joke at 30px); the disguise
                        // skitters across instead.
                        ['s' => 'disguise', 'b' => 'chatter', 'sz' => [20, 26]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#00FF41'],
                    'glyphs' => $katakana,
                    'dir'    => 'up',
                    'glitch' => true,
                ],
            ],

            'spring_canal' => [
                'ambient' => [
                    'water'     => true,
                    'particles' => [
                        ['s' => 'lilypad', 'b' => 'float', 'w' => 2, 'sz' => [26, 34]],
                        // The frog sprite was retired in 3.15.0 (it was legless);
                        // a dragonfly touches down pad to pad instead, which is
                        // what the behaviour actually does.
                        ['s' => 'dragonfly', 'b' => 'frogger', 'sz' => [16, 20]],
                        ['s' => 'petal', 'b' => 'sway', 'st' => 1, 'w' => 2],
                        ['s' => 'dragonfly', 'b' => 'dart'],
                        ['s' => 'kayak', 'b' => 'cruise', 'face' => 'L'],
                    ],
                ],
                'egg' => [
                    'colors' => ['#37B24D', '#339AF0'],
                    'glyphs' => ['✿', '~', 'ﾊ', '≈', '1'],
                ],
            ],

            'four_twenty' => [
                'ambient' => [
                    'particles' => [
                        // Real field marks: 7 serrated lance leaflets.
                        ['s' => 'cannabis', 'b' => 'sway', 'w' => 3],
                        // A drawn joint with an ember and its own curling
                        // smoke — replaces the old gray "noodle" wisps.
                        ['s' => 'joint', 'b' => 'rise', 'fx' => 'smoke', 'w' => 2, 'sz' => [22, 28]],
                        ['s' => 'peace', 'b' => 'spin', 'sz' => [24, 30]],
                        ['s' => 'peacehand', 'b' => 'fall'],
                        ['s' => 'basket', 'b' => 'grow', 'sz' => [24, 30]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#2F9E44'],
                    'glyphs' => ['@leaf', 'ﾊ', 'ﾒ', '0', '1'],
                ],
            ],

            // ---- 3.7.0: the summer half of the year --------------------------

            // Independence Day: New Year's fireworks machinery in red, white
            // and blue, the eagle as hero, sparklers falling.
            'july4' => [
                'ambient' => [
                    'mode'      => 'burst',
                    'hero'      => 'eagle',
                    'particles' => [
                        ['s' => 'flagcloth', 'b' => 'fly', 'face' => 'L', 'w' => 2, 'sz' => [26, 34]],
                        ['c' => 'star', 'cl' => ['#B22234', '#F1F3F5', '#3C3B6E'], 'b' => 'fall', 'w' => 3],
                        ['s' => 'sparkler', 'b' => 'fall', 'glow' => 1, 'w' => 3, 'sz' => [22, 30]],
                        ['c' => 'confetti', 'cl' => ['#FF5252', '#F1F3F5', '#5C7CFA'], 'b' => 'tumble', 'w' => 2],
                    ],
                    'sparkCl'   => ['#FF5252', '#F1F3F5', '#5C7CFA', '#FFD43B'],
                ],
                'egg' => [
                    'colors' => ['#FF5252', '#F1F3F5', '#5C7CFA'],
                    'glyphs' => ['★', '✦', '1', '7', '7', '6'],
                    'finale' => '★',
                ],
            ],

            // Memorial Day: remembrance poppies, the flag, doves — and the
            // eagle. Celebratory-patriotic like Patriot Day, not "gentle".
            'memorial_day' => [
                'ambient' => [
                    'hero'      => 'eagle',
                    'particles' => [
                        /* Poppies and doves, and deliberately nothing
                         * else. The flag and the falling stars were shared
                         * with the celebratory themes and were most of why
                         * the patriotic rotation felt like one theme. */
                        ['s' => 'poppy', 'b' => 'sway', 'st' => 1, 'w' => 4, 'sz' => [20, 28]],
                        ['s' => 'dove', 'b' => 'fly', 'face' => 'L', 'w' => 2],
                        /* A pale star, not the red/white/blue one every
                         * patriotic theme shared. Same count as before,
                         * nothing shared with the celebratory themes. */
                        ['c' => 'star', 'cl' => ['#F1F3F5', '#DEE2E6'], 'b' => 'twinkle', 'w' => 1],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FF5252', '#F1F3F5', '#5C7CFA'],
                    'glyphs' => ['★', '✦', '▮', '1', '0'],
                    'finale' => '★',
                ],
            ],

            // Mother's Day: tulips and blossom, a card that opens into
            // hearts, a balloon on a string.
            'mothers_day' => [
                'ambient' => [
                    'water'     => true,
                    'particles' => [
                        ['s' => 'tulip', 'b' => 'grow', 'w' => 2, 'sz' => [22, 30]],
                        ['s' => 'blossom', 'b' => 'sway', 'st' => 1, 'w' => 2],
                        ['s' => 'petal', 'b' => 'sway', 'st' => 1, 'w' => 2],
                        ['c' => 'heart', 'cl' => ['#F783AC', '#E64980', '#B197FC'], 'b' => 'pulse', 'w' => 2],
                        ['s' => 'letter0', 'b' => 'fall', 'fx' => 'letter', 'sz' => [22, 26]],
                        ['s' => 'balloon', 'b' => 'rise', 'fx' => 'string', 'sz' => [24, 30]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#F783AC', '#B197FC'],
                    'glyphs' => ['♥', '✿', '❀', 'ﾒ', '1'],
                    'finale' => '♥',
                ],
            ],

            // Father's Day: the dock — a bass on the line, the grill going,
            // a necktie nobody asked for.
            'fathers_day' => [
                'ambient' => [
                    'water'     => true,
                    'hero'      => 'bass',
                    'particles' => [
                        // Hangs from the top edge like an ornament: upright, a tie
                        // reads instantly; tumbling, it read as a rocket.
                        ['s' => 'necktie', 'b' => 'hang', 'w' => 2, 'sz' => [18, 26]],
                        ['s' => 'bobber', 'b' => 'float', 'w' => 2],
                        ['s' => 'hook', 'b' => 'dangle', 'worm' => 1],
                        ['s' => 'bass', 'b' => 'jump', 'face' => 'L'],
                        ['s' => 'grill', 'b' => 'grow', 'fx' => 'smoke', 'sz' => [26, 32]],
                        ['s' => 'burger', 'b' => 'fall'],
                        ['s' => 'cooler', 'b' => 'tumble', 'sz' => [20, 26]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#1864AB', '#0B7285', '#12B886'],
                    'glyphs' => ['~', '≈', 'ﾂ', 'ｼ', '0', '1'],
                ],
            ],

            // Veterans Day: flag, poppies, a medal, doves; the eagle.
            'veterans_day' => [
                'ambient' => [
                    'hero'      => 'eagle',
                    'particles' => [
                        /* Sombre, but not Memorial Day. Medals and the
                         * remembrance ribbon lead; the dove is left as
                         * Memorial's marker so the two read apart at a
                         * glance. Poppy is the one sprite they share.
                         *
                         * 'ribbon' had been drawn but never displayed: the
                         * theme carried it as 'accent' => ['svg' => ...],
                         * a key the engine has never read (its ACCENTS map
                         * is hardcoded by theme). Using it as a particle is
                         * what makes it real. */
                        ['s' => 'medal', 'b' => 'dangle', 'w' => 3, 'sz' => [20, 26]],
                        ['s' => 'ribbon', 'b' => 'flutter', 'w' => 3, 'sz' => [18, 26]],
                        ['s' => 'poppy', 'b' => 'sway', 'st' => 1, 'w' => 2, 'sz' => [20, 28]],
                        /* The dove stays in the brief's list for Veterans,
                         * but at a weight that keeps it Memorial's motif:
                         * the two share their contents, not their feel. */
                        ['s' => 'dove', 'b' => 'fly', 'face' => 'L', 'w' => 1],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FF5252', '#F1F3F5', '#5C7CFA'],
                    'glyphs' => ['★', '▮', '✦', '1', '0'],
                    'finale' => '★',
                ],
            ],

            // Summer on the Canal: the long default from Memorial Day to
            // Labor Day — sun in the corner, boats on the water, dragonflies,
            // watermelon and flip-flops.
            'summer_canal' => [
                'ambient' => [
                    'water'     => true,
                    'hero'      => 'bass',
                    'particles' => [
                        ['s' => 'watermelon', 'b' => 'tumble', 'w' => 2, 'sz' => [24, 32]],
                        ['s' => 'flipflop', 'b' => 'fall', 'w' => 2, 'sz' => [16, 22]],
                        ['s' => 'icecream', 'b' => 'fall', 'sz' => [18, 24]],
                        ['s' => 'sunshades', 'b' => 'tumble', 'sz' => [22, 28]],
                        ['s' => 'dragonfly', 'b' => 'dart'],
                        ['s' => 'lilypad', 'b' => 'float', 'sz' => [26, 34]],
                        ['s' => 'kayak', 'b' => 'cruise', 'face' => 'L'],
                        ['s' => 'pontoon', 'b' => 'cruise', 'face' => 'L', 'sz' => [32, 40]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#FFD43B', '#4DABF7'],
                    'glyphs' => ['☀', '~', '≈', 'ﾂ', '1'],
                    'finale' => '☀',
                ],
            ],

            'earth_day' => [
                'ambient' => [
                    'particles' => [
                        ['s' => 'sprout', 'b' => 'grow', 'w' => 2],
                        ['s' => 'globe', 'b' => 'pulse', 'fx' => 'orbitarrows', 'sz' => [26, 32]],
                        ['s' => 'recycle', 'b' => 'spin'],
                        ['s' => 'tree', 'b' => 'grow'],
                    ],
                ],
                'egg' => [
                    'colors' => ['#2F9E44', '#339AF0'],
                    'glyphs' => ['ﾂ', 'ﾜ', '✦', '0', '1'],
                    'finale' => '🌎',
                ],
            ],

            // Florida Keys: the year-round base. It can land in any month,
            // so nothing in it may read as a season — sabal palms (the state
            // tree, and what actually grows along the canal), a hibiscus
            // bloom that lasts a day and drops, a flats skiff, a queen conch.
            // The brown pelican is the hero.
            'florida_keys' => [
                'ambient' => [
                    'water'     => true,
                    'hero'      => 'pelican',
                    'particles' => [
                        // 'grow' (not 'sway'): 'sway' is the falling-leaf drift, and a
                        // palm TREE drifting down the page reads as a bug. 'grow' is
                        // what tree/pine use — it rises from the bottom edge and
                        // stands there. One word to change back.
                        ['s' => 'sabalpalm', 'b' => 'grow', 'w' => 2, 'sz' => [26, 34]],
                        ['s' => 'hibiscus', 'b' => 'fall', 'w' => 2, 'sz' => [18, 24]],
                        ['s' => 'skiff', 'b' => 'cruise', 'face' => 'L', 'sz' => [30, 38]],
                        ['s' => 'conch', 'b' => 'tumble', 'sz' => [16, 22]],
                        ['s' => 'sun', 'b' => 'pulse', 'sz' => [26, 32]],
                        ['s' => 'sunshades', 'b' => 'tumble', 'sz' => [22, 28]],
                        ['s' => 'dragonfly', 'b' => 'dart'],
                        ['s' => 'lilypad', 'b' => 'float', 'sz' => [26, 34]],
                    ],
                ],
                'egg' => [
                    'colors' => ['#20B2AA', '#FF7F50'],
                    'glyphs' => ['≈', '~', '☀', '⚓', 'ﾂ'],
                    'finale' => '☀',
                ],
            ],

            // Fallback for dates outside every range — the year-round face
            // of the site: the heron (now with a full landing sequence) and
            // at most ONE quiet canal touch at a time. Sparse is the point.
            'classic' => [
                'ambient' => [
                    'water'     => true,
                    'max'       => 1,
                    'particles' => [
                        ['s' => 'dragonfly', 'b' => 'dart'],
                    ],
                ],
                'egg'     => [
                    'colors' => ['#00FF41'],
                    'glyphs' => $katakana,
                ],
            ],
        ];

        /**
         * Filter every theme definition (ambient particles, egg palettes…).
         *
         * @param array $themes Theme key => definition.
         */
        return apply_filters('dcc_seasons_themes', $themes);
    }

    /**
     * Human-readable theme labels for the admin schedule dropdown.
     *
     * @return array<string, string>
     */
    /**
     * Layer 1 — the subtle layer: which quiet effect each theme runs.
     *
     * Four seasonal effects carry the year, with five bespoke exceptions
     * for the days where a guest would notice anything else. Deliberately
     * NOT 27 bespoke effects: the subtle layer is the calm baseline, and a
     * different flourish every fortnight is the opposite of calm.
     *
     * The engine mirrors this map as SUBTLE_FALLBACK for a cached config
     * that predates the setting; keep the two in step, the same way
     * ambient.js mirrors BASE_THEME.
     *
     * '' means no subtle layer at all — 'classic' is the "None" option, so
     * choosing it means choosing nothing.
     *
     * @return array<string, string> theme key => effect key.
     */
    public static function subtle_defaults(): array {
        return [
            // Fall
            'patriot_day'  => 'leaves',
            'fall_fishing' => 'leaves',
            'thanksgiving' => 'leaves',
            'veterans_day' => 'leaves',
            // Winter
            'snowbird'     => 'snow',
            'mlk'          => 'snow',
            'mardi_gras'   => 'snow',
            'presidents'   => 'snow',
            // Spring
            'strawberry'   => 'blossom',
            'st_patricks'  => 'blossom',
            'easter'       => 'blossom',
            'april_fools'  => 'blossom',
            'spring_canal' => 'blossom',
            'four_twenty'  => 'blossom',
            'mothers_day'  => 'blossom',
            'earth_day'    => 'blossom',
            // Summer — dragonflies over a faint heat shimmer on the water
            'labor_day'    => 'dragonheat',
            'memorial_day' => 'dragonheat',
            'fathers_day'  => 'dragonheat',
            'summer_canal' => 'dragonheat',
            'florida_keys' => 'dragonheat',
            // The five exceptions
            'valentines'   => 'hearts',
            'new_years'    => 'confetti',
            'halloween'    => 'embers',
            'july4'        => 'sparks',
            'christmas'    => 'bokeh',
            // The "None" option means none of this either.
            'classic'      => '',
        ];
    }

    public static function labels(): array {
        return [
            'labor_day'    => __('Labor Day', 'dcc-seasons'),
            'patriot_day'  => __('Patriot Day', 'dcc-seasons'),
            'fall_fishing' => __('Fall Fishing', 'dcc-seasons'),
            'halloween'    => __('Halloween', 'dcc-seasons'),
            'thanksgiving' => __('Thanksgiving', 'dcc-seasons'),
            'christmas'    => __('Christmas', 'dcc-seasons'),
            'new_years'    => __('New Year\'s (fireworks)', 'dcc-seasons'),
            'snowbird'     => __('Snowbird Season', 'dcc-seasons'),
            'mlk'          => __('MLK Day', 'dcc-seasons'),
            'mardi_gras'   => __('Mardi Gras', 'dcc-seasons'),
            'valentines'   => __('Valentine\'s', 'dcc-seasons'),
            'presidents'   => __('Presidents Day', 'dcc-seasons'),
            'strawberry'   => __('Strawberry Season', 'dcc-seasons'),
            'st_patricks'  => __('St. Patrick\'s', 'dcc-seasons'),
            'easter'       => __('Easter', 'dcc-seasons'),
            'april_fools'  => __('April Fool\'s', 'dcc-seasons'),
            'spring_canal' => __('Spring on the Canal', 'dcc-seasons'),
            'four_twenty'  => __('4/20', 'dcc-seasons'),
            'earth_day'    => __('Earth Day', 'dcc-seasons'),
            'july4'        => __('Independence Day', 'dcc-seasons'),
            'memorial_day' => __('Memorial Day', 'dcc-seasons'),
            'mothers_day'  => __('Mother\'s Day', 'dcc-seasons'),
            'fathers_day'  => __('Father\'s Day', 'dcc-seasons'),
            'veterans_day' => __('Veterans Day', 'dcc-seasons'),
            'summer_canal' => __('Summer on the Canal', 'dcc-seasons'),
            'florida_keys' => __('Florida Keys (year-round base)', 'dcc-seasons'),
            'classic'      => __('None (heron + classic green egg only)', 'dcc-seasons'),
        ];
    }

    /**
     * The pre-seeded 2026–27 schedule. Dates are Y-m-d and compared as
     * strings against the visitor's LOCAL date in JS.
     *
     * @return array<int, array{start:string,end:string,theme:string,label:string}>
     */
    /**
     * The recurring default schedule (rules, not dates). See Schedule.
     */
    public static function default_schedule(): array {
        return Schedule::defaults();
    }

    /**
     * The pre-3.7.0 default, dated for 2026-27. Kept ONLY so an unmodified
     * stored copy of it can be recognised and replaced on upgrade.
     */
    public static function legacy_default_schedule(): array {
        return [
            ['start' => '2026-09-01', 'end' => '2026-09-07', 'theme' => 'labor_day',    'label' => __('Labor Day', 'dcc-seasons')],
            ['start' => '2026-09-08', 'end' => '2026-09-11', 'theme' => 'patriot_day',  'label' => __('Patriot Day', 'dcc-seasons')],
            ['start' => '2026-09-12', 'end' => '2026-09-30', 'theme' => 'fall_fishing', 'label' => __('Fall Fishing', 'dcc-seasons')],
            ['start' => '2026-10-01', 'end' => '2026-10-31', 'theme' => 'halloween',    'label' => __('Halloween', 'dcc-seasons')],
            ['start' => '2026-11-01', 'end' => '2026-11-26', 'theme' => 'thanksgiving', 'label' => __('Thanksgiving', 'dcc-seasons')],
            ['start' => '2026-11-27', 'end' => '2026-12-25', 'theme' => 'christmas',    'label' => __('Christmas', 'dcc-seasons')],
            ['start' => '2026-12-26', 'end' => '2027-01-03', 'theme' => 'new_years',    'label' => __('New Year\'s', 'dcc-seasons')],
            ['start' => '2027-01-04', 'end' => '2027-01-17', 'theme' => 'snowbird',     'label' => __('Snowbird Season', 'dcc-seasons')],
            ['start' => '2027-01-18', 'end' => '2027-01-18', 'theme' => 'mlk',          'label' => __('MLK Day', 'dcc-seasons')],
            ['start' => '2027-01-19', 'end' => '2027-01-31', 'theme' => 'snowbird',     'label' => __('Snowbird Season', 'dcc-seasons')],
            ['start' => '2027-02-01', 'end' => '2027-02-09', 'theme' => 'mardi_gras',   'label' => __('Mardi Gras', 'dcc-seasons')],
            ['start' => '2027-02-10', 'end' => '2027-02-14', 'theme' => 'valentines',   'label' => __('Valentine\'s', 'dcc-seasons')],
            ['start' => '2027-02-15', 'end' => '2027-02-15', 'theme' => 'presidents',   'label' => __('Presidents Day', 'dcc-seasons')],
            ['start' => '2027-02-16', 'end' => '2027-03-01', 'theme' => 'strawberry',   'label' => __('Strawberry Season', 'dcc-seasons')],
            ['start' => '2027-03-02', 'end' => '2027-03-17', 'theme' => 'st_patricks',  'label' => __('St. Patrick\'s', 'dcc-seasons')],
            ['start' => '2027-03-18', 'end' => '2027-03-31', 'theme' => 'easter',       'label' => __('Easter', 'dcc-seasons')],
            ['start' => '2027-04-01', 'end' => '2027-04-01', 'theme' => 'april_fools',  'label' => __('April Fool\'s', 'dcc-seasons')],
            ['start' => '2027-04-02', 'end' => '2027-04-19', 'theme' => 'spring_canal', 'label' => __('Spring on the Canal', 'dcc-seasons')],
            ['start' => '2027-04-20', 'end' => '2027-04-20', 'theme' => 'four_twenty',  'label' => __('4/20', 'dcc-seasons')],
            ['start' => '2027-04-21', 'end' => '2027-04-22', 'theme' => 'earth_day',    'label' => __('Earth Day', 'dcc-seasons')],
        ];
    }

    /**
     * The effective schedule (saved option rows), filterable.
     *
     * @param array $rows Saved schedule rows.
     * @return array
     */
    public static function schedule(array $rows): array {
        /**
         * Filter the schedule sent to the client.
         *
         * @param array $rows Each row: start + end rules ({on, off, m?, d?}),
         *                    theme key, label, year (0 = every year).
         */
        return apply_filters('dcc_seasons_schedule', $rows);
    }
}
