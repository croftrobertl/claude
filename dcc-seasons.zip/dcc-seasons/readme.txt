=== DCC Seasons ===
Contributors: doracanalcourt
Tags: seasonal, particles, easter egg, matrix, canvas
Requires at least: 6.3
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 3.2.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Date-scheduled seasonal ambient particles plus a tap-the-logo Matrix-style
easter egg, built cache-safe and performance-first for doracanalcourt.com.

== Description ==

Two layers, both vanilla JS + 2D canvas (no libraries, no WebGL, no image
assets — every ambient particle is a bespoke inline-SVG sprite or a canvas
primitive drawn in code; emoji survive only as tofu fallbacks and as the
Matrix rain's deliberate glyph aesthetic):

1. **Ambient mode** — a sparse, slow, low-opacity drift of themed particles
   over the page during each scheduled date range. Capped at 16 particles,
   requestAnimationFrame-driven, paused when the tab is hidden, drawn on a
   `position:fixed`, `pointer-events:none`, `aria-hidden` canvas (zero CLS,
   never intercepts a click).
2. **Easter egg** — tapping/clicking the site logo (`#branding`, fallback
   `#site-title`) 5 times within a rolling 3-second window launches a
   full-screen Matrix-style glyph rain recolored and re-glyphed for the
   current theme (orange pumpkin rain in October, pastel egg rain at Easter…).
   Outside every range it falls back to the classic green Matrix rain. Exit
   via the ✕ button, Escape, or tapping the overlay. The rain engine
   (`matrix.js`) is a separate file lazy-loaded only on the launching tap.

= Cache-safe by design =

SpeedyCache (and HostGator's Endurance cache) serve cached HTML, so PHP never
bakes in "today's theme". The whole schedule ships to the client as a small
JSON config and the visitor's browser picks the active theme from its LOCAL
date at runtime. The markup is identical on every request. No AJAX, no
cookies, no localStorage.

= Every theme runs full =

As of 3.2.0 there are no "quiet" themes: Patriot Day and MLK Day get the same
particle counts, vignettes, parallax, pointer play, accents and working easter
egg as every other theme, in their own palettes. Use the density and opacity
sliders (or Visual richness) to tone any of it down.

= Accessibility & performance =

* `prefers-reduced-motion: reduce` → ambient layer disabled; the egg shows a
  static themed banner instead of animation (and follows live preference
  changes).
* Ambient loader is a single deferred script; the Matrix engine never loads
  unless someone finds the egg.
* Egg columns are capped at 60; both layers pause on `visibilitychange`.
* Excluded pages: the MotoPress checkout (`/submit-booking/`, detected via
  `MPHB()->settings()->pages()->getCheckoutPageId()` when MotoPress is
  active) and the Elementor editor/preview. Filterable.

= Logo tap behavior =

When the logo links to the page the visitor is already on (the usual case:
the home-page logo on the home page), the click's default reload is cancelled
so tap counting can survive five rapid taps. Logo links to *other* pages
still navigate normally — on those pages the first tap goes home, and the
egg is found there.

= Settings =

WP-Admin → Settings → DCC Seasons: master enable, ambient on/off, egg on/off,
tap target selector, tap count, ambient density/opacity sliders, and a fully
editable schedule table ({start, end, theme, label} rows, pre-seeded for
2026–27) — future years need no rebuild.

= Theme preview (admins only) =

Append `?dcc_season=<theme_key>` to any front-end URL to force that theme for
the page view — ambient runs in it and the egg uses its Matrix palette.
`?dcc_season=off` forces no theme (no ambient, classic green egg). The
capability check (`manage_options`) happens server-side and only then is the
preview flag placed in the JS config, so visitors typing the parameter get
the normal date-driven behavior. The settings page lists every valid key.

= Filters =

* `dcc_seasons_options` — the effective option array.
* `dcc_seasons_schedule` — schedule rows sent to the client.
* `dcc_seasons_themes` — every theme definition (particles, palettes, glyphs).
* `dcc_seasons_config` — the final JS config object.
* `dcc_seasons_excluded_page_ids` — page IDs that never get effects.
* `dcc_seasons_is_excluded` — final say on excluding the current request.

== Installation ==

1. WP Admin → Plugins → Add New → Upload Plugin → `dcc-seasons.zip`.
2. Activate. Defaults are live immediately (schedule pre-seeded for 2026–27).
3. Optional: adjust under Settings → DCC Seasons.

== Manual smoke-test checklist ==

* On a date inside a range: sparse particles drift; on any other date: none.
* 5 quick taps on the logo → themed rain; ✕, Escape, and overlay tap all exit.
* Outside every range: 5 taps → classic green rain.
* On 09/08–09/11 or 01/18 (adjust a row to today to simulate): corner accent
  only, egg does nothing.
* `/submit-booking/`: no script tag, no effects.
* OS reduced-motion on: no ambient; egg shows the static banner.
* No console errors, no PHP notices, no layout shift, booking flow untouched.

== Changelog ==

= 3.2.0 =
* 4/20 art fixed (the owner's direct complaint). The cannabis sprite was a
  smooth six-petal shape that read as a generic tree leaf; it is redrawn
  with the real field marks — 7 narrow lance-shaped leaflets radiating
  from one point, serrated edges, longest in the centre, smallest at the
  bottom. The grey curl-noise "wisp" particles (which read as noodles) are
  gone entirely, replaced by a drawn joint: tapered rolled cone, twisted
  paper tip, warm ember, and its own smoke curling up from the lit end.
  The peace emoji is now a drawn V-sign hand.
* No more "gentle" themes. Patriot Day and MLK Day run at full richness
  like every other theme — real particle counts, parallax, vignettes,
  pointer play, accents and a working easter egg. Patriot Day: waving flag
  cloths, red/white/blue stars, the eagle hero, a three-flag formation
  vignette, and a red/white/blue egg with star glyphs. MLK Day: doves in
  flight, olive sprigs and gold hearts on a gold/white palette, a
  dove-formation vignette, and a matching egg. The engine's `solemn`
  special-case is deleted; no theme ships `egg => false` any more. Preview
  labels are plain "Patriot Day" and "MLK Day".
* Full art audit — the ambient layer is now 100% drawn. All 24 remaining
  raw platform emoji (which rendered differently on every device and
  clashed with the drawn sprites beside them) are replaced by 18 new
  house-style sprites — snowflake, sparkle, fleur-de-lis, clover, orange,
  banana, burger, olive sprig, tree, flamingo, bat, champagne flutes,
  upside-down face, beach umbrella, recycle, fishing hook, joint, peace
  hand — plus a recolourable heart primitive and reuse of the existing
  bass, flagcloth and kayak art. Ambiguous silhouettes were re-cut after
  judging every sprite at its real 28px particle size: the pie was
  redrawn as a dish with a domed lattice crust, and the dove, swan and
  blossom (previously white-on-white and nearly invisible on a light page)
  gained outlines and shading.
* engine.min.js 62,712 bytes raw / 22,120 gzipped — within the raised
  64KB / 22KB ceiling (was 56,764 / 20,353).
* No settings, schedule, behaviour or performance-guardrail changes; all
  stored options survive untouched.

= 3.1.0 =
* New "Layering" setting (Settings → DCC Seasons, next to the layer
  toggles). "Behind interactive widgets" (the default, including for
  upgrades with no stored value) puts the ambient canvas at z-index 5 and
  raises the DCC cottage-selector and availability-calendar Elementor
  wrappers above it on a white backing — replacing the site-side
  mu-plugin rule (dcc-ui-tweaks item 3) byte-for-byte so it can be
  retired. "In front of everything" restores the pre-3.1 canvas
  z-index 99990 and outputs no widget CSS at all. The choice rides the
  existing config pipeline (a one-key `layer` flag the engine reads when
  creating its canvas); the Matrix easter-egg overlay is untouched in
  both modes and still covers everything. No other setting, theme, or
  behavior changed; existing stored options survive unchanged.

= 3.0.0 =
* The "wow" visual overhaul, designed around the Dora Canal identity.
* Bespoke illustrated sprite set (~75 inline SVGs, one consistent hand):
  species-accurate fall leaves (maple/oak/cypress/sweetgum), three
  jack-o'-lantern faces with flicker glow, turkey 2.0 leading chicks,
  glinting ornaments, state license plates (NY/OH/MI), rose petals, opening
  love letter, quill with ink trail, decorated-egg upgrades, pontoon 2.0
  with stern flag, kayak, swans, stilt walker, and more. Emoji remain only
  as tofu-checked fallbacks.
* Depth layers: FAR parallax layer (60% scale / 50% speed / 60% opacity)
  behind the NEAR layer.
* Waterline reflections: actors just above the water draw a flipped,
  squashed 25% mirror; floaters get a broken shimmer line. Off on mobile.
* Pointer awareness (observation only): particles ease away from the
  cursor and spring back; a click landing on a particle pops it without
  consuming the click.
* Vignette director — rare 5–12s choreographed scenes, one at a time,
  ≥90s apart: the pontoon flotilla, the FULL CAST fishing story (lure →
  bobber → circling shadow → bass strike), dragonfly-lands-on-the-bobber,
  witch across the moon, sleigh gift-drop (+ evening sleigh-past-moon),
  cork pop, flamingo arrival on the waterline, stilt walker, doubloon
  shower, the two swans forming a heart, berry-in-the-basket, the Easter
  egg hunt and the hatch, the banana slip, mama duck parade, the kayaker.
* THE real New Year's countdown: within the final 10 seconds of Dec 31 by
  the visitor's clock, numerals count down to a triple mega-burst with the
  year in gold.
* Evening tint (7pm–6am local): −10% brightness, +30% glow, night
  variants (fireflies on the canal, pontoon deck lights, sleigh-past-moon).
* Christmas snow accumulation: a ≤6px snow line builds along the
  waterline from settled flakes (per-session).
* Egg finale formations: ~18s into the Matrix rain the glyphs organize
  into the theme's shape (jack-o'-lantern, turkey, tree, year numerals,
  fleur-de-lis, heart, shamrock, egg, globe), hold, and dissolve.
* Heroes upgraded: 3-frame heron wingbeat with an occasional full landing
  sequence on the waterline (the classic no-theme day's signature);
  manatee mom-with-calf; upgraded rainbow moment (leprechaun hat, coin
  arcs, clover strip); the inverted heron on April Fool's only.
* Auto-degrade ladder (~8ms rolling frame budget): sheds reflections →
  far parallax → vignettes, silently. New settings: Visual richness
  (Full/Classic/Minimal) + Advanced visuals toggles (reflections,
  vignettes, pointer awareness, evening tint, snow).
* Patriot Day and MLK Day are exempt from all of it beyond sprite polish —
  quiet and dignified, nothing falls on Patriot Day, egg stays off.
* engine.min.js: 56.7KB raw / 20.3KB gzipped (budget ≤60KB / ≤20KiB).

= 2.2.0 =
* Preview tooling baked in (the "DCC Seasons Preview Links" companion
  mu-plugin can now be deleted): the settings page gets a panel of
  one-click preview buttons — one per theme plus a red-outlined "Off
  (force none)" — each opening the homepage with ?dcc_season=<key> in a
  new tab, with a note that reads the live saved tap count; and any
  front-end page loaded by an administrator with ?dcc_season= present
  shows a fixed bottom-right chip ("Previewing:" + a theme dropdown that
  swaps the param in place, preserving path and other query params, and a
  ✕ that removes it). Admin-gated inline output only — nothing is
  enqueued for visitors and non-admins get no markup at all. Themes added
  via the dcc_seasons_themes filter appear in both automatically. No
  engine, loader, schedule, or visitor-facing changes.

= 2.1.0 =
* Directional facing: particle specs can declare `face:'L'` (native art
  faces left) and the engine mirrors the glyph when travelling rightward —
  boats, fish, birds, turkey, flamingo Vs, dove, bunny and chick now face
  their direction of travel. Flags, symmetric glyphs, and canvas primitives
  are never flipped; jump-arc rotation stays correct when mirrored. The
  emoji heroes (eagle, witch) and the duckling line flip too.
* FIX: the big-bass hero never rendered (jump physics ran but there was no
  draw branch — visitors saw two unexplained ripples). It now draws a 🐟
  (🐠 fallback) at 40px, rotated along its arc and facing its travel.
* FIX: procedural Easter eggs could pick identical base/decoration colors
  and look plain; the decoration color now always contrasts, and the eggs
  are ~15% larger (sz 20–30) with a heavier spawn weight.
* New `cruise` behavior: rides AT the waterline with a gentle bob while
  steadily crossing, dropping a wake ripple every 2–4 s. Labor Day's
  speedboat is replaced by a new pontoon-boat SVG sprite that cruises the
  water (boats no longer fly mid-air); Spring on the Canal's canoe cruises
  too. Labor Day gains the waterline and plants its beach umbrellas at the
  bottom (grow) instead of raining them; Christmas trees likewise grow up
  from the bottom edge instead of falling.
* Easter Matrix rain: removed '🥚' (renders as a plain chicken egg);
  glyphs are now 🐣 🐰 ✿ with the pastel palette unchanged.

= 2.0.0 =
* FIX (critical): the tap target now accepts a comma-separated selector list
  and binds every VISIBLE match (Bravada renders #branding at 0px on this
  site). Zero-size elements are skipped; #masthead is the last resort. New
  default: `#branding, .header-image .entry-title, .entry-title, #site-title`.
* FIX: canvas sizing hardened for Chrome zoom / wide monitors — one width
  source (canvas rect × devicePixelRatio), re-applied on window.resize AND
  visualViewport resize with a particle re-seed (ambient and egg).
* Particle overhaul: THE WATERLINE (settle+ripples, floaters, jumping bass,
  submerged manatee along the bottom ~8%); 20+ motion personalities (sway,
  flutter, dangle, hang, toss, hop, waddle, dart, twinkle, chatter, grow,
  vee formations, orbit-pair, burst…); hybrid rendering (emoji + recolorable
  canvas primitives + ~19 inline SVG sprites, tofu-checked fallbacks).
* BRAND HERO: the great blue heron glides across every 2–3 minutes in every
  theme AND on no-theme days. Per-theme heroes: eagle, witch flyby, Santa
  sleigh, manatee, big bass jump, ducklings, St. Patrick's rainbow moment.
* Patriot Day rebuilt: NOTHING falls (twinkle + slow glide only), ribbon
  accent, eagle hero, egg still disabled. MLK Day: dove/olive/heart, gentle.
* New Year's fireworks now flash the auto-computed year at the burst point.
* The ambient engine is its own lazy file (engine.js) loaded after idle;
  the deferred loader stays tiny. All caps unchanged (≤16 particles
  including ripples, ≤60 egg columns, visibilitychange pause).

= 1.1.0 =
* Theme preview: `?dcc_season=<theme_key>` forces a theme for the page view
  (`off` forces none) — restricted server-side to logged-in users with
  `manage_options`. Valid keys listed on the settings page.

= 1.0.0 =
* Initial release: ambient particle layer, lazy-loaded themed Matrix egg,
  pre-seeded 2026–27 schedule, settings page, cache-safe client-side date
  logic, checkout/Elementor exclusions, reduced-motion support.
