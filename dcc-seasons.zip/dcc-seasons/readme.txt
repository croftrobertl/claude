=== DCC Seasons ===
Contributors: doracanalcourt
Tags: seasonal, particles, easter egg, matrix, canvas
Requires at least: 6.3
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 4.6.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Date-scheduled seasonal ambient particles plus a tap-the-logo Matrix-style
easter egg, built cache-safe and performance-first for doracanalcourt.com.

== Description ==

Three layers, all vanilla JS + 2D canvas (no libraries, no WebGL, no image
assets — every ambient particle is a bespoke inline-SVG sprite or a canvas
primitive drawn in code; emoji survive only as tofu fallbacks and as the
Matrix rain's deliberate glyph aesthetic):

1. **Ambient mode** — a sparse, slow, low-opacity drift of themed particles
   over the page during each scheduled date range. Capped at 16 particles,
   requestAnimationFrame-driven, paused when the tab is hidden, drawn on a
   `position:fixed`, `pointer-events:none`, `aria-hidden` canvas (zero CLS,
   never intercepts a click).
2. **Easter egg** — tapping/clicking the site logo (`#branding`, fallback
   `#site-title`) 5 times within a rolling 3-second window launches a
   full-screen Matrix-style glyph rain recolored and re-glyphed for the
   current theme (orange pumpkin rain in October, pastel egg rain at Easter…).
   Outside every range it falls back to the classic green Matrix rain. Exit
   via the ✕ button, Escape, or tapping the overlay. The rain engine
   (`matrix.js`) is a separate file lazy-loaded only on the launching tap.

= Cache-safe by design =

SpeedyCache (and HostGator's Endurance cache) serve cached HTML, so PHP never
bakes in "today's theme". The whole schedule ships to the client as a small
JSON config and the visitor's browser picks the active theme from its LOCAL
date at runtime. The markup is identical on every request. No AJAX, no
cookies, no localStorage.

= Every theme runs full =

As of 3.2.0 there are no "quiet" themes: Patriot Day and MLK Day get the same
particle counts, vignettes, parallax, pointer play, accents and working easter
egg as every other theme, in their own palettes. Use the density and opacity
sliders (or Visual richness) to tone any of it down.

= Accessibility & performance =

* `prefers-reduced-motion: reduce` → ambient layer disabled; the egg shows a
  static themed banner instead of animation (and follows live preference
  changes).
* Ambient loader is a single deferred script; the Matrix engine never loads
  unless someone finds the egg.
* Egg columns are capped at 60; both layers pause on `visibilitychange`.
* Excluded pages: the MotoPress checkout (`/submit-booking/`, detected via
  `MPHB()->settings()->pages()->getCheckoutPageId()` when MotoPress is
  active) and the Elementor editor/preview. Filterable.

= Logo tap behavior =

When the logo links to the page the visitor is already on (the usual case:
the home-page logo on the home page), the click's default reload is cancelled
so tap counting can survive five rapid taps. Logo links to *other* pages
still navigate normally — on those pages the first tap goes home, and the
egg is found there.

= Settings =

WP-Admin → DCC → Seasons: master enable, ambient on/off, egg on/off, where
effects appear, layering, tap target selector, tap count, ambient
density/opacity sliders, and the schedule.

= Schedule =

Rows are RULES that repeat every year, so the calendar never expires. Each
end of a range is either a fixed month/day or a named holiday — MLK Day,
Presidents Day, Mardi Gras, Easter, Mother's Day, Memorial Day, Father's Day,
Labor Day, Columbus Day and Thanksgiving move with the calendar
automatically — plus an optional ± days offset. Ranges may overlap: the
NARROWEST one wins that day, so a one-day holiday can sit inside a season
without splitting it. A range that ends before it starts runs into the next
year (New Year's, Dec 26 → Jan 3). A row with a year in its last column is a
one-off. The settings page shows every row resolved to real dates for this
year and next, and flags any day nothing covers.

The default covers every day of the year: Snowbird → Strawberry →
St. Patrick's → Spring on the Canal → Summer on the Canal → Fall Fishing →
Halloween → Thanksgiving → Christmas → New Year's, with the holidays as
narrower rows inside those seasons.

The rules are resolved in the VISITOR'S browser from their local date
(cache-safe — the HTML never carries "today"); the same resolver runs in PHP
for the admin table, and the two are cross-checked by the test suite.

= Where effects appear =

Four nested tiers, default "All pages and posts" (today's behaviour):

* **Homepage only** — the front page and nothing else.
* **All pages except cottage pages** — every WordPress page, but not the
  MotoPress accommodation singles, so the booking screens stay calm.
* **All pages** — pages including cottage pages.
* **All pages and posts** — everything: posts, other post types, archives,
  categories, search and 404 as well.

Cottage pages are matched by MotoPress POST TYPE (`mphb_room_type`), never by
URL or slug — the live slugs don't correspond to cottage numbers
(`/accommodation/cottage-34/` serves room type 1607).

A page outside the scope loads none of the plugin: no script, no inline
config, no inline layering CSS. The scope decision is made server-side, which
is cache-safe because it depends only on which URL is being rendered, not on
the date — the season schedule still ships to the client and is still picked
from the visitor's local clock. Saving the settings purges the page cache so
already-cached URLs pick up the change; if no cache plugin can be purged
automatically, the settings page says so and asks you to purge by hand.

Scope covers the ambient particles AND the tap easter egg together, so with
"Homepage only" the egg does not fire on interior pages. Admin theme previews
(`?dcc_season=`) ignore the scope entirely, so you can always preview
anywhere.

= Theme preview (admins only) =

Append `?dcc_season=<theme_key>` to any front-end URL to force that theme for
the page view — ambient runs in it and the egg uses its Matrix palette.
`?dcc_season=off` forces no theme (no ambient, classic green egg). The
capability check (`manage_options`) happens server-side and only then is the
preview flag placed in the JS config, so visitors typing the parameter get
the normal date-driven behavior. The settings page lists every valid key.

= Filters =

* `dcc_seasons_options` — the effective option array.
* `dcc_seasons_schedule` — schedule rows sent to the client.
* `dcc_seasons_themes` — every theme definition (particles, palettes, glyphs).
* `dcc_seasons_config` — the final JS config object.
* `dcc_seasons_excluded_page_ids` — page IDs that never get effects.
* `dcc_seasons_is_excluded` — final say on excluding the current request.
* `dcc_seasons_in_scope` — final say on the "Where effects appear" gate
  (applied after the exclusions, so it can't re-enable the checkout).
* `dcc_seasons_cottage_post_types` — post types treated as cottage pages.
* `dcc_seasons_layering_selectors` — widgets raised above the canvas.
* `dcc_seasons_backdrop_host` — CSS selector for the element the canvas is
  mounted inside in "behind" mode (empty = auto-detect).
* `dcc_seasons_purged_cache` (action) — fires after a settings save purge.

== Installation ==

1. WP Admin → Plugins → Add New → Upload Plugin → `dcc-seasons.zip`.
2. Activate. Defaults are live immediately (schedule pre-seeded for 2026–27).
3. Optional: adjust under DCC → Seasons.

== Manual smoke-test checklist ==

* On a date inside a range: sparse particles drift; on any other date: none.
* N quick taps on the logo (N = the Tap count setting) → themed rain; ✕, Escape, and overlay tap all exit.
* Outside every range: N taps → classic green rain.
* On 09/08–09/11 or 01/18 (adjust a row to today to simulate): Patriot Day
  and MLK Day run full, egg included.
* `/submit-booking/`: no script tag, no effects.
* OS reduced-motion on: no ambient; egg shows the static banner.
* No console errors, no PHP notices, no layout shift, booking flow untouched.

== Changelog ==

= 4.6.0 =
Lighter, looking exactly the same (Rob, 2026-10-06). Rollback: reinstall
the 4.5.0 zip. Nothing stored is rewritten.

* Nothing is drawn while the effects canvas is off screen (a footer or
  sticky canvas scrolled away) or the tab is hidden; it resumes where it
  left off.
* While the background layer is all that moves, it repaints 30 times a
  second instead of 60 (every effect was measured moving at most 1.5
  pixels between repaints, so it looks the same) and only the small areas
  its particles cover are cleared. Heroes, scenes, sprites, fireworks and
  ripples keep the full rate.
* With nothing to draw at all, nothing is drawn: no canvas clears, just a
  quiet four-times-a-second check for the next hero or scene.
* Reduced-motion settings are respected as before.
* Decided by Rob after a side-by-side on his phone (2026-10-06): the
  background stays at 30 repaints a second. The 20-a-second option (lighter
  still, but particles step up to 2.3 pixels) was declined; do not
  re-propose it.

= 4.5.0 =
Rob's decisions of 2026-10-06. Rollback: reinstall the 4.4.0 zip. Nothing
stored is rewritten.

* "Ambient particles" is now "Falling and drifting sprites" and switches
  only those (boats and birds included). Until now it gated the whole
  effects engine, so with it off guests saw nothing but the logo egg,
  even with the background layer switched on. The engine now loads
  whenever any of its layers is on, and each layer follows its own
  setting: background layer → "Subtle layer"; corner accents → Visual
  richness "Full"; scenes → richness "Full" plus "Scene moments"; heroes
  → any richness but "Minimal". No new settings.
* The Theme guide's notice and "Switched off in Settings" tags follow the
  same mapping.
* The "Preview a theme" button panel at the top of the Seasons settings
  page is gone (both tabs): every theme row and guide card has its own
  preview link. The front-end preview chip is unchanged.

= 4.4.0 =
Two WP-Admin changes from Rob (2026-10-06). Nothing guests see changes.
Rollback: reinstall the 4.3.0 zip. Nothing stored is rewritten.

* Theme preview links are full links that open in a new tab — the preview
  table, the "off" row and the two examples above it
  (e.g. https://doracanalcourt.com/?dcc_season=snowbird). Administrators
  only, as before.
* New "Theme guide" tab: a card per theme in the order the year plays
  them (unscheduled themes last), with its dates this year, its preview
  link, and everything a guest can see in it — the drawings the engine
  actually uses and their names, sprite counts at 1280px and on a 390px
  phone, the background layer, corner accent, scenes and heroes with their
  timing, special behaviour (Earth Day's turns, New Year's countdown) and
  the logo-egg palette. Layers switched off in Settings are tagged. Built
  from the plugin itself on every load, so it cannot drift from what
  plays; its files load on that tab only.

= 4.3.0 =
Three changes, each Rob's pick from rendered options (2026-10-01).
Rollback: reinstall the 4.2.0 zip. Nothing stored is rewritten.

* Florida Keys and Summer on the Canal no longer tumble the sun in
  sunglasses: it read as a second sun next to the corner sun. Nothing
  replaces it. (Snowbird keeps it as its corner accent.)
* Earth Day: the hands holding the Earth and the globe now take turns,
  45 seconds each on every page — hands first, then one globe that fades
  in low and drifts up, then the hands again. Never both at once.
* The last three scenes built from emoji are drawings now: the Halloween
  witch crossing the moon is the silhouette witch with her cat (the same
  one as the hero); Snowbird's flamingos flap down with a two-frame
  wingbeat and stand as Snowbird's own flamingo; Spring's duck parade is a
  mottled duck hen and four ducklings, facing the way they swim. Same
  timing, same place in the rotation, same phone rules.

= 4.2.0 =
One release, every choice in it Rob's, picked from rendered options.
Rollback: reinstall the 4.1.3 zip. Nothing stored is rewritten — not the
schedule, not the settings — so rolling back restores 4.1.3 exactly.

No snow anywhere ("it doesn't snow in Florida"):
* Christmas — the snowflake sprite and the snow piling are gone; bokeh
  stays; a Florida sabal palm strung with lights (lit string by string)
  fills the share. Cap 9, so ornaments, holly, gifts and pines keep their
  old counts; on a phone never fewer than 5 (4 while a scene runs).
  Ornaments and holly hang on longer threads, down through the page instead
  of bunched in the header. The sleigh's gift lands on the water line, with
  a ripple. The Matrix egg carries H and O instead of ❄ ("HO HO HO").
* New subtle-layer choices, each its own named entry: Winter sun glow
  (Snowbird), Gold & white light (MLK), Mardi Gras confetti, Orange blossom
  (Presidents Day). The Snow choice and the snow-accumulation checkbox are
  gone. A stored "snow" choice (or snow checkbox) is ignored on read: that
  theme gets its new default. Nothing stored is rewritten.

Counts that look right:
* Phones get fewer sprites, on the subtle layer's own curve: 7 at 390px
  (6 on a water theme), the full 16 from 1280px. A theme's cap scales the
  same way, never below 3. Recomputed on rotation. The density setting is
  untouched.
* Caps: Patriot Day ~5 in all, Memorial Day ~7, St. Patrick's ~6 (about
  five clovers). Per sprite: MLK doves ~3, Labor Day burgers and pontoons
  ~1 each (and its leftover red/white/blue stars are gone), Valentine's
  pulsing hearts ~3, Earth Day's globe never alongside the hands accent
  (which already holds an Earth).
* Sprites now pick against their share, so a page shows the mix Rob set
  rather than a lucky or unlucky draw (one could get five ornaments and no
  gifts before).
* On a phone a scene borrows at most one sprite, so no scene empties the
  screen.
* The same thing twice, removed: the sprite version goes where the subtle
  layer already does it — Valentine's orbiting hearts; New Year's confetti;
  Fall Fishing and Thanksgiving leaves; Summer on the Canal and Florida Keys
  dragonflies; the petal sprite on Mother's Day and Spring on the Canal;
  Strawberry's drifting blossom (the bloom-to-berry one stays). July 4 is
  unchanged.

Heroes:
* Every hero is a drawing now — device emoji looked different on iPhone,
  Android and Windows. The eagle (two-frame wingbeat) flies on July 4 and
  Patriot Day only; Memorial Day and Veterans Day have the heron. The witch
  is a silhouette with her cat on the broom tail. The jumping bass is a
  largemouth drawn mid-leap. The one exception, by Rob's choice: the St.
  Patrick's rainbow keeps its ☘ clover strip. The unused "ducks" hero is gone.
* The first hero of a visit crosses 3-5s in — after the home page's
  seaplane and fishing catch (it waits for dcc-hero-life's DCCHeroFx to say
  done, then 2s; never longer than 70s). Later pages keep 120-180s.
* A scene never starts while a hero crosses, and no hero while a scene runs.

Themes:
* 4/20 — the picnic basket goes; a hippie van (no badge) drives up and parks.
* Summer on the Canal — three new scenes: a gator glides by and sinks; an
  inflatable flamingo pool float drifts past with a lost flip-flop; a
  mullet skips three times and another answers.
* Florida Keys — keeps its sun, palms, hibiscus and colours, with Central
  Florida wildlife instead of sea life: the osprey carrying a fish is the
  hero (the brown pelican retires), an aluminium jon boat replaces the
  flats skiff, a white ibis replaces the flamingo (Snowbird keeps its
  flamingos), and the sun is a corner accent, never a sprite. Five scenes:
  an anhinga dries its wings on a snag, an osprey catches a fish, a
  sandhill crane pair dances, a limpkin pulls an apple snail, a hibiscus
  bloom drops and floats.

Calendar (in the resolver, so the stored schedule gets it untouched; the
PHP and browser resolvers agree on every day of 2027-2036):
* A holiday always shows on its own day — Fat Tuesday is Mardi Gras, 14 Feb
  Valentine's. On 1 Apr 2029 Easter wins; April Fool's skips that year.
* Overlapping lead-up days go to the nearer holiday (an exact tie, to the
  one still to come): Mardi Gras takes 10-12 Feb 2029, and St. Patrick's
  runs 2-17 March 2035 in one piece.
* A long theme is never left one lone day — it goes to the theme that starts
  next, except that a one-day holiday (MLK, Presidents, April Fool's, 4/20)
  is never lengthened.

Cost: the effects engine grows from 106KB to 124KB (36KB to 42KB gzipped)
for the 22 new drawings and 8 scenes. It still loads only after the page has
finished loading, so it never delays the page itself.

Corrections: the 4.1.3 "needs a decision" note below was wrong and is marked
withdrawn; the schedule code no longer claims Summer on the Canal "must stay
absent" on this site.

= 4.1.3 =
A self-audit release: three defects in 4.0.0-4.1.2 work, found by re-reading
the code rather than the release notes, plus one finding that needs the
owner's decision.

* FIXED — the per-theme subtle-effect map was supposed to store OVERRIDES
  ONLY, so an untouched theme keeps tracking the plugin's default. It did
  not: the settings form posts a value for all 27 themes on every save, and
  the sanitiser kept every valid one, so a single Save turned the stored
  map into a full copy pinned to that day's defaults. A value equal to the
  plugin's own is now not stored. Saving the form unchanged stores nothing.
* FIXED — the subtle-layer intensity slider at 0 still drew three particles
  at over half strength, because the alpha curve has a deliberate floor and
  the particle count is floored at 3. Zero now means off.
* FIXED (test) — the "engine pauses on a hidden tab" assertion read a flag
  the debug state never exposed, got undefined, and passed unconditionally.
  The flag is exposed and the test now asserts the real boolean in both
  directions.
* WITHDRAWN (corrected in 4.2.0) — this entry said the 4.0.0 calendar
  change had never been active on the live site and that Florida Keys
  "still wins zero days there", from a note that the site had "all 26 rows".
  That was an inference, and it was wrong: the live site held 25 rows with
  no Summer on the Canal row, so Florida Keys won 87 days of 2026 there,
  not zero. The owner resolved it site-side on 2026-09-26 by resetting the
  schedule to the defaults (backup: dcc_seasons_options_bak_20260926), and
  confirmed Summer on the Canal for June-July on 2026-09-27. Live now
  resolves exactly as the defaults do (in 2027: Florida Keys 59 days,
  Summer on the Canal 53). The general caveat stands — the upgrade path
  never rewrites a stored row's bounds — but there was no decision to make
  here.
* Docs: nine references to test suites that lived in a session scratchpad
  and did not survive are corrected; the Florida Keys entry now states the
  stored-schedule caveat above.

= 4.1.2 =
* NEW — "Excluded page IDs", a free-text field beside the booking and Guest
  Guide toggles. Ships with 18119 pre-filled: /explore/, the Wildlife hub,
  where a live mobile audit found the fishing line drawn through the species
  deck with bobbers parked on tile names. Taps passed through, but it read
  as a glitch on a field guide. An ID is used rather than a slug because an
  ID survives the page being renamed; the field takes more IDs without a
  release. Deliberately NOT coupled to the Wildlife plugin — this plugin
  should not know that plugin exists, and the page would still want
  excluding if the hub were rebuilt by hand.
* The plugin no longer creates the shared "DCC" admin parent menu, and no
  longer removes WordPress's mirrored duplicate. The site-side mu-plugin
  dcc-menu.php owns both outright. Every DCC plugin used to create the
  parent "only if it isn't there yet", which meant its label, icon and
  position came from whichever plugin loaded first. One owner, one
  definition. This plugin still registers its own submenu at priority 40,
  and Menu::init() is kept as a no-op so a sibling still calling it does not
  fatal. The live priority register moves to dcc-menu.php's header; the copy
  here is a mirror.
* NOT DONE, with numbers: moving the themes table out of the inline config.
  Measured, the whole config payload is 14,039 bytes raw / 2,997 gzipped.
  Moving the ambient half into the engine saves 1,494 bytes gzipped; moving
  the egg half into the Matrix bundle as well takes the total to 2,286. That
  is the entire available win, and the cost is a second hand-maintained copy
  of the theme definitions in a file where a desync draws nothing and
  reports nothing — a failure this plugin has already had three times over
  smaller mirrors. The table also cannot simply be trimmed to today's theme:
  the schedule is resolved from the VISITOR'S clock precisely so cached HTML
  stays date-agnostic, so the server does not know which theme is live.

= 4.1.1 =
* The contact sheet's "not referenced" label was WRONG for four sprites,
  and the sprites were fine. heron0, heron1, heron2 and letter1 are all
  drawn: the heron frames live in an array that is indexed at draw time,
  and letter1 is chosen by a ternary on the particle's height, so a tool
  matching only literal sprite('name') calls could not see either. The
  labeller now counts any quoted occurrence of a known key anywhere in the
  engine, which is the same rule the path validator already used. 105 of
  105 sprites now show an attribution; none say "not referenced".
  Proved rather than asserted: a forced heron flyover cycles heron0, heron1
  and heron2, with heron1 appearing about twice as often as the other two —
  which is what the [0,1,2,1] wingbeat requires — and puts ink on the
  canvas. This is the year-round heron, the most on-brand thing the plugin
  draws, and it has been working all along.
* The path validator now reports UNREFERENCED sprites as well as dangling
  references. It warns rather than failing, deliberately: "does this sprite
  exist" is exactly decidable, but "can anything reach this sprite" is a
  heuristic over quoted occurrences, and a stricter version of it produced
  four false positives this round that nearly deleted a working animation.
  Pass --strict to turn it into a build failure for a deliberate cull.
* 'conch' is removed at the owner's call — two redraws in, it never
  resolved into a readable shell at scene scale. Florida Keys is not left a
  sprite thinner: a flamingo takes its place, the most on-brand Florida bird
  after the heron. Snowbird flies it in formation; here it crosses alone,
  and the two themes are months apart, so the shared art cannot read as
  repetition.
* christmas keeps the warm bokeh subtle effect rather than snow. It does
  not snow in Central Florida; the dropdown is there if that judgement ever
  changes.
* Build: engine.min.js is 105,948 raw / 36,385 gzipped (4.1.0: 106,593 /
  36,558). Sprite count 106 -> 105.

= 4.1.0 =
* FIXED, HIGHEST PRIORITY — the "All pages except cottage pages" scope
  silently included the entire booking and payment flow: Checkout, Payment
  Request, Submit Booking, Cottage Cart and all five booking confirmation
  pages, plus the internal staff board. Only the checkout page itself had
  ever been excluded. The booking flow is now excluded in EVERY scope tier,
  "All pages and posts" included, and it is a visible setting rather than a
  filter. MotoPress's own context predicates are asked first, with page IDs
  and slugs as fallbacks, because IDs change and a stale ID fails silently
  in the worst direction — effects return to the payment form and nothing
  reports it.
* The Guest Guide is excluded by default, with its own toggle so it can be
  turned back on without code, and a free-text list of extra paths never to
  decorate (defaults to "staff").
* FIXED — the ambient canvas claimed z-index 99990 in "In front of
  everything" mode, which outranked the site's severe-weather banner: the
  decorations drew over live NWS tornado, hurricane and flood warnings. It
  now mounts at 9000, above ordinary content and Elementor sections and
  deliberately below lightboxes, the banner and any consent UI. The band is
  documented in the code, settable, and clamped so it can never be raised
  above the alert layer.
* FIXED — four vignettes were named by themes but did not exist. MLK Day
  and Patriot Day therefore never played a vignette at all, and Mardi Gras
  and Spring on the Canal silently lost a third to a half of theirs. Worse,
  the retry clock only moves on a SUCCESSFUL vignette, so a name with
  nothing behind it was retried on every frame for the life of the page.
  All four scenes are now implemented — doves crossing for MLK, a single
  slow flag for Patriot Day, a kayaker on the canal, and a Mardi Gras stilt
  walker — and the build now fails on a vignette name with no scene behind
  it, exactly as it already did for sprites.
* FIXED — the stored options row now gains a release's new default keys on
  upgrade instead of waiting for someone to open the settings page and
  save. Nothing was broken by this (defaults are merged on every read) but
  the database did not describe the site's actual behaviour. It only adds:
  a value the owner set is never touched.
* Sprites — hands, bunnycarry, stilts, lure, peel and conch redrawn. The
  contact sheet now renders every sprite on BOTH a light and a dark ground,
  because the effects run over a hero photograph, white body copy and the
  navy footer, and labels which themes each sprite belongs to so a theme's
  set can be judged as a set.
* "(recommended)" is off the footer placement label. That recommendation
  produced the reported bug — footer placement confines the effects to a
  small box — and the trade is now explained in help text beside the
  Layering control it interacts with.
* Measured at the live settings (content placement, front layering, density
  16): engine work is 0.50ms per frame at 1280x900 and 0.35ms at 390x844,
  the canvas pauses on a hidden tab, and there is no horizontal overflow or
  text interception at phone width.
* Build: engine.min.js is 106,593 raw / 36,558 gzipped (4.0.0: 105,079 /
  36,124).
* NOT CHANGED, because the premise did not hold: subtle_map shipping as an
  empty array is not a half-delivered feature. It is the OVERRIDES store —
  the effective map merges the plugin's own defaults underneath it, and the
  client receives the merged result. All 27 themes resolve, including the
  five bespoke exceptions, even on a row missing the key entirely.

= 4.0.0 =
BREAKING: the layer model changed and several themes' sprite sets changed.

* NEW — Layer 1, the subtle layer. A quiet seasonal effect that always runs
  underneath the sprites: leaves in fall, snow in winter, blossom in spring,
  and dragonflies over a faint heat shimmer in summer, with five bespoke
  days — hearts at Valentine's, confetti at New Year's, embers at Halloween,
  sparks on Independence Day and warm bokeh at Christmas. It is drawn on the
  existing canvas rather than a second one, so it inherits the placement and
  layering decisions the backdrop already makes. Deliberately faint:
  measured with the sprites suppressed it lights 0.02-0.69% of the canvas at
  a mean alpha of 8-36 out of 255. On/off, intensity and the per-theme
  effect are all settings.
* FIXED — the ambient backdrop was being hidden by page content. Coverage
  was only ever measured at mount and at the settled pass, both of which run
  at the scroll offset the page loads at. At scroll 0 the only thing inside
  the canvas box is the host's own background, so reach measured 100% and
  the corrective loop concluded there was nothing to fix — while everything
  that actually covers the backdrop was below the fold. Measured on an
  Elementor page, reach fell to 38% by the time the visitor had scrolled to
  read. Coverage is now re-checked when scrolling settles. After: 88% at
  every offset measured.
  Note for anyone chasing this again: the covering sections' stacking
  contexts are NOT the cause. A descendant of the host paints above a
  z-index:-1 child whether or not it establishes a context. Transform,
  filter and opacity on those sections change nothing.
* FIXED — florida_keys, named as the year-round base theme, displayed on
  zero days. The season rows tiled the year and the narrowest containing
  range wins, so the widest possible row lost every day. Spring on the Canal
  now ends 30 April and Summer on the Canal 31 July, which gives the base
  May and August: 49-59 days a year measured across 2024-2035, with no day
  left uncovered and not one day taken from a holiday window.
* FIXED — the engine's DEBUG flag read a config key the plugin has never
  emitted, so it was permanently false on every real page. The ?dcc_debug=1
  panel still worked, which is why this went unnoticed, but the programmatic
  state accessors and the date-mocking test hooks did not exist.
* Sprites — the three heron flight frames and both pelicans were redrawn
  against reference; they had no readable neck, legs or pouch. The oak leaf
  was redrawn (it read as a peanut) and so was the banana peel.
* Sprites — the patriotic themes have distinct identities. flagcloth
  appeared in five themes and all five also shared one red/white/blue star.
  Independence Day keeps flags and sparklers as the celebratory one; Patriot
  Day is the flag and a few quiet stars; Memorial Day is poppies and doves
  with a pale star; Veterans Day leads with medals and the remembrance
  ribbon. flagcloth is now in two themes.
* The 'ribbon' sprite renders for the first time. It had been wired to a
  theme-level 'accent' key the engine has never read.
* Build: engine.min.js is 105,079 bytes raw / 36,124 gzipped, up from
  97,900 / 34,373 at 3.18.0 — the cost of Layer 1.
* NOT done, deliberately: 'classic' is not retired. It is the intentional
  "None" option in the schedule table, the egg's fallback palette, and is
  excluded from the unscheduled-themes warning by name. Retiring it would
  break all three.

= 3.18.1 =
* From a script audit: "ambient.min.js and engine.min.js load on the homepage
  on 12 September, when no season is active." Measured, and mostly the other
  way round. A season IS active on 12 September — Fall Fishing on the shipped
  defaults — and there are ZERO days in 2026 with no active row: the season
  rows tile the year and florida_keys sits under them as the year-round base.
  Gating the enqueue on "a schedule row is live" would never fire. It also
  could not be done server-side: the row is resolved from the VISITOR'S local
  date so that page caching can never serve a stale season.
* What the homepage actually loads, measured with the network timeline: ONE
  script is enqueued, ambient.min.js at 4,392 bytes, in the footer with
  defer. The 96KB engine is not enqueued at all — the loader fetches it on
  requestIdleCallback, measured at +215ms AFTER the load event, so it never
  competes for the critical path. Under prefers-reduced-motion, or with the
  ambient layer switched off, the engine is never fetched and the page pays
  4,392 bytes in total.
* FIXED, and the one real waste the audit's instinct was right about: under
  footer placement on a page with NO footer, the engine was fetched in full
  and rendered nothing — 97,900 bytes for no effect. The loader now looks for
  the footer before fetching, so such a page pays 4KB instead of 100KB. The
  selector is emitted once by PHP (config footerSel, still overridable with
  the dcc_seasons_footer_host filter) and read by both the loader and the
  engine, so the two cannot disagree about what a footer is.
* That optimisation does NOT apply when an administrator has asked for
  ?dcc_debug=1: the diagnostics panel is drawn by the engine, and skipping the
  fetch would have left the panel silent in exactly the state it exists to
  explain. Visitors save the bytes; whoever is debugging still gets the
  explanation.

= 3.18.0 =
* "It basically only appears over my About Us text, which blocks exactly the
  type of stuff that I want guests to be able to read easily." The seasonal
  decorations now live in the SITE FOOTER and nowhere else. Placement is a
  setting — Settings > DCC Seasons > Placement — with "Site footer only" as
  the default, so the next change to this is a choice rather than a release.
* The canvas is mounted inside the footer element and absolutely positioned to
  its padding box, which takes no flow space: the footer and the document are
  the same height with the decorations and without them, measured. Nothing
  renders outside that box on any page — verified on a homepage, a listing
  page and a cottage page.
* Nothing is drawn over footer text either. Every frame is clipped to the
  footer box MINUS the rects of the words in it, measured with Range rects
  over the text nodes rather than the elements' block boxes — a footer link's
  block box is the width of its column, the range rect is the width of the
  word. Images and inline SVG are protected the same way. The test does not
  trust the clip: it reads the canvas's own pixels inside each text rect on
  every frame — 1,820 rect-samples over 140 frames, zero pixels on a word,
  with the canvas confirmed painting in all 140.
* Placement is a different question from "Where effects appear", which decides
  which PAGES load the plugin at all; the two settings stay independent. An
  option array saved before this release reads back as footer without
  disturbing the schedule or any other setting. If a theme has no footer,
  nothing renders rather than falling back into the page content, and the
  console and ?dcc_debug=1 both say so — name the element with the
  dcc_seasons_footer_host filter.
* Verified rather than assumed: aria-hidden="true", pointer-events:none (a tap
  in the footer lands on the footer, never the canvas), nothing at all under
  prefers-reduced-motion, no CSS transition or animation on the canvas, and no
  horizontal scrolling at 375px. Corner accents are page-corner decoration by
  definition and are not rendered under footer placement.
* The season schedule, the ?dcc_season= share previews and the tap-the-logo
  Matrix easter egg are unaffected and still pass their suites.
* engine.min.js is 97,933 raw / 34,373 gzipped.

= 3.17.0 =
* The Schedule is now ONE ROW PER CARD at 782px and below. The repaired table
  still scrolled sideways inside its own box on a phone — 573px of content in
  a 374px window, better than the 967px before 3.16.1 but still a drag to
  reach Theme and Label. Each row is now a card with its six fields stacked
  and labelled, and nothing scrolls sideways at either the page or the card:
  measured at 374px, document 374, card 334, no row overflowing.
* The desktop table Rob approved is untouched. Every cell carries its column
  heading in a data-dcc-label attribute, which nothing reads above the
  breakpoint — the label only becomes visible when the rows turn into cards.
  Proved by pixel diff: the 1280px screenshot of the six-row Schedule is
  identical before and after, 0 differing pixels of 2224x1436. The breakpoint
  itself is exact — 783px still renders the table, 782px the cards.
* Same six fields, same names, same values: the 66 name= attributes in the
  table diff clean against 3.16.1, so no saved schedule data is touched.
* Inside a card, Starts and Ends stay the two grouped objects they are on the
  desktop, offsets glued to their unit ("Easter Sunday" over "-10 days"),
  Theme / Label / Year each labelled, and the x sits alone under a rule at the
  card's foot rather than beside the Year field. Every visible control is at
  least 44x44 (72 of them, measured), text is 16px so iOS does not zoom the
  page on focus, and focus draws a visible outline. "Add row" is the last
  thing on the list, full width, 334x44.
* Worth noting for the desktop: at phone width the holiday names are NOT
  truncated — "Memorial Day (last Mon May)" and "Thanksgiving (4th Thu Nov)"
  both render in full in a card, where the desktop table clips them at about
  150px. The card layout gives those names room that six columns cannot.

= 3.16.1 =
* The Schedule table was "confusing and hard to visually read — the sections
  look like they're all part of each other without borders or separation".
  Layout only: every control, field name and value is byte-identical, and no
  saved schedule data is touched.
* Rows now have a real boundary. They were separated by the zebra stripe and
  wp-admin's #f0f0f1 hairline alone, which stops reading as a boundary once a
  row is two lines tall and there are six of them.
* Each end of a range is one field group with a card edge, so "Starts" and
  "Ends" read as two objects rather than four loose controls. The offset is
  glued to its unit — "Easter Sunday  -10 days" on one line — where before the
  word "days" could wrap below the box it labelled, which is what made a row
  look like two unrelated half-rows. Month and day are paired the same way and
  can no longer split across lines.
* The Theme <select> used to set its column's width from its longest option
  ("Florida Keys (year-round base)") and starved Label to about sixty pixels —
  "Snov", "Mem". The table is now fixed-layout with explicit column widths, so
  Label and Year are readable and the Year field shows all four digits.
* The × is an outlined destructive button in its own ruled-off column, no
  longer sharing an edge with the Year field.
* Measured at 1280px with six rows: the page does not scroll sideways, and the
  table fits the admin column at 1080px. At phone width the table still scrolls
  inside its own box, as before — and less far than it did (573px of content
  against 967px).

= 3.16.0 =
* FIXED: "the floating items only show above the top part of the About Us
  section — it begins after the hero image and stops above the text row." They
  did, and no amount of placement work could have helped, because the canvas
  was only that tall. Measured off the screen recording (patriot-red and navy
  sprite pixels, DPR 3): a band roughly 300 CSS px tall, anchored to the page
  rather than the viewport, in a ~660px screen.
* The cause was the descend step of the backdrop self-check. When something
  inside the host paints over the canvas, the engine moves the canvas INTO
  that element — and it never asked whether the new host was big enough to be
  worth having. Reproduced with the shipped 3.15.0 engine on a fixture in the
  live shape: an opaque 300px section inside the transformed article wins the
  descend, the canvas is refitted to 300px, and after scrolling 1,200px it
  covers 0 of 660 screen pixels. There are no sprites below that section at
  any scroll position. The panel called it "behind is working", because reach
  measures the fraction of the CANVAS nothing paints over — a 1px canvas
  scores 100%.
* A host is now judged by the page area the canvas can actually paint in it:
  its own height (a sticky canvas slides through its host) times the reach it
  would end up with. Two descends are refused: into a host SHORTER THAN THE
  SCREEN, which can never fill one whatever its reach, and into a host that
  gives up more than 40% of the paintable page. Staying is costed honestly —
  if the covering element's background can be moved onto the canvas, staying
  is worth full reach over the whole host, not today's reach. 3.10.0's
  ordinary descend into the opaque article is neither case and is unchanged;
  the mount suite holds that line. On the same fixture the canvas now stays on
  the article and covers 660 of 660 screen pixels at every section height
  tested (120px through 2,400px), and a tall section whose background CANNOT
  be moved still wins the descend.
* ?dcc_debug=1 gained SCREEN REACH — how much of the viewport is canvas, and
  the word LETTERBOX when it is under half — and the console says so once at
  the settled pass. The old CANVAS REACH line stays: both are true at once,
  and only having the first is what let this run for three releases.
* engine.min.js is 95,220 raw / 33,372 gzipped (3.15.0 was 93,845 / 32,920).

= 3.15.0 =
* FIXED: "sprites only show up in the area underneath the hero image and above
  the DCC Cottage Selector widget." They were being seeded evenly over the
  CANVAS, and on a phone the canvas is mostly page that paints over it. The
  occlusion map of the live article at 375px: from the article top (456) to
  the selector (1,685) is 99-100% open — the band that was working — and below
  it, eight full-bleed room cards and 270 painted calendar cells leave 300px
  bands that are 14/69/17/39/51/8/48/32/26/51/11/48 percent open. 57% of the
  column is open by area and almost none of it can hold a whole sprite.
* Seeding now asks the page where a sprite can be seen. The same hit test the
  mount already uses (what paints here, and is it inside the host and
  therefore above the canvas?) runs over a coarse grid of the canvas's
  on-screen box — 48px cells, 136 of them on a 375x812 phone — and the
  guardrail draws its candidates from the open cells only. Its even-share rule
  is computed over the OPEN cells too: a third of a canvas that is 15% visible
  is not a third of what anyone can see, which is why the old rule still
  looked random below the fold. Crossers entering from an edge pick their band
  from open rows on that side. On a fixture built to the band profile above,
  respawns landing where a sprite can be seen went from 35.7% (3.14.0, which
  is simply the open fraction of the page) to 86.3%. On the florida_keys theme
  the live site runs, 54.9% of on-screen sprite-seconds are now spent on open
  page.
* The map is rebuilt on scroll-settle, on a real resize, after the settled
  mount pass and after a re-mount — never per frame, and never more than once
  every 400ms. Measured at 1.2-1.8ms a build. If under 10% of the sampled page
  is open it is ignored and seeding falls back to even coverage, so a fully
  painted page still gets its full field rather than ten sprites in one
  gutter. Cells below the fold are unknown, not covered: they stay in the
  candidate pool but are left out of the open fraction.
* FIXED: "clumping isn't as bad but still needs to be better." The 3.14.0
  guardrail was seed-only, so free-air motion re-bunched the field within a
  minute. Free-air sprites now push each other apart with a soft force that
  fades to nothing at the spacing target — no teleports, no jitter, clamped so
  a nudge can never push a sprite over an edge and restart it, and never
  applied to anything placed on purpose (water-line riders, growers,
  off-screen entrances, the hero). At most 16 particles is at most 120 pairs:
  0.002-0.011ms a frame. At density 10 a field's closest pair after 10 seconds
  of running went from 49px to 76px; over 200 seedings the worst ninth held 2
  of 10 and no field ever held 4 in one.
* At density 12 or below the seeding pass looks harder (16 candidate throws
  instead of 8) and asks for more room (0.6 of the lattice pitch instead of
  0.45). Both numbers, and the map, are printed by ?dcc_debug=1.
* Retired four sprites that were not good enough: the cork (it read as a
  mushroom — it was renamed `popper` in 3.2.0), both whoopee-cushion frames,
  and the legless frog. The April Fools' chatterer is now the disguise, the
  Spring Canal pad-hopper is now a dragonfly (which is what that behaviour
  actually looks like), and the New Year's cork is the same theme's sparkle on
  the same arc. tools/validate-paths.js now also resolves every sprite
  reference — the plain form, the array form, the $variable form, computed
  'prefix' + n keys and theme heroes — and fails the build on a dangling one:
  106 sprites, 98 references, 0 dangling, 0 unreferenced.
* engine.min.js is 93,845 raw / 32,920 gzipped. Retiring the four sprites paid
  for roughly three quarters of the new code; the net is +855 raw / +797
  gzipped over 3.14.0. Note that the 66KB/23KB ceiling quoted for this release
  has not been the real one since 3.6.0 — the shipped engine passed it with
  the backdrop machinery and has been over it for eight releases (3.14.0 was
  92,990 / 32,123).

= 3.14.0 =
* FIXED: "too many in the same area versus more evenly distributed throughout
  the page/viewport." A particle used to take a uniform random position, which
  is free to pile up. Measured against the shipped 3.13.0 engine over 200
  fields of 16 particles on a 390x844 phone: six or more of them landed in the
  SAME ninth of the canvas in 27 fields, as many as eight at once, and the
  closest pair in a field averaged 23px apart.
* Placement now throws up to eight candidate positions and takes the first
  that lands in a ninth still under its even share AND no closer than the
  spacing target to a live particle; if none qualifies, the best candidate
  seen. Same 200 fields on the same phone: worst ninth 3 of 16, never a
  bunched field, closest pair averaging 47px. Respawns that enter from
  off-screen are spread across the width the same way (worst column 11 of 16
  before, 7 after).
* The rule runs at SEED time only, never per frame, so it cannot fight the
  motion and 3.13.0's rescale-on-resize is untouched (re-verified: a same-size
  resize still moves nothing, a real one still rescales to 0.01px). Sprites
  that are placed on purpose keep their staging exactly — water-line riders
  still sit on the water line, growers still start below the fold, off-screen
  entrances and the hero flyover are not routed through it at all.
* Cost, measured in the browser: 0.004ms per seed, the same as before within
  noise. Seeding is rare; nothing was added to the frame loop.

= 3.13.0 =
* FIXED: "the sprites reset whenever I tap or scroll." They did, on every
  gesture, and it was applySize(). It ran unconditionally and always re-seeded
  every particle, dropped every ripple, and killed any hero flyover or
  vignette in flight — so on a phone those set-pieces could almost never
  finish. On iOS the URL bar collapsing IS a visualViewport resize, so nearly
  every swipe fired it. Measured on the live site at 375x812 with the canvas
  box UNCHANGED: one dispatched resize, one canvas rewrite, 607 lit samples to
  zero.
  Three parts, because the first alone would not have fixed a phone:
  1. applySize() now compares the new width, height and pixel ratio against
     the current ones and returns immediately when nothing changed — before
     writing cv.width, which by itself clears the canvas.
  2. The sticky canvas is fitted to the SMALL viewport height (100svh),
     measured once from a probe, instead of window.innerHeight. innerHeight
     genuinely moves with the iOS URL bar, so fitting to it made the size
     really change on scroll and no guard could help. The probe doubles as the
     feature test, and orientation changes re-measure it.
  3. When the size genuinely did change, the scene now SLIDES into the new box
     — every particle, ripple, hero and vignette rescaled by the width and
     height ratio — instead of restarting. Only a real discontinuity starts
     over: the first sizing, or a box that has more than doubled or halved.
* The host ResizeObserver now goes through the same 150ms debounce as window
  resizes rather than calling applySize() directly on every observation.
* Tests: a same-size resize must produce zero canvas rewrites and leave every
  particle exactly where it was; a real resize must preserve the particle
  count and rescale each position rather than randomise it; ten simulated
  URL-bar cycles must leave the canvas box steady and the field untouched; a
  host resize must be debounced, not synchronous. The shipped 3.12.0 engine
  runs as a control arm, where the same ten cycles rewrite the canvas ten
  times with the box unchanged.

= 3.12.0 =
* FIXED: the canvas could still be lost for good. 3.11.0 checked whether
  something had removed it only once, at the settled pass — but the risk it
  was written for is a container re-rendering at an ARBITRARY later time, and
  a one-shot check cannot cover that by construction. Reproduced: re-render
  the host three seconds after load and the backdrop was gone permanently.
  Liveness now rides on the frame loop, which is already running: one
  body.contains() per frame, no observer to disconnect and nothing to leak.
  Re-mounts are rate-limited to one a second and capped at 20, so a script
  determined to remove the canvas is lost to gracefully rather than fought
  every frame, and the corrective coverage pass runs again afterwards because
  a re-render may have changed what paints over it.
  Latent on this site — nothing re-renders the homepage article today — so
  this is robustness rather than a live fault.
* FIXED, found by that test: the sticky mount check could reject a good
  re-mount. It compared a height computed BEFORE inserting the canvas against
  the host measured AFTER, and inserting the canvas changes the host's own
  height (it un-collapses the next element's top margin). A 23px canvas was
  judged against a host that had just grown to 38px and failed. The check now
  asks whether the canvas got the geometry it was given; whether the host is
  short is the fit's business, and the fit runs again straight afterwards.
* FIXED: the margin-compensation routine toggled display:none once per round.
  Repeated toggling perturbs the page it is measuring — on the live site the
  first toggle of a page load reads the true delta and later ones read ~36px
  of residue, which looks like a regression that is not there. It now takes
  one no-canvas baseline per page load and compares every round against it.
* Tests: mount, settle past the re-check, wipe the host's children, assert the
  canvas returns AND returns to the host rather than the body — with the
  shipped 3.11.0 engine as a control arm, where it does not return at all.

= 3.11.0 =
"Behind" itself is confirmed working on the live site in 3.10.0. These are two
defects in the SELF-CHECK that shipped with it — a check that cried wolf, and
an assertion that missed 50px.

* FIXED: the coverage check could report a working backdrop as 100% covered,
  and warn about it in the console, when it had not actually measured
  anything. Only the part of the canvas that is on screen can be sampled —
  elementFromPoint outside the viewport returns null, which says nothing about
  what paints there — and a canvas fitted to a column that is a few pixels
  tall at that instant has no measurable box at all. An unmeasurable sample is
  now reported as exactly that: the panel says "CANVAS REACH: not measurable —
  no part of the canvas box was on screen", and nothing is warned. The metric
  itself was already the right one (walk up to the first element that paints
  an opaque background, and only a DESCENDANT of the host covers the canvas —
  a backdrop at z-index:-1 is by design never the topmost element anywhere
  content exists).
* The check now runs TWICE: once at mount, and again 1200ms later once the
  layout has stopped moving. Only the settled run may warn, and the
  ?dcc_debug=1 panel is printed from it, so the panel and the console describe
  the page as it finally is rather than as it briefly was. Lazy images, late
  sections and webfont reflow all change a column's height after the mount.
* FIXED: the sticky mount added exactly 50px of page height on the live site,
  and the no-layout-shift assertion missed it twice over — it measured
  body.scrollHeight instead of documentElement.scrollHeight, on a fixture
  whose first child had padding instead of a collapsing top margin.
  height + a matching negative margin cancel the canvas's own flow height, but
  inserting a block as the host's FIRST CHILD also stops the next element's
  top margin from collapsing out of the host, and where a preceding sibling's
  bottom margin had been absorbing it, that margin becomes real page height.
  The engine now measures the difference instead of guessing at it — document
  height with the canvas, then with it display:none for one measurement, then
  back — and takes the difference off the negative margin, repeating up to
  three times. Self-correcting, so it holds for margin collapse, lazy-image
  reflow and themes never seen. The panel reports how much it corrected.
* Added: if something rewrites the host's innerHTML — a slider, an accordion,
  a theme script re-rendering a container — the canvas goes with it. The
  settled pass now notices and re-mounts.
* Tests: the fixtures now reproduce both faults against the shipped 3.10.0
  engine as a control arm (+50px of page height; a column that collapses after
  the mount). The suite asserts page height by documentElement.scrollHeight,
  and cross-checks the hit-test metric against the pixel ground truth of a
  magenta CSS background on the canvas element — a background on the canvas
  ELEMENT paints in the canvas's exact stacking position, cannot be cleared by
  the engine, and needs no requestAnimationFrame, which makes it valid in an
  automated browser whose visibilityState pauses rAF.

= 3.10.0 =
* FIXED: "behind" mode, measured rather than assumed. With Seasons finally
  switched on, the host walk was doing its job — it picked the theme's opaque
  content column — but the canvas was still invisible, because the article
  INSIDE that column paints opaque white over the whole of it. The re-target
  that was meant to catch this had existed since 3.7.1 and never fired on the
  live site: it ran once, from a 16-point sample, behind four conditions that
  all had to hold at the same moment.
  The mount is now verified and corrected by a post-condition instead. After
  mounting, the engine hit-tests a grid of points inside the canvas's own box
  and asks what paints there; anything inside the host is above the canvas and
  hiding it. While the canvas is covered it either moves INTO the covering
  element — where it paints above that element's background and below its
  content, which is what "behind" means — or, when that element cannot hold a
  canvas, takes the element's background colour off it and paints that colour
  on the canvas instead, over exactly that box, every frame. Up to four
  passes, then it reports what is left.
* The measurement is in the ?dcc_debug=1 panel as one line: CANVAS REACH: N%
  of its own box is unpainted-over — behind is working, or STILL COVERED BY
  <element>. Below 50% it also warns in the browser console. This is what was
  missing: every previous round needed a screenshot to know whether the mount
  had worked.
* Hit-testing, not pixel sampling, on purpose: document.elementFromPoint is
  layout, so it stays valid in an automated browser whose visibilityState
  pauses requestAnimationFrame — the state that made the previous round's
  canvas measurements meaningless.
* FIXED: a sticky-mounted canvas was always 100vh, so in a content column
  SHORTER than the window it overflowed and lengthened the page. It now fits
  whichever is smaller and stays fitted through a ResizeObserver, because lazy
  images change a column's height without firing a resize event.
* FIXED: corner accents used position:fixed inside a transformed host, where
  fixed resolves against the host rather than the viewport — so they landed in
  the column's corner and added scrollable overflow. They use absolute
  positioning there, which is what fixed already meant in that subtree.
* Tests: a new suite drives three shapes of the same problem through the real
  minified engine — the live markup (opaque column, opaque transformed article
  inside it), a covering grid container that cannot hold the canvas, and a
  column with no opaque painter at all — and asserts, by hit test, that
  nothing paints over the canvas afterwards. It runs the shipped 3.9.0 engine
  as a control arm on the same fixtures, and checks that a moved background
  still renders as the same colour and that the page height is identical with
  the engine on and off.

= 3.9.0 =
Three upgrade-safety fixes, all of them found on the live install rather than
in a test. Each had been failing silently — no error, nothing in the admin.

* FIXED: new themes never reached an edited schedule. The 3.7.0 migration only
  replaces a stored schedule outright when it recognises it as the UNMODIFIED
  pre-3.7.0 default. The owner's was edited, so it was converted row for row —
  and the six themes 3.7.0 introduced (Mother's Day, Memorial Day, Summer on
  the Canal, Father's Day, Independence Day, Veterans Day) were never given
  rows. Six themes were built, tested and shipped, and not one of them ever
  displayed. An upgrade now appends the default row for each theme a release
  introduced, when the schedule has no row for it.
  This is scoped BY VERSION, deliberately: only themes new in a version being
  upgraded THROUGH are appended, and only once each. The naive rule — "append
  a row for any theme that has no row" — would re-add a row the owner had
  deliberately deleted, and silently undo their choice. Summer on the Canal is
  exactly that case on this site: it is absent because Florida Keys was
  preferred as the summer backdrop, and it stays absent.
* NEW: "Built, but never shown" on the settings page. Any theme with no
  schedule row is listed under the schedule with the dates it would use and a
  one-click Add row button. Passive by design — a missing row is often
  deliberate, so nothing is ever added without a click. One line of this would
  have surfaced the problem above the day it appeared.
* FIXED: a switched-off plugin now says so, everywhere it matters.
  With Master enable unticked, nothing at all is printed on the site — no
  config, no scripts, no canvas, no easter egg — and because the diagnostics
  panel is drawn by the engine, ?dcc_debug=1 rendered NOTHING either. That
  state cost three rounds of work on "why doesn't behind layering work on the
  live site". Now: a red notice at the top of the settings page saying what
  being off actually means; a "Switched OFF" flag in the plugins list, where
  "Active" otherwise looks identical either way; and ?dcc_debug=1 renders a
  server-side panel whose first line is the reason nothing is rendering —
  switched off, both layers off, page excluded, or out of scope — followed by
  the state of every gate. A diagnostic that goes silent in exactly the state
  you need it for is worse than none.
* Tests: a regression fixture built from the real live schedule (21 rows, not
  equal to the old default, missing every new theme) asserts the upgrade
  appends exactly the new-in-version rows once and touches nothing else —
  including that Summer on the Canal is NOT re-added when it is absent and not
  new in that version. Coverage is now checked by walking 365 real days and
  resolving every row for year-1 and year, narrowest wins, asserting per-theme
  day counts; that method reproduces the live numbers exactly (98 uncovered
  days before, Florida Keys holding 87 days after) and finds a class of bug a
  defaults-based test structurally cannot.

= 3.8.0 =
* NEW THEME: Florida Keys — the year-round base. Calm and water-forward, with
  nothing in it that reads as a particular season, because it can land in any
  month: sabal palms (the state tree, and what actually grows along the
  canal — costapalmate fan fronds, not a coconut palm), a hibiscus bloom that
  lasts a single day and drops (which is why it FALLS), a flats skiff with its
  poling platform, a queen conch, the sun, shades, dragonflies and lilypads.
  The hero is a Brown Pelican: it commutes LOW over the water on stiff,
  motionless wings and drops into a couple of beats only when it starts to
  sink, which is the most recognisably-Florida thing in the theme.
* Six new hand-drawn sprites: sabalpalm, pelican (glide + flap frames),
  hibiscus, conch, skiff. Each depicts a real species or object with its
  identifying feature intact — the pelican's pouched bill and folded neck,
  the hibiscus's protruding staminal column, the conch's knobbed spire and
  flared pink lip — and each was checked at the real 30px particle size on
  both a white and a navy ground.
* The schedule gains a year-round base row (Jan 1 – Dec 31, Florida Keys),
  appended LAST. The picker takes the narrowest containing range, so a
  full-year row loses to every other row and can only win a day nothing else
  claims. Nothing that was showing before shows differently after.
* On upgrade, a schedule you have already edited gains that base row once, if
  and only if it has no full-year row of its own. Never duplicated; your rows
  are not touched; delete it and it stays deleted.
* A day with no row at all now falls back to Florida Keys rather than to the
  bare "None" theme.
* NOTE: 3.7.0's season rows already tile the whole year, so on the shipped
  default schedule the base row wins zero days. It exists for schedules with
  gaps — including the pre-3.7.0 one, which covers only September to April.
  Pick "Florida Keys" for a row, or shorten a season row, to see it.

= 3.7.1 =
* FIXED, with the live DOM in hand: "behind" layering on this theme. Three
  separate faults, each of which alone was enough to break it.
  1. The canvas was mounted in the theme's content column (main), but the
     element actually PAINTING the white column — article#post-620 — is a
     descendant of it, so it went on covering the canvas exactly as before.
     The engine now samples what is really painting the page and, when that
     turns out to be inside the chosen host, moves into it.
  2. That article carries a translateZ(-0.001px) hack, which makes it the
     containing block for position:fixed descendants — a fixed canvas inside
     it is silently reduced to an article-sized box that scrolls and clips.
     The canvas now mounts position:sticky in that case, so it stays
     viewport-tall and rides the content column. display:block on it, so it
     cannot add baseline space: layout is byte-identical with the engine on
     and off (verified).
  3. z-index:-1 resolves in the nearest ANCESTOR stacking context, not in
     the element it is written on, so mounting inside an ordinary container
     put the canvas behind that container's own background. Hosts that are
     not already a stacking context now get `isolation: isolate`, which
     changes nothing visually.
  Measured on a reproduction of the live chain: the canvas reaches 0.0% of
  the white column before, 69.8% after, with 0.0% over images and cards.
* Host selection is stricter: a candidate must paint something, have
  non-zero area (Elementor breaks out of the theme wrappers, collapsing them
  to 0px — they were being chosen), and not sit under a transform. Only a
  positioned element with a z-index above the canvas's can actually cover
  it, so those are tried first.
* FIXED: the mount check accepted any canvas at least viewport-sized, so a
  tall transformed ancestor could pass while producing a box that scrolled
  with the page. It now requires an exact viewport match.
* Diagnostics (?dcc_debug=1) now name the element painting the page and say
  whether it is above or below the canvas, and warn when several elements
  paint it — the one case a single canvas cannot fully sit behind.

= 3.7.0 =
* Six new themes: Independence Day (fireworks in red, white and blue, the
  eagle, sparklers), Memorial Day (poppies, the flag, doves), Mother's Day
  (tulips, blossom, a card that opens into hearts), Father's Day (the dock —
  a bass on the line, the grill, a necktie), Veterans Day (flag, poppies, a
  medal) and Summer on the Canal (sun, watermelon, flip-flops, ice cream,
  boats, dragonflies). Nine new sprites, all three-ground checked.
* The schedule is now RECURRING. Rows are rules — fixed month/day or a named
  holiday plus an offset — so it never expires, and moveable holidays land on
  the right day every year. The narrowest overlapping range wins its day.
  Year-spanning ranges and one-off years are supported. The settings page
  resolves every row to real dates for this year and next and reports gaps.
* Upgrade: an unmodified pre-3.7.0 schedule becomes the new recurring
  default outright. An edited one is kept — each dated row repeats yearly,
  and rows for moveable holidays take the proper rule so they stop drifting.
* FIXED: the easter egg opened after HALF the configured taps. The fallback
  tap target (#masthead) was always bound and encloses the real target, so
  every tap counted twice. Taps are now counted by delegation: once per
  tap, and still counted if the theme rebuilds its header on scroll.
* FIXED: corner accents (Halloween web, Thanksgiving cornucopia, Snowbird
  sunshades, Earth Day hands, Valentine's ribbon) ignored the layering
  setting and floated over content in "behind" mode. They now ride on the
  same mount as the canvas.
* The easter egg overlay locks the page behind it and traps keyboard focus;
  a swipe no longer scrolls the site under the rain.
* The settings page tables scroll inside their own box on a phone-width
  admin instead of pushing the page sideways.
* Reflections re-evaluate the mobile breakpoint on rotate.
* New admin-only diagnostics: append `?dcc_debug=1` to any front-end URL as
  an administrator and a panel reports the plugin version, the engine file
  actually loaded, the layering mode, every backdrop-host candidate with its
  computed position/z-index/background, which one was used (or why the
  canvas fell back to the body), and the full ancestor chain of the content
  column. Copy it and send it to the developer.

= 3.6.2 =
* FIXED: the 3.6.1 purge-on-upgrade never fired on an upgrade. The stored
  version option only exists from 3.6.1, so every upgrade from an earlier
  release arrived with no stored version — indistinguishable from a fresh
  install, which is the one case that correctly skips the purge. A saved
  settings row now tells the two apart, so upgrading actually purges.
* FIXED: the backdrop host was found by walking up from the FIRST element
  matching the content-anchor list, in document order. A theme wrapper that
  matches the list and encloses the real content column is therefore found
  first, and walking up from an ancestor can never reach the column inside
  it — so "behind" would silently fall back to the body mount. Every anchor
  is now walked, deepest candidate first.
* The "no backdrop host" console warning is only emitted when candidates
  existed and none could hold the canvas. A theme with no opaque content
  column has nothing covering a body-level canvas, so "behind" already works
  there and the warning was noise.
* No art, theme, schedule, glyph or settings changes.

= 3.6.1 =
* FIXED (the real cause): "Behind interactive widgets" never worked on this
  site, and 3.6.0's widget fix — correct in itself — could not have fixed it.
  The theme's content column (Bravada/cryout: main.main) is position:relative
  with z-index:9 AND an opaque white background. It therefore establishes a
  stacking context that paints over any body-level canvas below z-index 9,
  and anything above 9 is simply "front" mode. No body-level z-index lands
  between that white background and the text on top of it, so the widget-level
  z-index:10 from 3.6.0 was never consulted — the occlusion happens a level up.
* The canvas is now mounted INSIDE that element at z-index:-1. A
  negative-z-index positioned descendant paints after its stacking context's
  background but before its in-flow content: above the white, below every
  piece of text, image and widget. It needs no cooperation from individual
  widgets at all.
* Measured on a reproduction of the live DOM stack, as the share of the white
  content column the canvas can paint on: desktop 0.0% -> 60.0%, mobile
  (375px) 0.0% -> 50.4%, with 0 of 90,438 (desktop) and 0 of 63,076 (mobile)
  inked pixels covered — no particle over any text, image, button, card or
  calendar cell. Coloured page margins stay fully reachable.
* The host is found by walking up from the page's content anchor to the
  nearest ancestor that both establishes a stacking context and paints an
  opaque background — never hardcoded to one theme's markup. Override it with
  the new `dcc_seasons_backdrop_host` filter.
* A candidate that turns out to be the containing block for fixed descendants
  (transform/filter/perspective) would clip the canvas; the mount is measured
  and such a host is rejected in favour of the next one up. If nothing usable
  is found the canvas returns to the pre-3.6.1 body mount AND logs a console
  warning naming the filter — it is never left invisible.
* "In front of everything" is byte-for-byte unchanged: body, z-index 99990.
* A plugin install or upgrade now purges the page cache. Uploading a zip
  changes nothing a full-page cache can see, so cached HTML kept the old
  inline config and the old `?ver=` asset URL — after the 3.6.0 upload the
  site went on serving engine.min.js?ver=3.5.0 until someone purged by hand.
  A stored version is compared against the plugin's, so FTP uploads and
  auto-updates are caught too, not just the upgrader.
* Art: `cork` replaced by `popper` (a party popper). Two redraws of a
  champagne cork read as a bucket and then a mushroom; the concept does not
  survive 28px, so the replacement licence was spent instead of a third try.
  Same New Year's scene, same beat.

= 3.6.0 =
* FIXED: "Behind interactive widgets" was far too aggressive. The rule also
  painted `background: #fff` on the Elementor widget WRAPPER — the whole
  bounding rectangle, not the controls — so the particles were hidden behind
  a pair of large opaque blocks rather than passing behind the widgets. A
  browser hit-test (canvas filled solid, screenshot, count the pixels it can
  reach inside each wrapper) measured 0.0% of the wrapper reachable, on
  desktop and at 375px alike. The rule now sets stacking only. Same
  measurement after: 22.0% desktop / 24.8% mobile reachable on a widget
  whose own root is transparent — its padding, gaps and rounded corners —
  while painted cards, cells and text still measure 0.0%. Widgets that paint
  their own background keep it and look identical.
* The widget list is matched by attribute prefix (`elementor-widget-dcc*`,
  `elementor-widget-mphbac*`) instead of three exact class names, and is
  filterable via `dcc_seasons_layering_selectors`, so a DCC widget rename no
  longer needs a release here.
* "In front of everything" is unchanged, and still emits no style tag at all
  — which is what makes a stale cached page detectable.
* Art: 16 sprites redrawn for accuracy — sleigh (the Christmas hero; read as
  a flying chicken drumstick), cornucopia, all three remaining autumn leaves
  (leafm/leafc/leafs — the primary particle in two themes), cork, lure,
  lilypad, petal, manatee, swan, hands, peel, stilts and pontoon.
* The April Fool's chattering teeth (`teeth0`/`teeth1`) are replaced by a
  whoopee cushion (`cushion0`/`cushion1`): the concept could not be read at
  particle size. Same two-frame chatter animation, same theme slot.
* Every one of the 278 path elements in the sprite registry passes the
  path-arity validator, and all 20 theme previews render with zero
  "<path> attribute d" console warnings.

= 3.5.0 =
* New "Where effects appear" setting (`scope`), directly beneath the
  ambient/egg toggles: Homepage only · All pages except cottage pages · All
  pages · All pages and posts. Default is "All pages and posts", including
  for existing installs whose stored options have no `scope` key, so
  upgrading changes nothing until you choose otherwise.
* Cottage pages are detected by MotoPress post type (`mphb_room_type`, asked
  of MotoPress's own API first), never by URL or slug.
* A page outside the scope now loads NOTHING — no loader script, no inline
  config, no inline layering CSS. Out-of-scope pages cost zero bytes.
* The scope gate runs alongside, never instead of, the hard exclusions: the
  MotoPress checkout and the Elementor editor stay clean under every scope
  value, and the new `dcc_seasons_in_scope` filter cannot re-enable them.
* Admin theme previews (`?dcc_season=`) bypass the scope gate, so previewing
  works on pages the current scope excludes.
* Saving the settings purges the page cache (SpeedyCache first, then other
  common caches, all guarded by function/class checks). The settings page
  reports what was purged — or warns you to purge manually if nothing could
  be reached.
* New filters: `dcc_seasons_in_scope`, `dcc_seasons_cottage_post_types`, and
  the `dcc_seasons_purged_cache` action.
* Note: scope governs the ambient effects and the easter egg together, so
  with "Homepage only" the egg does not fire on interior pages.
* No art, sprite, theme, schedule, engine, glyph or animation changes.

= 3.4.0 =
* The settings page moved from Settings → DCC Seasons to the shared
  **DCC → Seasons** top-level menu, alongside the other Dora Canal Court
  plugins' screens. The page slug is unchanged, so the old
  `options-general.php?page=dcc-seasons` URL redirects to the new
  `admin.php?page=dcc-seasons` and existing bookmarks still resolve.
* The shared parent menu is registered idempotently: whichever DCC plugin
  loads first creates it, and each one removes WordPress's auto-generated
  duplicate first item, so deactivating any sibling never orphans the page
  and never produces a second "DCC" menu.
* Internal: the admin screen ID changed with the parent
  (settings_page_dcc-seasons → dcc_page_dcc-seasons). The conditional admin
  asset enqueue and the preview-buttons panel now compare against the hook
  suffix add_submenu_page() returns rather than a hard-coded string, and the
  Plugins-row "Settings" link resolves through menu_page_url().
* No art, theme, schedule, engine, glyph, or option changes.

= 3.3.1 =
* Three more sprites were still shipping malformed path data from the
  3.2.0 precision-trim regex. The browser silently drops a bad path, so
  each rendered with a part missing while only whispering "<path>
  attribute d: Expected number" to the console: flamingo had lost its
  BEAK (the black-tipped bill is its field mark), hook had lost its BARB,
  and clover had one of four LEAVES malformed. All three are reconstructed
  from intent and rewritten with explicit spacing so no number pair can be
  ambiguous again.
* A path validator now ships in tools/validate-paths.js and runs in the
  test suite. The 3.3.0 registry scan searched for the regex's INPUT
  pattern (compact runs like "8.2.4"), but the corrupted OUTPUT ("12.2")
  is an ordinary-looking number that no text search can find — it is only
  detectable by parsing. The validator tokenises every `d` attribute and
  checks each command's argument count (M/L/T multiples of 2, H/V of 1,
  C of 6, S/Q of 4, A of 7, Z of 0). It found exactly these three and
  would have caught bat the day the regex ran. A companion browser check
  now fails the build on any "<path> attribute d" console warning across
  all 20 theme previews.
* Craft defects — a third class, distinct from "can you see it" (3.2.1)
  and "is it the right object" (3.3.0): is it BUILT correctly?
  - spider: 6 legs, asymmetric — the left three started at the body's edge
    and the right three at its CENTRE, so they emerged from under the body
    and read shorter. Now 8 legs, 4 per side, mirrored structurally by a
    <use> flip so symmetry cannot drift.
  - dragonfly: 2 same-angled wings on a rect body read as a paper dart.
    Now 4 wings in two pairs, a long segmented abdomen trailing well
    behind them, and a head with a compound eye.
  - web: radiating lines that read as scratches. Now 5 spokes plus 4
    concentric rings — the rings are what make it a web.
  - frog: no legs at all. Two bent hind legs added.
  - ladybug: 3 spots scattered across the elytra seam and no antennae.
    Now 4 spots mirrored about the seam, plus antennae.
* Anatomy sweep across every sprite with countable or symmetric parts came
  back clean. One deviation noted and deliberately kept: the strawberry's
  calyx has 4 sepals where real fruit has 5–7 — a stylisation that reads
  correctly at 28px.
* engine.min.js 65,736 raw / 23,105 gzipped, inside the 66KB / 23KB
  ceiling (3.3.0 was 64,803 / 22,823). No sprite had to be simplified to
  pay for the extra legs, wings and web rings.
* Art repair only: no theme, behaviour, settings, schedule or glyph
  changes, and all stored options survive untouched.

= 3.3.0 =
* The accuracy release. The criterion was not detail but whether a sprite
  depicts the object it is supposed to depict: if a viewer confidently
  names it as something else, it fails, because it silently misrepresents
  the theme. Every item below was that class of defect, judged at ~28px.
* Critical false reads fixed: joint (read as a PENCIL/cigarette — the tan
  wedge at the mouth end is exactly where a pencil's wood or a cigarette's
  filter sits, so it is gone; the cone is now strongly tapered and the lit
  end glows instead of being a hard orange bead); fleur (read as a CROWN
  or trophy — the side petals now sweep out and hook DOWNWARD, the
  decisive field mark, over a tapering foot rather than a blunt block);
  berry (read as a TOMATO — now a cone/heart silhouette pointed at the
  bottom with a pointed calyx crown on the shoulders and brighter seeds);
  horseshoe (read as a MAGNET — the branches now curve back in so the
  mouth is narrower than the widest point, which magnets never do, plus
  six high-contrast nail holes).
* silly retired. It read as ANGRY (an arc above two dots is a furrowed
  brow), and it was the last sprite still imitating a flat platform emoji.
  April Fool's leans on the existing jester instead, which also saves
  bytes.
* Softer misreads fixed: swan (read as a DUCK — now a long thin S-curve
  neck, small head, and the mute swan's black knob at the orange bill);
  bunny and bunnycarry (read as a BLOB with ears — now a crouched rabbit
  with a defined haunch, a muzzle rather than a sphere, and the tail as a
  tuft on the outline; bunnycarry holds the egg in front with its paws).
* bat was rendering brown rather than black because its wing path had been
  CORRUPTED by the precision-trim regex shipped in 3.2.0, which collapsed
  compact SVG number pairs such as "8.2.4" (two numbers) into one. The bat
  is redrawn, the trim is rewritten to only touch unambiguously delimited
  numbers, and the whole registry is checked for the same damage.
* Matrix rain: matrix.js can now paint DRAWN glyphs (a '@name' entry is
  rendered with canvas paths instead of fillText), so 4/20 rains a real
  cannabis leaf instead of 🍃, which is a wind-blown tree leaf — the very
  error the ambient sprite had before 3.2.0. Colour object-emoji are gone
  from twelve themes' glyph sets, replaced by typographic and katakana
  glyphs that render identically on every platform; ★ ✦ ▮ ❄ ♥ ☠ ⚜ ☘ ✿ and
  the katakana stay, and the eight already-clean themes were not touched.
* New Year's now reads as a celebration. Fireworks were built from stolen
  ambient particles — 13 dots on a 1200px canvas, which also emptied the
  theme while they flew. They are now a dedicated short-lived system: 26
  radiating streaks with trails, a flash at the burst point, and a cadence
  of 1.4–2.8s so any given moment shows one. The year is 46px bold with a
  dark outline (it was barely legible on a light page) and holds longer,
  the countdown numerals are outlined to match, and confetti and bubbles
  are large enough to register.
* engine.min.js 64,803 raw / 22,823 gzipped and matrix.min.js 5,959 raw /
  2,660 gzipped. The ceiling was raised to 66KB/23KB for this release but
  the engine landed under the OLD 64KB/22.5KB ceiling instead.
* No settings, schedule or behaviour changes; all stored options survive.

= 3.2.1 =
* Sprite contrast on light pages. The 3.2.0 audit judged every sprite
  against a single background; the live site renders particles over both a
  deep navy hero and large white content sections, and the pale sprites
  that survived on navy washed out on white. Root cause is stroke weight
  relative to viewBox width — a 1-unit outline on a 46-wide viewBox is
  about 0.6px at particle size, i.e. sub-pixel. Rule adopted: any sprite
  with a near-white body needs an outline of at least ~6% of its viewBox
  width, in a tone dark enough to read on white rather than a tint of the
  fill. Applied to dove (the worst case, and MLK Day's primary particle),
  swan, bunny, bunnycarry, ghost (kept deliberately soft — ethereal, but
  now visible), blossom, quill, joint and flutes (whose outline was wide
  enough but far too pale to count). Silhouettes and palettes unchanged.
* recycle redrawn. Three solid rotated wedges read unmistakably as a green
  fir tree at particle size — actively confusing on Earth Day, which
  already has plant particles. It is now the real Möbius symbol: three
  chasing ribbon arms with visible arrowheads and an open centre.
* fleur redrawn. The rounded lobes read as a chess piece or trophy; the
  petals are now lance-tipped over a banded waist, so the Mardi Gras
  reference lands at 26–34px.
* The audit grid is now the acceptance test: every sprite is rendered
  three ways — 120px on white, 30px on white, 30px on the site's navy —
  and passes only if identifiable in all three. That grid ships with the
  release. It also caught two the report had not listed: bunnycarry (as
  faint on white as bunny) and the Halloween web accent.
* engine.min.js 63,015 bytes raw / 22,228 gzipped, inside the 64KB /
  22.5KB ceiling (3.2.0 was 62,712 / 22,120) — outlines are cheap, so no
  art had to be thinned to pay for them.
* Art only: no theme, behaviour, settings, schedule, engine or layout
  changes, and all stored options survive untouched.

= 3.2.0 =
* 4/20 art fixed (the owner's direct complaint). The cannabis sprite was a
  smooth six-petal shape that read as a generic tree leaf; it is redrawn
  with the real field marks — 7 narrow lance-shaped leaflets radiating
  from one point, serrated edges, longest in the centre, smallest at the
  bottom. The grey curl-noise "wisp" particles (which read as noodles) are
  gone entirely, replaced by a drawn joint: tapered rolled cone, twisted
  paper tip, warm ember, and its own smoke curling up from the lit end.
  The peace emoji is now a drawn V-sign hand.
* No more "gentle" themes. Patriot Day and MLK Day run at full richness
  like every other theme — real particle counts, parallax, vignettes,
  pointer play, accents and a working easter egg. Patriot Day: waving flag
  cloths, red/white/blue stars, the eagle hero, a three-flag formation
  vignette, and a red/white/blue egg with star glyphs. MLK Day: doves in
  flight, olive sprigs and gold hearts on a gold/white palette, a
  dove-formation vignette, and a matching egg. The engine's `solemn`
  special-case is deleted; no theme ships `egg => false` any more. Preview
  labels are plain "Patriot Day" and "MLK Day".
* Full art audit — the ambient layer is now 100% drawn. All 24 remaining
  raw platform emoji (which rendered differently on every device and
  clashed with the drawn sprites beside them) are replaced by 18 new
  house-style sprites — snowflake, sparkle, fleur-de-lis, clover, orange,
  banana, burger, olive sprig, tree, flamingo, bat, champagne flutes,
  upside-down face, beach umbrella, recycle, fishing hook, joint, peace
  hand — plus a recolourable heart primitive and reuse of the existing
  bass, flagcloth and kayak art. Ambiguous silhouettes were re-cut after
  judging every sprite at its real 28px particle size: the pie was
  redrawn as a dish with a domed lattice crust, and the dove, swan and
  blossom (previously white-on-white and nearly invisible on a light page)
  gained outlines and shading.
* engine.min.js 62,712 bytes raw / 22,120 gzipped — within the raised
  64KB / 22KB ceiling (was 56,764 / 20,353).
* No settings, schedule, behaviour or performance-guardrail changes; all
  stored options survive untouched.

= 3.1.0 =
* New "Layering" setting (Settings → DCC Seasons, next to the layer
  toggles). "Behind interactive widgets" (the default, including for
  upgrades with no stored value) puts the ambient canvas at z-index 5 and
  raises the DCC cottage-selector and availability-calendar Elementor
  wrappers above it on a white backing — replacing the site-side
  mu-plugin rule (dcc-ui-tweaks item 3) byte-for-byte so it can be
  retired. "In front of everything" restores the pre-3.1 canvas
  z-index 99990 and outputs no widget CSS at all. The choice rides the
  existing config pipeline (a one-key `layer` flag the engine reads when
  creating its canvas); the Matrix easter-egg overlay is untouched in
  both modes and still covers everything. No other setting, theme, or
  behavior changed; existing stored options survive unchanged.

= 3.0.0 =
* The "wow" visual overhaul, designed around the Dora Canal identity.
* Bespoke illustrated sprite set (~75 inline SVGs, one consistent hand):
  species-accurate fall leaves (maple/oak/cypress/sweetgum), three
  jack-o'-lantern faces with flicker glow, turkey 2.0 leading chicks,
  glinting ornaments, state license plates (NY/OH/MI), rose petals, opening
  love letter, quill with ink trail, decorated-egg upgrades, pontoon 2.0
  with stern flag, kayak, swans, stilt walker, and more. Emoji remain only
  as tofu-checked fallbacks.
* Depth layers: FAR parallax layer (60% scale / 50% speed / 60% opacity)
  behind the NEAR layer.
* Waterline reflections: actors just above the water draw a flipped,
  squashed 25% mirror; floaters get a broken shimmer line. Off on mobile.
* Pointer awareness (observation only): particles ease away from the
  cursor and spring back; a click landing on a particle pops it without
  consuming the click.
* Vignette director — rare 5–12s choreographed scenes, one at a time,
  ≥90s apart: the pontoon flotilla, the FULL CAST fishing story (lure →
  bobber → circling shadow → bass strike), dragonfly-lands-on-the-bobber,
  witch across the moon, sleigh gift-drop (+ evening sleigh-past-moon),
  cork pop, flamingo arrival on the waterline, stilt walker, doubloon
  shower, the two swans forming a heart, berry-in-the-basket, the Easter
  egg hunt and the hatch, the banana slip, mama duck parade, the kayaker.
* THE real New Year's countdown: within the final 10 seconds of Dec 31 by
  the visitor's clock, numerals count down to a triple mega-burst with the
  year in gold.
* Evening tint (7pm–6am local): −10% brightness, +30% glow, night
  variants (fireflies on the canal, pontoon deck lights, sleigh-past-moon).
* Christmas snow accumulation: a ≤6px snow line builds along the
  waterline from settled flakes (per-session).
* Egg finale formations: ~18s into the Matrix rain the glyphs organize
  into the theme's shape (jack-o'-lantern, turkey, tree, year numerals,
  fleur-de-lis, heart, shamrock, egg, globe), hold, and dissolve.
* Heroes upgraded: 3-frame heron wingbeat with an occasional full landing
  sequence on the waterline (the classic no-theme day's signature);
  manatee mom-with-calf; upgraded rainbow moment (leprechaun hat, coin
  arcs, clover strip); the inverted heron on April Fool's only.
* Auto-degrade ladder (~8ms rolling frame budget): sheds reflections →
  far parallax → vignettes, silently. New settings: Visual richness
  (Full/Classic/Minimal) + Advanced visuals toggles (reflections,
  vignettes, pointer awareness, evening tint, snow).
* Patriot Day and MLK Day are exempt from all of it beyond sprite polish —
  quiet and dignified, nothing falls on Patriot Day, egg stays off.
* engine.min.js: 56.7KB raw / 20.3KB gzipped (budget ≤60KB / ≤20KiB).

= 2.2.0 =
* Preview tooling baked in (the "DCC Seasons Preview Links" companion
  mu-plugin can now be deleted): the settings page gets a panel of
  one-click preview buttons — one per theme plus a red-outlined "Off
  (force none)" — each opening the homepage with ?dcc_season=<key> in a
  new tab, with a note that reads the live saved tap count; and any
  front-end page loaded by an administrator with ?dcc_season= present
  shows a fixed bottom-right chip ("Previewing:" + a theme dropdown that
  swaps the param in place, preserving path and other query params, and a
  ✕ that removes it). Admin-gated inline output only — nothing is
  enqueued for visitors and non-admins get no markup at all. Themes added
  via the dcc_seasons_themes filter appear in both automatically. No
  engine, loader, schedule, or visitor-facing changes.

= 2.1.0 =
* Directional facing: particle specs can declare `face:'L'` (native art
  faces left) and the engine mirrors the glyph when travelling rightward —
  boats, fish, birds, turkey, flamingo Vs, dove, bunny and chick now face
  their direction of travel. Flags, symmetric glyphs, and canvas primitives
  are never flipped; jump-arc rotation stays correct when mirrored. The
  emoji heroes (eagle, witch) and the duckling line flip too.
* FIX: the big-bass hero never rendered (jump physics ran but there was no
  draw branch — visitors saw two unexplained ripples). It now draws a 🐟
  (🐠 fallback) at 40px, rotated along its arc and facing its travel.
* FIX: procedural Easter eggs could pick identical base/decoration colors
  and look plain; the decoration color now always contrasts, and the eggs
  are ~15% larger (sz 20–30) with a heavier spawn weight.
* New `cruise` behavior: rides AT the waterline with a gentle bob while
  steadily crossing, dropping a wake ripple every 2–4 s. Labor Day's
  speedboat is replaced by a new pontoon-boat SVG sprite that cruises the
  water (boats no longer fly mid-air); Spring on the Canal's canoe cruises
  too. Labor Day gains the waterline and plants its beach umbrellas at the
  bottom (grow) instead of raining them; Christmas trees likewise grow up
  from the bottom edge instead of falling.
* Easter Matrix rain: removed '🥚' (renders as a plain chicken egg);
  glyphs are now 🐣 🐰 ✿ with the pastel palette unchanged.

= 2.0.0 =
* FIX (critical): the tap target now accepts a comma-separated selector list
  and binds every VISIBLE match (Bravada renders #branding at 0px on this
  site). Zero-size elements are skipped; #masthead is the last resort. New
  default: `#branding, .header-image .entry-title, .entry-title, #site-title`.
* FIX: canvas sizing hardened for Chrome zoom / wide monitors — one width
  source (canvas rect × devicePixelRatio), re-applied on window.resize AND
  visualViewport resize with a particle re-seed (ambient and egg).
* Particle overhaul: THE WATERLINE (settle+ripples, floaters, jumping bass,
  submerged manatee along the bottom ~8%); 20+ motion personalities (sway,
  flutter, dangle, hang, toss, hop, waddle, dart, twinkle, chatter, grow,
  vee formations, orbit-pair, burst…); hybrid rendering (emoji + recolorable
  canvas primitives + ~19 inline SVG sprites, tofu-checked fallbacks).
* BRAND HERO: the great blue heron glides across every 2–3 minutes in every
  theme AND on no-theme days. Per-theme heroes: eagle, witch flyby, Santa
  sleigh, manatee, big bass jump, ducklings, St. Patrick's rainbow moment.
* Patriot Day rebuilt: NOTHING falls (twinkle + slow glide only), ribbon
  accent, eagle hero, egg still disabled. MLK Day: dove/olive/heart, gentle.
* New Year's fireworks now flash the auto-computed year at the burst point.
* The ambient engine is its own lazy file (engine.js) loaded after idle;
  the deferred loader stays tiny. All caps unchanged (≤16 particles
  including ripples, ≤60 egg columns, visibilitychange pause).

= 1.1.0 =
* Theme preview: `?dcc_season=<theme_key>` forces a theme for the page view
  (`off` forces none) — restricted server-side to logged-in users with
  `manage_options`. Valid keys listed on the settings page.

= 1.0.0 =
* Initial release: ambient particle layer, lazy-loaded themed Matrix egg,
  pre-seeded 2026–27 schedule, settings page, cache-safe client-side date
  logic, checkout/Elementor exclusions, reduced-motion support.
